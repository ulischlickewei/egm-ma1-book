var ptx_lunr_search_style = "textbook";
var ptx_lunr_docs = [
{
  "id": "front-colophon",
  "level": "1",
  "url": "front-colophon.html",
  "type": "Colophon",
  "number": "",
  "title": "Colophon",
  "body": "  "
},
{
  "id": "ma1-ds-3-4",
  "level": "1",
  "url": "ma1-ds-3-4.html",
  "type": "Preface",
  "number": "",
  "title": "Preface: How to use this book",
  "body": " Preface: How to use this book  This book accompanies the course Mathematics 1 for students of Engineering and Management. It covers complex numbers, sequences and series, functions and differential calculus, integral calculus, and ordinary differential equations — in ten sections, one per week of lectures.   The course is flipped. Every week, you read the corresponding section at home before the lecture. In the lecture itself, the material is not presented again. Instead, we work through exercises to deepen it, discuss it and answer your questions. This only works if you come prepared — and that is what this book is written for. Plan about two to three hours of focused reading to prepare one section.   How a section is organized. Every section begins with objectives : this list tells you what you should be able to do at the end. Read it first, and read it again at the end. Then comes the actual material: definitions fix the terms, theorems state the rules of computation and the relationships between ideas, and examples show how to compute with them. The examples are the heart of the book: computational examples walk through a method step by step, and application examples show where the same method is needed in data science, business or engineering — from AC circuit analysis through compound interest, marginal cost and probability densities to gradient descent. When you first prepare a section, you can skip examples with (optional) in the title: the rest of the text does not depend on them, and the short quizzes in the lecture do not assume them. At the end, a summary collects the most important points on one page, and a few short exercises let you check whether you have understood the section.   Read with pen and paper. You cannot read mathematics like a novel. In the online version, the solutions to the examples are collapsed at first: try each example on your own, and then expand the solution to compare. When a computation in the text skips a step, work it out yourself. And if something is still unclear, write down the question — that is exactly what the lecture is for.  The aim of the course is that you learn to recognize typical problem structures, apply standard methods with confidence, and develop a solid understanding of the mathematical tools that are used every day in data science and engineering practice.   How this book was written. The text was generated with the help of artificial intelligence (AI), based on the author's lecture slides. The author then reviewed and curated it carefully and is responsible for its quality. The English version was translated from the German original with the help of AI and reviewed by the author.  "
},
{
  "id": "ma1-ds-3-4-3",
  "level": "2",
  "url": "ma1-ds-3-4.html#ma1-ds-3-4-3",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "The course is flipped. "
},
{
  "id": "ma1-ds-3-4-4",
  "level": "2",
  "url": "ma1-ds-3-4.html#ma1-ds-3-4-4",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "How a section is organized. "
},
{
  "id": "ma1-ds-3-4-5",
  "level": "2",
  "url": "ma1-ds-3-4.html#ma1-ds-3-4-5",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Read with pen and paper. "
},
{
  "id": "ma1-ds-3-4-7",
  "level": "2",
  "url": "ma1-ds-3-4.html#ma1-ds-3-4-7",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "How this book was written. "
},
{
  "id": "sec-koerper-der-komplexen-zahlen",
  "level": "1",
  "url": "sec-koerper-der-komplexen-zahlen.html",
  "type": "Section",
  "number": "1.1",
  "title": "The field of complex numbers: Representations and basic arithmetic",
  "body": " The field of complex numbers: Representations and basic arithmetic    After this section, you can    add, subtract, multiply and divide complex numbers in algebraic form;  determine the real part, imaginary part, modulus and conjugate and interpret them in the complex plane — in particular the modulus as the distance from the origin and as the distance between two points;  convert between algebraic form, polar form and exponential form — for the standard angles by normalizing and reading off the unit circle;  compute products, quotients and powers via the exponential form and interpret them geometrically as a rotation combined with a scaling;  read impedances and phasors of AC engineering as complex numbers.     At first sight, complex numbers look like a trick: a new number whose square is . In fact, they are the natural tool for everything that oscillates or rotates — alternating currents, signals, periodic time series — because they combine lengths and angles in a single number. This section introduces the complex numbers and their two representations: the algebraic form  , in which addition is easy, and the exponential form  , in which multiplication and powers are easy. By the end, you should be able to switch freely between the two and know which form suits which computation.    The field of complex numbers   What is the square root of ? In school, the honest answer is: there is no such thing. For every real number , we have , so the equation has no real solution — and a quadratic equation with a negative discriminant simply has no solution.   The mathematicians of the 16th century saw it the same way at first. But when they solved cubic equations, they repeatedly came across square roots of negative numbers. They found that they could simply go on computing with these impossible quantities and still get correct, perfectly ordinary real results in the end. René Descartes called such numbers, somewhat disparagingly, imaginary, that is, existing only in the imagination. The name has stuck, but the stigma has not. Today, complex numbers are indispensable in electrical engineering, signal processing and control engineering.  The basic idea fits in one line: we introduce a new number with and compute with it by the usual rules. In this subsection, you will see which numbers arise, how to draw them as points in a plane, how to measure their size, what the conjugate of a number is, and how to compute with complex numbers. You will find that you already know much of it.    The imaginary unit and complex numbers  We extend the real numbers by a new number, the imaginary unit  , for which, by definition, holds. Nothing more is needed: you may compute with as with a variable — add, multiply out, remove parentheses — except that you may replace by at any time. (By the way, electrical engineers write instead of , because already stands for the current there.)   Complex numbers   A complex number is a number of the form with real numbers and . The set of all complex numbers is      The equation becomes solvable   Show that and solve the equation . In the same way, find two solutions of .    We compute with as with a variable and replace by at the end: In the same way, and ; so the equation has the two solutions and . Likewise, and solve the equation .  The numbers and are complex numbers in the sense of the definition, each with . So equations that we could not solve in suddenly have solutions in — two of them, in fact.    A complex number thus consists of two real building blocks: the part without and the factor in front of . Each of them gets its own name.   Real and imaginary parts; equality   For , is called the real part and the imaginary part of . Two complex numbers are equal if and only if their real parts and their imaginary parts agree.    Watch out: a common trap. The imaginary part is the real number , not . For , we have , not .   Reading off real and imaginary parts   Determine the real and imaginary parts of , , and .      , .  Since , we have and — the minus sign belongs to the imaginary part.  is not written in the order real part first. Rearranged, , so and .  Since , we have and .       One complex equation contains two real equations   Determine the real numbers and such that holds.    On the left is a complex number with real part and imaginary part ; on the right, one with real part and imaginary part . The two are equal if and only if both parts agree: So a single equation between complex numbers gives two equations between real numbers. You will often use such a comparison of real and imaginary parts.     Real and purely imaginary numbers  Every real number can be written as , that is, as a complex number with imaginary part . In this sense, : the complex numbers extend the real numbers; they do not replace them. The other extreme is complex numbers with real part , that is, numbers of the form ; they are called (purely) imaginary — like and from the examples above.     The complex plane  We think of real numbers as points on a number line. But a complex number has two real components, and two coordinates describe a point in the plane. This view was made popular above all by Carl Friedrich Gauss, who also coined the term complex number in the first half of the 19th century. The plane is therefore also called the Gauss plane .   Complex plane   In the complex plane , the complex number is represented as the point with Cartesian coordinates . The horizontal axis is called the real axis , the vertical axis the imaginary axis .     The complex plane: the number is the point with coordinates .    A coordinate system with a horizontal real axis and a vertical imaginary axis. The real axis has a tick mark at , the imaginary axis at . The point lies in the first quadrant; dotted lines connect it to on the real axis and to on the imaginary axis.       Plotting complex numbers (optional)   Plot , , , , and in the complex plane. Where are the real numbers, and where are the purely imaginary ones?    Each number becomes the point , so , , , , and ; see . The sign of the real part decides between left and right, the sign of the imaginary part between up and down.   The numbers in the complex plane.    A coordinate grid from to horizontally and from to vertically. The figure marks at in the first quadrant, at in the second, at in the third, at in the fourth quadrant, at on the real axis and at on the imaginary axis.      The real number lies on the real axis ( -axis), the purely imaginary number on the imaginary axis ( -axis). So the real axis is the familiar number line — the complex plane adds a second direction to it.     Conditions on the real and imaginary parts as pictures   Where in the complex plane are all complex numbers with  ,  ,  ,  ?        All points with arbitrary : the vertical line through , parallel to the imaginary axis.  All points : the horizontal line through , parallel to the real axis.  All points above the real axis: the upper half-plane, without the real axis itself.  All points : the line that bisects the first and third quadrants, that is, the numbers with .    Conditions on the real and imaginary parts describe lines and half-planes. With the modulus, which we introduce next, circles come in as well.      The modulus  How large is a complex number? For real numbers, the absolute value measures the distance from to zero on the number line. In the complex plane, it is natural to do the same: we measure the distance of the point from the origin — and the Pythagorean theorem gives us this distance.   Modulus of a complex number   The modulus (or absolute value ) of is      The modulus is the hypotenuse of the right triangle with legs and , that is, the distance from to the origin.    A right triangle in the complex plane with vertices at the origin, at and at . The horizontal leg on the real axis has length , the vertical leg has length , and the hypotenuse from the origin to has length .      Geometrically, is thus the distance from to the origin . For a real number , the formula gives , the familiar absolute value of a real number — so the new definition agrees with the old one.   Computing moduli   Determine , , , and .     For , we get the absolute value of a real number, as expected. The last number has modulus , so it lies on the circle of radius around the origin, the unit circle . Such numbers play a leading role in .     All numbers with modulus 5   Which complex numbers with integer real and imaginary parts have modulus ? Where do they lie in the complex plane?    We are looking for integers with , that is, . The squares up to are , and exactly two combinations add up to : and (each in both orders). With all choices of signs, we get the twelve numbers All of them have distance from the origin and therefore lie on the circle of radius around ; see .   The twelve numbers with integer real and imaginary parts and modulus lie on the circle of radius around the origin.    A circle of radius around the origin of the complex plane. Twelve points are marked on it: the four points and on the axes and the eight points and . The points , , and are labeled.      In general, the numbers with form the circle of radius around the origin.     Application: Positions in a warehouse (optional)   Autonomous transport robots move around a logistics warehouse. The warehouse control system describes each position in meters relative to the charging station at the origin; the real axis points east, the imaginary axis north. A position is then simply a complex number. Python, for example, has the built-in data type complex for this, written with j as in electrical engineering: -12+9j .  Robot A is at , robot B at ( ). Which of the two is closer to the charging station?   Positions of two transport robots relative to the charging station (in meters).    A complex plane with the charging station at the origin. The real axis is labeled East, the imaginary axis North. Robot A is at at the upper left, robot B at at the upper right; dotted lines show their coordinates on both axes.        The distance to the charging station is the distance from the origin, that is, the modulus: At a straight-line distance of  m, robot A is closer to the charging station than robot B at  m. (In Python, abs(-12+9j) returns exactly this modulus, 15.0 .)    A final warning: in , you can compare any two numbers by size. In , this is not possible — there is no ordering of the complex numbers that is compatible with the rules of arithmetic. An expression like therefore simply makes no sense. However, you can compare the moduli: .    Complex conjugation  Another operation has no counterpart for real numbers, but it is extremely useful: you reverse the sign of the imaginary part. Geometrically, this is a reflection in the real axis.   Complex conjugation   For , the number is called the complex conjugate of . In the complex plane, is obtained from by reflection in the real axis.    In engineering, is also often written instead of .   The conjugate is the mirror image of in the real axis.    A coordinate system with a horizontal real axis ( ) and a vertical imaginary axis ( ). The figure shows the point , the origin, a dashed line from the origin to , and the point , the reflection in the real axis, which is also connected to the origin by a dashed line.       Conjugating means reflecting (optional)   Determine the conjugates of , , and , and describe what happens in the complex plane.    Only the sign of the imaginary part changes: The points and move to the other side of the real axis. The purely imaginary number jumps along the imaginary axis from to . The real number lies on the mirror axis and therefore stays where it is.     Conjugation does not change the modulus (optional)   Verify that for every complex number . Also explain this geometrically.    With , we have , so Geometrically: the origin lies on the mirror axis, and a reflection does not change distances — so and have the same distance from the origin (see the two dashed segments of equal length in ).      Arithmetic in  Now we compute. We set the rules of the game so that  nothing changes for real numbers ( principle of permanence ),  the familiar laws of arithmetic — the commutative, associative and distributive laws — still hold, and  .    In practice, this means: compute with as with a variable, and replace by wherever it appears. The following formulas are nothing but the results of this procedure.   Addition and subtraction   For and :  So real and imaginary parts are added or subtracted componentwise.    Because real and imaginary parts are added separately, addition in the complex plane is the familiar addition of arrows: is the fourth vertex of the parallelogram spanned by the arrows from to and to .   Addition and subtraction — algebraically and geometrically   For and , compute the sum and the difference , and interpret both in the complex plane.     The sum is the diagonal of the parallelogram with sides and . The difference is the arrow that leads from to (because ), here moved to the origin; see .   Sum and difference of and : the sum is the diagonal of the parallelogram, the difference is the arrow from to .    Arrows from the origin to , to and to . Dashed lines from and to complete the parallelogram. A dotted arrow leads from to ; a parallel dotted arrow of the same length leads from the origin to .        This leads to one of the most useful observations of this section: because is the arrow from to , is the distance between the points and in the complex plane.   Application: How far apart are two robots? (optional)   The two robots from are at and . Robot A has to bring a package to robot B. How far apart are the two (in a straight line)?    The distance is the modulus of the difference: The robots are  m apart. A nice check: . So the triangle formed by the charging station, A and B satisfies the Pythagorean theorem — it has a right angle at the charging station.     Multiplication   The distributive law and give     You do not need to memorize this formula: multiplying out and substituting always works. What matters, however, is that multiplication does not work componentwise — the real part of the product is not simply .   The powers of repeat   Compute , , , and . What pattern do you see?     Since , the powers repeat in a cycle of four, — for , only the remainder when is divided by matters. In the complex plane, the point moves on by a quarter turn each time: . shows that multiplication by really is a rotation by .     Multiplying out products (optional)   Compute and in algebraic form.    Multiply out and substitute : The first result shows why multiplying componentwise would be wrong: it would have given . In fact, the real part cancels completely: here the product of two numbers with positive real parts is purely imaginary.     An unsolvable quadratic equation   The equation has no real solution: the quadratic formula in its form leads to . Show that and are solutions in .    For , we have , so For , we have , so Both numbers are solutions — and they are conjugates of each other. This is no coincidence. How to find such solutions systematically, instead of just checking them, is the topic of .     A computational example from history: Bombelli's cubic equation   The Italian engineer Rafael Bombelli studied the equation in his book L'Algebra , published in 1572. The formula for solving cubic equations, which was new at the time (Cardano's formula), gives the expression for one solution. It contains the square root of a negative number. In our notation, , because . Bombelli guessed that might be a cube root of .  Verify that and . What is the value of then, and does it really solve the equation?    First the square, then multiply by once more: In the same way, and . So Bombelli's approach gives Check: and . The imaginary parts cancel, and what remains is a perfectly ordinary real solution. It was exactly this experience — complex numbers as a detour to real results — that led to complex numbers being accepted in mathematics.    Before we divide, we need one more observation about the product of a number with its conjugate.   Product with the conjugate   For every , we have     With , we have since .    So the product of a number with its conjugate is always real and nonnegative, for example . Exactly this property makes division easy: you multiply the numerator and the denominator of a fraction by the same number so that the denominator becomes real.   Division   For , multiply the numerator and denominator of the fraction by to make the denominator real: with ( ), we get      Division by multiplying by the conjugate of the denominator   Compute and in algebraic form, and check each result.    In the first fraction, we multiply the numerator and denominator by : Check by multiplying back: .  In the second fraction, we multiply the numerator and denominator by : Check: . So dividing by means multiplying by — a trick that the following application example needs right away.     Application: Impedance of a series RC circuit   In AC circuit analysis, the impedance  , the complex AC resistance, takes the place of the ohmic resistance. Like for direct current, it is the ratio of voltage to current. But it is a complex number, because besides the ratio of the amplitudes it also records how far voltage and current are shifted relative to each other in time ( shows how to read off both).  A resistor has the (real) impedance ; a capacitor with capacitance at angular frequency has the (purely imaginary) impedance . The total impedance of a series circuit ( ) is the sum of the individual impedances — just as for real resistances, except that the addition is now complex.   Series RC circuit: the AC voltage source drives the current first through the resistor and then through the capacitor .    Circuit diagram of a closed circuit. On the left, an AC voltage source, drawn as a circle with a sine wave and labeled . The wire leads along the top through a resistor (a rectangle) and down the right side through a capacitor (two parallel plates) back to the source. All components lie one after the other in a single current path.      For , and , determine the total impedance in algebraic form and its modulus .  For the units, you need , that is, ohm equals second per farad: a capacitor of stores the charge at , so and therefore     First, we convert to algebraic form by multiplying the numerator and denominator by : With and , we get The total impedance is therefore a simple complex addition. Its modulus is The negative imaginary part shows that the circuit is capacitive: the current leads the voltage in phase ( explains the terms capacitive and inductive). In the next subsection, we will see how to read off this phase angle directly from the polar form of .    Now we have everything we need: in , you can add, subtract, multiply and divide (except by ), and the same laws of arithmetic hold as in and . In mathematics, a set of numbers with these properties is called a field . Hence the title of this subsection: is the field of complex numbers.     Representations of complex numbers   Addition is very easy in the algebraic form . Multiplication, on the other hand, quickly becomes tedious: if you compute by multiplying five times, you need patience, and it is easy to make a sign error. And the geometric meaning of multiplication — we saw in that the powers of go around in a circle — remains completely hidden in the formula .  A change of perspective helps. Instead of describing a point by this far to the right, this far up, we say this far from the origin, in this direction — just as a radar does. This leads to the polar form and, with Euler's formula, to the exponential form  . In this form, multiplication becomes surprisingly simple: multiply the moduli, add the angles.    Polar coordinates  A point of the complex plane is determined if we know its distance from the origin and the angle at which it lies as seen from the origin, measured counterclockwise from the positive real axis ( ). We already know the distance: it is the modulus .   Polar coordinates of a complex number   Every complex number can be described uniquely by two polar coordinates :  the radius  , the distance from to the origin;  the angle (the argument ) , the angle between the position vector and the positive real axis.    For , we set and . For , is computed from      Polar coordinates: the point has distance from the origin and lies at the angle to the positive real axis.    A complex plane with a point in the first quadrant. A line segment of length connects the origin to . An arc at the origin marks the angle between the positive real axis and this segment. Dotted lines show the coordinates on the real axis and on the imaginary axis.      The case distinction looks daunting, but it only expresses a simple observation: the arctangent always gives angles between and , that is, directions into the right half-plane. If lies to the left of the imaginary axis, we have to correct by .  For the numbers we work with in this course, there is almost always a simpler way — with no arctangent at all. If you divide by its modulus , you get the normalized number It has modulus , so it lies on the unit circle, in the same direction as — at the same angle . For the standard angles, the multiples of and , shows which number on the unit circle belongs to which angle. This figure is your most important tool for the rest of the chapter; take a moment to study it carefully. Among the colored points, those of the same color are mirror images of each other in the axes: their real and imaginary parts differ only in sign.   The unit circle with the standard angles (inside) and the number of modulus that lies at this angle (outside). Its real part is , its imaginary part .    The unit circle in the complex plane with sixteen marked points, each connected to the origin by a line segment. The angle is written inside, next to each segment; the number in algebraic form is written outside. Black: at , at , at , at . Blue: at and at . Orange: at and at . Green: at and at . In each case, the plus sign of the angle goes with the plus sign of the imaginary part.       Recipe: Reading off polar coordinates from the unit circle    Compute the modulus .  Normalize: form and simplify until the real and imaginary parts look like those in . You often need for this.  Find the normalized number in and read off the angle .  If is not one of the marked numbers, you have to use the arctangent with the case distinction from . Even then, the figure shows between which standard angles must lie — a valuable check.    Reading off polar coordinates from the unit circle   Determine the polar coordinates of with the recipe from .    The modulus is . Normalized: We find this number in in the second quadrant, at the angle . So the polar coordinates are and .  As a check: the point lies above and to the left of the origin, so must lie between and . The case distinction would have given the same result, , only with more effort and more opportunities for mistakes.     One angle per quadrant — and a trap (optional)   Determine the modulus and argument of , , , as well as of and . What does the calculator approach give for ?    The first four numbers all have modulus . Normalized, with : These are the four orange points in , and we read off: The two points on the axes work the same way, only faster: and , so ; and , so .  The trap: for , we have , and — the same value as for . The quotient cannot distinguish between the opposite points and . Only the correction by (the third case of the definition) gives the correct angle .      Polar form and Euler's formula  If you know and , you can read off the real and imaginary parts from the right triangle in : the adjacent side and the opposite side are and .   Trigonometric polar form   From and , you get the real and imaginary parts back by so This representation is called the (trigonometric) polar form of .    For the standard angles, you need neither a calculator nor a table of values: the number is written in outside, next to the angle . You read it off and multiply by — the recipe from , applied backward.   From polar form back to algebraic form (optional)   A complex number has modulus and argument . What is it in algebraic form?    In , the number is written at the angle . Multiplied by the modulus : This is plausible: points into the second quadrant, and indeed the real part is negative and the imaginary part positive. This direction of conversion is the easier one — it needs no case distinction.    The expression appears so often that it deserves a shorthand. In 1748, Leonhard Euler discovered that it is related to the exponential function — one of the most astonishing connections in mathematics.   Euler's formula   The (real) exponential function can be extended to complex arguments. For , Euler's formula holds:     A proof requires power series and goes beyond this course; we use the formula as a computational tool. Geometrically, is the point on the unit circle that lies at the angle ( ), because . So for the standard angles, you can read off directly from .   The number lies on the unit circle at the angle .    The unit circle in the complex plane, with the points , , and marked. Another point, , lies on the circle in the first quadrant; an arc marks the angle , and dotted lines show on the real axis and on the imaginary axis.       Once around the unit circle (optional)   Compute for .    The first four angles lie in ; their values are given in : The angles and do not appear in the figure. But a full turn of leads back to the same point; in general, . So we subtract : You know the number from : it has modulus , and now we also know in which direction it lies. The value for gives the famous identity , known as Euler's identity . It unites the five most important constants of mathematics in one equation.     Exponential form   With Euler's formula, every complex number can be written in exponential form  where and are exactly the polar coordinates of .    Because repeats after a full turn, is also a valid way to write the same number. The exponential form only becomes unique through the convention .  The exponential form is also the natural language of AC engineering, because there, every oscillation is described by exactly two quantities: how large it is and when it reaches its maximum.   Phasors  A sinusoidal AC voltage is determined by its amplitude , its angular frequency and its initial phase . In an AC circuit, all voltages and currents oscillate with the angular frequency of the source; they differ only in amplitude and phase. These two quantities are combined into one complex number, the phasor (also called the complex amplitude ) Its modulus is the amplitude, its argument the phase. The oscillation itself is the real part . Intuitively, is an arrow of length that rotates counterclockwise with angular velocity , and is its shadow on the real axis.  The phasors and of voltage and current satisfy Ohm's law for AC circuits, , with the impedance from . As we will see in , it follows that is the ratio of the amplitudes of voltage and current, and the argument of is the phase of the voltage minus the phase of the current.    Application: The phase angle of an impedance   In , we computed the impedance (in ) of a series RC circuit. Determine its exponential form. What does the argument mean physically?  Electrical engineering has two technical terms for the sign of the argument. A circuit is called capacitive if its impedance has a negative imaginary part, that is, : it behaves like a capacitor with , and the current leads the voltage. It is called inductive if the imaginary part is positive, that is, : it behaves like a coil with inductance and impedance , and the current lags behind the voltage. An old German mnemonic sums this up: With a capacitor, the current runs ahead; with an inductor, it arrives late. Is the circuit from capacitive or inductive?    The modulus is . Normalized, with : In , this number belongs to the angle , so and By , the modulus tells you how strongly the circuit limits the current: it is the ratio of the amplitudes of voltage and current. The argument is the phase angle between voltage and current: the phase of the voltage is smaller than that of the current by , so the current leads the voltage by . Since , the circuit is capacitive — as expected, because apart from the resistor it contains only a capacitor. Both quantities that an electrical engineer wants to know can be read directly from the exponential form — in the algebraic form , you do not see them at first glance.      Computing in exponential form  Now the exponential form pays off. The complex exponential function obeys the same laws of exponents as the real one, in particular . This makes products and quotients almost trivial.   Multiplication and division in exponential form   For and , we have Geometrically, multiplication means: multiply the moduli, add the angles ; division means: divide the moduli, subtract the angles .    This follows directly from the laws of exponents for the exponential function: and .    If the sum of the angles lies outside , subtract or add — this does not change the number.   Product and quotient via the exponential form   Compute and for and , and give both results in algebraic form.    Multiply or divide the moduli, add or subtract the angles; we read off the values of and from : For comparison: in algebraic form (again using ), and — multiplying out and multiplying by the conjugate of the denominator lead to the same result, but with considerably more computation.    Applying the multiplication rule times to the same factor gives a formula for powers: The modulus is raised to the same power, and the angle is multiplied by the exponent.   Powers via the exponential form   Compute and .    First, the exponential form of the base: , and normalized, ; so by , and . Hence where we used and read off .  For the second number, , and normalized, ; in , this is the point at the angle . Hence The sixth power is real — two full turns bring the angle back to the positive real axis. Multiplying out would hardly have let you guess that.     Conjugation in exponential form   For , we have Geometrically, the modulus stays the same, and the sign of the angle is reversed.    This fits the reflection in the real axis from : a point that lies at the angle above the real axis ends up at the angle below it. In this way, can also be confirmed at a glance.   Application: Rotating data points   If we regard a point of the plane as the complex number , then by , multiplication by (modulus , angle ) is exactly a rotation about the origin by the angle : the modulus stays the same, and the angle increases by . Such rotations are needed, for example, when you rotate image data to augment a training data set or convert sensor data to a rotated coordinate system. Rotate the point counterclockwise by and by .    We read off the rotation factors from . For , , so For , , so Check: like , both image points have distance from the origin — a rotation does not change moduli ( ). Incidentally, this also explains why the powers of in go around in a circle: each multiplication by is a quarter turn.   The point , rotated by and by . All three points lie on the circle of radius .    A circle of radius around the origin. On it lie the point in the first quadrant, its image under a rotation by , , and its image under a rotation by , , in the second quadrant. Arrows from the origin lead to all three points; curved arrows show the counterclockwise direction of rotation.         Application: The current in the RC circuit (optional)   An AC voltage with the phasor (amplitude , phase ) is applied to the series RC circuit from with . By Ohm's law for AC circuits ( ), the current phasor is . Determine the amplitude and phase of the current.    Division in exponential form — divide the moduli, subtract the angles: The current has amplitude and phase : it leads the voltage by an eighth of a period, as read off in . In algebraic form, we would have had to divide by and multiply by the conjugate of the denominator; in exponential form, it takes one line.     Application: Superposition of AC voltages (phasors)   Oscillations with the same frequency are superposed by adding their phasors ( ). This is because the real part of a sum is the sum of the real parts:   Let and . Determine the amplitude and phase of the superposed oscillation .    The phasors are and . The sum phasor is Its modulus is ; normalized, . This number is not one of the marked points in — here only the arctangent helps: (first quadrant, so no correction), about . Still, the figure is useful as a check: the imaginary part lies between and , so the angle must lie between and — this is consistent. So , and the superposed oscillation is You can see directly: the amplitude of the sum is not the sum of the amplitudes — phase differences matter, and complex addition automatically takes them into account correctly.    Here the two representations work together: we add in algebraic form and read off amplitude and phase from the exponential form. As a rule of thumb for this whole section: algebraic form for addition and subtraction, exponential form for multiplication, division and powers. If you can switch confidently between the two, you have the most important tools for complex numbers.     Summary     Complex number:  with ; , (both real). In the complex plane, is the point ; real numbers lie on the real axis, .   Modulus and distance:  is the distance from to the origin, the distance between the points and . The numbers with form the circle of radius around the origin.   Conjugation:  is the mirror image of in the real axis; and .   Computing in algebraic form: add and subtract componentwise; to multiply, multiply out and use ; to divide, multiply the numerator and denominator by the conjugate of the denominator.   Polar and exponential form:  with and . Converting with the unit circle ( ): compute , form and read off the angle; in the other direction, read off at the angle and multiply by . Only for other angles do you need with the quadrant correction.   Computing in exponential form: multiply the moduli, add the angles — , , . Multiplication by is a rotation by .   Rule of thumb: algebraic form for addition, exponential form for multiplication, division and powers.   Application: impedances ( , , ) in series add as complex numbers; means capacitive (the current leads), inductive (the current lags). The phasor combines the amplitude and phase of the oscillation ; oscillations with the same frequency are superposed by adding their phasors.      Exercises    Let and . Compute , , and in algebraic form.      For the division, we multiply the numerator and denominator by :       For , determine the real part, the imaginary part, the conjugate and the modulus .     , , , and       Plot and in the complex plane. Determine , and the distance between the two points.     is the point in the second quadrant, the point in the first quadrant. The distance is the modulus of the difference:       Determine the exponential form of .     Normalized, with : In , this number belongs to the angle . Hence       Compute via the exponential form.    We have and, normalized, ; so by , and . Hence (with from the same figure) (Check via the algebraic form: , so .)     "
},
{
  "id": "sec-koerper-der-komplexen-zahlen-2",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#sec-koerper-der-komplexen-zahlen-2",
  "type": "Objectives",
  "number": "1.1",
  "title": "",
  "body": "  After this section, you can    add, subtract, multiply and divide complex numbers in algebraic form;  determine the real part, imaginary part, modulus and conjugate and interpret them in the complex plane — in particular the modulus as the distance from the origin and as the distance between two points;  convert between algebraic form, polar form and exponential form — for the standard angles by normalizing and reading off the unit circle;  compute products, quotients and powers via the exponential form and interpret them geometrically as a rotation combined with a scaling;  read impedances and phasors of AC engineering as complex numbers.   "
},
{
  "id": "ssub-imaginaere-einheit-2",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ssub-imaginaere-einheit-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "imaginary unit "
},
{
  "id": "def-komplexe-zahlen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-komplexe-zahlen",
  "type": "Definition",
  "number": "1.1.1",
  "title": "Complex numbers.",
  "body": " Complex numbers   A complex number is a number of the form with real numbers and . The set of all complex numbers is    "
},
{
  "id": "ex-quadratwurzeln-negativer-zahlen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-quadratwurzeln-negativer-zahlen",
  "type": "Example",
  "number": "1.1.2",
  "title": "The equation <span class=\"process-math\">\\(z^2=-9\\)<\/span> becomes solvable.",
  "body": " The equation becomes solvable   Show that and solve the equation . In the same way, find two solutions of .    We compute with as with a variable and replace by at the end: In the same way, and ; so the equation has the two solutions and . Likewise, and solve the equation .  The numbers and are complex numbers in the sense of the definition, each with . So equations that we could not solve in suddenly have solutions in — two of them, in fact.   "
},
{
  "id": "def-realteil-imaginaerteil",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-realteil-imaginaerteil",
  "type": "Definition",
  "number": "1.1.3",
  "title": "Real and imaginary parts; equality.",
  "body": " Real and imaginary parts; equality   For , is called the real part and the imaginary part of . Two complex numbers are equal if and only if their real parts and their imaginary parts agree.   "
},
{
  "id": "ex-realteil-imaginaerteil",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-realteil-imaginaerteil",
  "type": "Example",
  "number": "1.1.4",
  "title": "Reading off real and imaginary parts.",
  "body": " Reading off real and imaginary parts   Determine the real and imaginary parts of , , and .      , .  Since , we have and — the minus sign belongs to the imaginary part.  is not written in the order real part first. Rearranged, , so and .  Since , we have and .     "
},
{
  "id": "ex-gleichheit-komplexer-zahlen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-gleichheit-komplexer-zahlen",
  "type": "Example",
  "number": "1.1.5",
  "title": "One complex equation contains two real equations.",
  "body": " One complex equation contains two real equations   Determine the real numbers and such that holds.    On the left is a complex number with real part and imaginary part ; on the right, one with real part and imaginary part . The two are equal if and only if both parts agree: So a single equation between complex numbers gives two equations between real numbers. You will often use such a comparison of real and imaginary parts.   "
},
{
  "id": "rem-reelle-und-imaginaere-zahlen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#rem-reelle-und-imaginaere-zahlen",
  "type": "Remark",
  "number": "1.1.6",
  "title": "Real and purely imaginary numbers.",
  "body": " Real and purely imaginary numbers  Every real number can be written as , that is, as a complex number with imaginary part . In this sense, : the complex numbers extend the real numbers; they do not replace them. The other extreme is complex numbers with real part , that is, numbers of the form ; they are called (purely) imaginary — like and from the examples above.  "
},
{
  "id": "def-gausssche-zahlenebene",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-gausssche-zahlenebene",
  "type": "Definition",
  "number": "1.1.7",
  "title": "Complex plane.",
  "body": " Complex plane   In the complex plane , the complex number is represented as the point with Cartesian coordinates . The horizontal axis is called the real axis , the vertical axis the imaginary axis .   "
},
{
  "id": "fig-gausssche-zahlenebene",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#fig-gausssche-zahlenebene",
  "type": "Figure",
  "number": "1.1.8",
  "title": "",
  "body": " The complex plane: the number is the point with coordinates .    A coordinate system with a horizontal real axis and a vertical imaginary axis. The real axis has a tick mark at , the imaginary axis at . The point lies in the first quadrant; dotted lines connect it to on the real axis and to on the imaginary axis.     "
},
{
  "id": "ex-punkte-zahlenebene",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-punkte-zahlenebene",
  "type": "Example",
  "number": "1.1.9",
  "title": "Plotting complex numbers (optional).",
  "body": " Plotting complex numbers (optional)   Plot , , , , and in the complex plane. Where are the real numbers, and where are the purely imaginary ones?    Each number becomes the point , so , , , , and ; see . The sign of the real part decides between left and right, the sign of the imaginary part between up and down.   The numbers in the complex plane.    A coordinate grid from to horizontally and from to vertically. The figure marks at in the first quadrant, at in the second, at in the third, at in the fourth quadrant, at on the real axis and at on the imaginary axis.      The real number lies on the real axis ( -axis), the purely imaginary number on the imaginary axis ( -axis). So the real axis is the familiar number line — the complex plane adds a second direction to it.   "
},
{
  "id": "ex-mengen-zahlenebene",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-mengen-zahlenebene",
  "type": "Example",
  "number": "1.1.11",
  "title": "Conditions on the real and imaginary parts as pictures.",
  "body": " Conditions on the real and imaginary parts as pictures   Where in the complex plane are all complex numbers with  ,  ,  ,  ?        All points with arbitrary : the vertical line through , parallel to the imaginary axis.  All points : the horizontal line through , parallel to the real axis.  All points above the real axis: the upper half-plane, without the real axis itself.  All points : the line that bisects the first and third quadrants, that is, the numbers with .    Conditions on the real and imaginary parts describe lines and half-planes. With the modulus, which we introduce next, circles come in as well.   "
},
{
  "id": "def-betrag-komplex",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-betrag-komplex",
  "type": "Definition",
  "number": "1.1.12",
  "title": "Modulus of a complex number.",
  "body": " Modulus of a complex number   The modulus (or absolute value ) of is    "
},
{
  "id": "fig-betrag-pythagoras",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#fig-betrag-pythagoras",
  "type": "Figure",
  "number": "1.1.13",
  "title": "",
  "body": " The modulus is the hypotenuse of the right triangle with legs and , that is, the distance from to the origin.    A right triangle in the complex plane with vertices at the origin, at and at . The horizontal leg on the real axis has length , the vertical leg has length , and the hypotenuse from the origin to has length .     "
},
{
  "id": "ex-betrag-berechnen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-betrag-berechnen",
  "type": "Example",
  "number": "1.1.14",
  "title": "Computing moduli.",
  "body": " Computing moduli   Determine , , , and .     For , we get the absolute value of a real number, as expected. The last number has modulus , so it lies on the circle of radius around the origin, the unit circle . Such numbers play a leading role in .   "
},
{
  "id": "ex-kreis-betrag-fuenf",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-kreis-betrag-fuenf",
  "type": "Example",
  "number": "1.1.15",
  "title": "All numbers with modulus 5.",
  "body": " All numbers with modulus 5   Which complex numbers with integer real and imaginary parts have modulus ? Where do they lie in the complex plane?    We are looking for integers with , that is, . The squares up to are , and exactly two combinations add up to : and (each in both orders). With all choices of signs, we get the twelve numbers All of them have distance from the origin and therefore lie on the circle of radius around ; see .   The twelve numbers with integer real and imaginary parts and modulus lie on the circle of radius around the origin.    A circle of radius around the origin of the complex plane. Twelve points are marked on it: the four points and on the axes and the eight points and . The points , , and are labeled.      In general, the numbers with form the circle of radius around the origin.   "
},
{
  "id": "ex-anwendung-lagerroboter-betrag",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-lagerroboter-betrag",
  "type": "Example",
  "number": "1.1.17",
  "title": "Application: Positions in a warehouse (optional).",
  "body": " Application: Positions in a warehouse (optional)   Autonomous transport robots move around a logistics warehouse. The warehouse control system describes each position in meters relative to the charging station at the origin; the real axis points east, the imaginary axis north. A position is then simply a complex number. Python, for example, has the built-in data type complex for this, written with j as in electrical engineering: -12+9j .  Robot A is at , robot B at ( ). Which of the two is closer to the charging station?   Positions of two transport robots relative to the charging station (in meters).    A complex plane with the charging station at the origin. The real axis is labeled East, the imaginary axis North. Robot A is at at the upper left, robot B at at the upper right; dotted lines show their coordinates on both axes.        The distance to the charging station is the distance from the origin, that is, the modulus: At a straight-line distance of  m, robot A is closer to the charging station than robot B at  m. (In Python, abs(-12+9j) returns exactly this modulus, 15.0 .)   "
},
{
  "id": "def-komplexe-konjugation",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-komplexe-konjugation",
  "type": "Definition",
  "number": "1.1.19",
  "title": "Complex conjugation.",
  "body": " Complex conjugation   For , the number is called the complex conjugate of . In the complex plane, is obtained from by reflection in the real axis.   "
},
{
  "id": "fig-komplexe-konjugation",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#fig-komplexe-konjugation",
  "type": "Figure",
  "number": "1.1.20",
  "title": "",
  "body": " The conjugate is the mirror image of in the real axis.    A coordinate system with a horizontal real axis ( ) and a vertical imaginary axis ( ). The figure shows the point , the origin, a dashed line from the origin to , and the point , the reflection in the real axis, which is also connected to the origin by a dashed line.     "
},
{
  "id": "ex-konjugierte-bestimmen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-konjugierte-bestimmen",
  "type": "Example",
  "number": "1.1.21",
  "title": "Conjugating means reflecting (optional).",
  "body": " Conjugating means reflecting (optional)   Determine the conjugates of , , and , and describe what happens in the complex plane.    Only the sign of the imaginary part changes: The points and move to the other side of the real axis. The purely imaginary number jumps along the imaginary axis from to . The real number lies on the mirror axis and therefore stays where it is.   "
},
{
  "id": "ex-betrag-konjugierte",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-betrag-konjugierte",
  "type": "Example",
  "number": "1.1.22",
  "title": "Conjugation does not change the modulus (optional).",
  "body": " Conjugation does not change the modulus (optional)   Verify that for every complex number . Also explain this geometrically.    With , we have , so Geometrically: the origin lies on the mirror axis, and a reflection does not change distances — so and have the same distance from the origin (see the two dashed segments of equal length in ).   "
},
{
  "id": "ssub-grundrechenarten-2",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ssub-grundrechenarten-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "principle of permanence "
},
{
  "id": "def-addition-subtraktion-komplex",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-addition-subtraktion-komplex",
  "type": "Definition",
  "number": "1.1.23",
  "title": "Addition and subtraction.",
  "body": " Addition and subtraction   For and :  So real and imaginary parts are added or subtracted componentwise.   "
},
{
  "id": "ex-addition-subtraktion",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-addition-subtraktion",
  "type": "Example",
  "number": "1.1.24",
  "title": "Addition and subtraction — algebraically and geometrically.",
  "body": " Addition and subtraction — algebraically and geometrically   For and , compute the sum and the difference , and interpret both in the complex plane.     The sum is the diagonal of the parallelogram with sides and . The difference is the arrow that leads from to (because ), here moved to the origin; see .   Sum and difference of and : the sum is the diagonal of the parallelogram, the difference is the arrow from to .    Arrows from the origin to , to and to . Dashed lines from and to complete the parallelogram. A dotted arrow leads from to ; a parallel dotted arrow of the same length leads from the origin to .       "
},
{
  "id": "ssub-grundrechenarten-7",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ssub-grundrechenarten-7",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "distance "
},
{
  "id": "ex-anwendung-lagerroboter-abstand",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-lagerroboter-abstand",
  "type": "Example",
  "number": "1.1.26",
  "title": "Application: How far apart are two robots? (optional).",
  "body": " Application: How far apart are two robots? (optional)   The two robots from are at and . Robot A has to bring a package to robot B. How far apart are the two (in a straight line)?    The distance is the modulus of the difference: The robots are  m apart. A nice check: . So the triangle formed by the charging station, A and B satisfies the Pythagorean theorem — it has a right angle at the charging station.   "
},
{
  "id": "def-multiplikation-komplex",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-multiplikation-komplex",
  "type": "Definition",
  "number": "1.1.27",
  "title": "Multiplication.",
  "body": " Multiplication   The distributive law and give    "
},
{
  "id": "ex-potenzen-imaginaere-einheit",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-potenzen-imaginaere-einheit",
  "type": "Example",
  "number": "1.1.28",
  "title": "The powers of <span class=\"process-math\">\\(\\ii\\)<\/span> repeat.",
  "body": " The powers of repeat   Compute , , , and . What pattern do you see?     Since , the powers repeat in a cycle of four, — for , only the remainder when is divided by matters. In the complex plane, the point moves on by a quarter turn each time: . shows that multiplication by really is a rotation by .   "
},
{
  "id": "ex-multiplikation",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-multiplikation",
  "type": "Example",
  "number": "1.1.29",
  "title": "Multiplying out products (optional).",
  "body": " Multiplying out products (optional)   Compute and in algebraic form.    Multiply out and substitute : The first result shows why multiplying componentwise would be wrong: it would have given . In fact, the real part cancels completely: here the product of two numbers with positive real parts is purely imaginary.   "
},
{
  "id": "ex-quadratische-gleichung-probe",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-quadratische-gleichung-probe",
  "type": "Example",
  "number": "1.1.30",
  "title": "An “unsolvable” quadratic equation.",
  "body": " An unsolvable quadratic equation   The equation has no real solution: the quadratic formula in its form leads to . Show that and are solutions in .    For , we have , so For , we have , so Both numbers are solutions — and they are conjugates of each other. This is no coincidence. How to find such solutions systematically, instead of just checking them, is the topic of .   "
},
{
  "id": "ex-bombelli-kubische-gleichung",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-bombelli-kubische-gleichung",
  "type": "Example",
  "number": "1.1.31",
  "title": "A computational example from history: Bombelli’s cubic equation.",
  "body": " A computational example from history: Bombelli's cubic equation   The Italian engineer Rafael Bombelli studied the equation in his book L'Algebra , published in 1572. The formula for solving cubic equations, which was new at the time (Cardano's formula), gives the expression for one solution. It contains the square root of a negative number. In our notation, , because . Bombelli guessed that might be a cube root of .  Verify that and . What is the value of then, and does it really solve the equation?    First the square, then multiply by once more: In the same way, and . So Bombelli's approach gives Check: and . The imaginary parts cancel, and what remains is a perfectly ordinary real solution. It was exactly this experience — complex numbers as a detour to real results — that led to complex numbers being accepted in mathematics.   "
},
{
  "id": "thm-zzstern-betragsquadrat",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#thm-zzstern-betragsquadrat",
  "type": "Theorem",
  "number": "1.1.32",
  "title": "Product with the conjugate.",
  "body": " Product with the conjugate   For every , we have     With , we have since .   "
},
{
  "id": "def-division-komplex",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-division-komplex",
  "type": "Definition",
  "number": "1.1.33",
  "title": "Division.",
  "body": " Division   For , multiply the numerator and denominator of the fraction by to make the denominator real: with ( ), we get    "
},
{
  "id": "ex-division-schrittweise",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-division-schrittweise",
  "type": "Example",
  "number": "1.1.34",
  "title": "Division by multiplying by the conjugate of the denominator.",
  "body": " Division by multiplying by the conjugate of the denominator   Compute and in algebraic form, and check each result.    In the first fraction, we multiply the numerator and denominator by : Check by multiplying back: .  In the second fraction, we multiply the numerator and denominator by : Check: . So dividing by means multiplying by — a trick that the following application example needs right away.   "
},
{
  "id": "ex-anwendung-impedanz-rc-reihenschaltung",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-impedanz-rc-reihenschaltung",
  "type": "Example",
  "number": "1.1.35",
  "title": "Application: Impedance of a series RC circuit.",
  "body": " Application: Impedance of a series RC circuit   In AC circuit analysis, the impedance  , the complex AC resistance, takes the place of the ohmic resistance. Like for direct current, it is the ratio of voltage to current. But it is a complex number, because besides the ratio of the amplitudes it also records how far voltage and current are shifted relative to each other in time ( shows how to read off both).  A resistor has the (real) impedance ; a capacitor with capacitance at angular frequency has the (purely imaginary) impedance . The total impedance of a series circuit ( ) is the sum of the individual impedances — just as for real resistances, except that the addition is now complex.   Series RC circuit: the AC voltage source drives the current first through the resistor and then through the capacitor .    Circuit diagram of a closed circuit. On the left, an AC voltage source, drawn as a circle with a sine wave and labeled . The wire leads along the top through a resistor (a rectangle) and down the right side through a capacitor (two parallel plates) back to the source. All components lie one after the other in a single current path.      For , and , determine the total impedance in algebraic form and its modulus .  For the units, you need , that is, ohm equals second per farad: a capacitor of stores the charge at , so and therefore     First, we convert to algebraic form by multiplying the numerator and denominator by : With and , we get The total impedance is therefore a simple complex addition. Its modulus is The negative imaginary part shows that the circuit is capacitive: the current leads the voltage in phase ( explains the terms capacitive and inductive). In the next subsection, we will see how to read off this phase angle directly from the polar form of .   "
},
{
  "id": "ssub-grundrechenarten-21",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ssub-grundrechenarten-21",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "field "
},
{
  "id": "sub-darstellungsformen-2-2",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#sub-darstellungsformen-2-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "polar form exponential form "
},
{
  "id": "def-polarform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-polarform",
  "type": "Definition",
  "number": "1.1.37",
  "title": "Polar coordinates of a complex number.",
  "body": " Polar coordinates of a complex number   Every complex number can be described uniquely by two polar coordinates :  the radius  , the distance from to the origin;  the angle (the argument ) , the angle between the position vector and the positive real axis.    For , we set and . For , is computed from    "
},
{
  "id": "fig-polarkoordinaten",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#fig-polarkoordinaten",
  "type": "Figure",
  "number": "1.1.38",
  "title": "",
  "body": " Polar coordinates: the point has distance from the origin and lies at the angle to the positive real axis.    A complex plane with a point in the first quadrant. A line segment of length connects the origin to . An arc at the origin marks the angle between the positive real axis and this segment. Dotted lines show the coordinates on the real axis and on the imaginary axis.     "
},
{
  "id": "ssub-polarkoordinaten-6",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ssub-polarkoordinaten-6",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "normalized "
},
{
  "id": "fig-einheitskreis-standardwinkel",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#fig-einheitskreis-standardwinkel",
  "type": "Figure",
  "number": "1.1.39",
  "title": "",
  "body": " The unit circle with the standard angles (inside) and the number of modulus that lies at this angle (outside). Its real part is , its imaginary part .    The unit circle in the complex plane with sixteen marked points, each connected to the origin by a line segment. The angle is written inside, next to each segment; the number in algebraic form is written outside. Black: at , at , at , at . Blue: at and at . Orange: at and at . Green: at and at . In each case, the plus sign of the angle goes with the plus sign of the imaginary part.     "
},
{
  "id": "rem-umrechnen-einheitskreis",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#rem-umrechnen-einheitskreis",
  "type": "Remark",
  "number": "1.1.40",
  "title": "Recipe: Reading off polar coordinates from the unit circle.",
  "body": " Recipe: Reading off polar coordinates from the unit circle    Compute the modulus .  Normalize: form and simplify until the real and imaginary parts look like those in . You often need for this.  Find the normalized number in and read off the angle .  If is not one of the marked numbers, you have to use the arctangent with the case distinction from . Even then, the figure shows between which standard angles must lie — a valuable check.  "
},
{
  "id": "ex-algebraisch-zu-polar",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-algebraisch-zu-polar",
  "type": "Example",
  "number": "1.1.41",
  "title": "Reading off polar coordinates from the unit circle.",
  "body": " Reading off polar coordinates from the unit circle   Determine the polar coordinates of with the recipe from .    The modulus is . Normalized: We find this number in in the second quadrant, at the angle . So the polar coordinates are and .  As a check: the point lies above and to the left of the origin, so must lie between and . The case distinction would have given the same result, , only with more effort and more opportunities for mistakes.   "
},
{
  "id": "ex-winkel-vier-quadranten",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-winkel-vier-quadranten",
  "type": "Example",
  "number": "1.1.42",
  "title": "One angle per quadrant — and a trap (optional).",
  "body": " One angle per quadrant — and a trap (optional)   Determine the modulus and argument of , , , as well as of and . What does the calculator approach give for ?    The first four numbers all have modulus . Normalized, with : These are the four orange points in , and we read off: The two points on the axes work the same way, only faster: and , so ; and , so .  The trap: for , we have , and — the same value as for . The quotient cannot distinguish between the opposite points and . Only the correction by (the third case of the definition) gives the correct angle .   "
},
{
  "id": "def-trigonometrische-polarform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-trigonometrische-polarform",
  "type": "Definition",
  "number": "1.1.43",
  "title": "Trigonometric polar form.",
  "body": " Trigonometric polar form   From and , you get the real and imaginary parts back by so This representation is called the (trigonometric) polar form of .   "
},
{
  "id": "ex-polar-zu-algebraisch",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-polar-zu-algebraisch",
  "type": "Example",
  "number": "1.1.44",
  "title": "From polar form back to algebraic form (optional).",
  "body": " From polar form back to algebraic form (optional)   A complex number has modulus and argument . What is it in algebraic form?    In , the number is written at the angle . Multiplied by the modulus : This is plausible: points into the second quadrant, and indeed the real part is negative and the imaginary part positive. This direction of conversion is the easier one — it needs no case distinction.   "
},
{
  "id": "thm-eulersche-formel",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#thm-eulersche-formel",
  "type": "Theorem",
  "number": "1.1.45",
  "title": "Euler’s formula.",
  "body": " Euler's formula   The (real) exponential function can be extended to complex arguments. For , Euler's formula holds:    "
},
{
  "id": "fig-einheitskreis-euler",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#fig-einheitskreis-euler",
  "type": "Figure",
  "number": "1.1.46",
  "title": "",
  "body": " The number lies on the unit circle at the angle .    The unit circle in the complex plane, with the points , , and marked. Another point, , lies on the circle in the first quadrant; an arc marks the angle , and dotted lines show on the real axis and on the imaginary axis.     "
},
{
  "id": "ex-werte-euler-einheitskreis",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-werte-euler-einheitskreis",
  "type": "Example",
  "number": "1.1.47",
  "title": "Once around the unit circle (optional).",
  "body": " Once around the unit circle (optional)   Compute for .    The first four angles lie in ; their values are given in : The angles and do not appear in the figure. But a full turn of leads back to the same point; in general, . So we subtract : You know the number from : it has modulus , and now we also know in which direction it lies. The value for gives the famous identity , known as Euler's identity . It unites the five most important constants of mathematics in one equation.   "
},
{
  "id": "def-exponentialform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-exponentialform",
  "type": "Definition",
  "number": "1.1.48",
  "title": "Exponential form.",
  "body": " Exponential form   With Euler's formula, every complex number can be written in exponential form  where and are exactly the polar coordinates of .   "
},
{
  "id": "rem-phasoren",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#rem-phasoren",
  "type": "Remark",
  "number": "1.1.49",
  "title": "Phasors.",
  "body": " Phasors  A sinusoidal AC voltage is determined by its amplitude , its angular frequency and its initial phase . In an AC circuit, all voltages and currents oscillate with the angular frequency of the source; they differ only in amplitude and phase. These two quantities are combined into one complex number, the phasor (also called the complex amplitude ) Its modulus is the amplitude, its argument the phase. The oscillation itself is the real part . Intuitively, is an arrow of length that rotates counterclockwise with angular velocity , and is its shadow on the real axis.  The phasors and of voltage and current satisfy Ohm's law for AC circuits, , with the impedance from . As we will see in , it follows that is the ratio of the amplitudes of voltage and current, and the argument of is the phase of the voltage minus the phase of the current.  "
},
{
  "id": "ex-anwendung-impedanz-phasenwinkel",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-impedanz-phasenwinkel",
  "type": "Example",
  "number": "1.1.50",
  "title": "Application: The phase angle of an impedance.",
  "body": " Application: The phase angle of an impedance   In , we computed the impedance (in ) of a series RC circuit. Determine its exponential form. What does the argument mean physically?  Electrical engineering has two technical terms for the sign of the argument. A circuit is called capacitive if its impedance has a negative imaginary part, that is, : it behaves like a capacitor with , and the current leads the voltage. It is called inductive if the imaginary part is positive, that is, : it behaves like a coil with inductance and impedance , and the current lags behind the voltage. An old German mnemonic sums this up: With a capacitor, the current runs ahead; with an inductor, it arrives late. Is the circuit from capacitive or inductive?    The modulus is . Normalized, with : In , this number belongs to the angle , so and By , the modulus tells you how strongly the circuit limits the current: it is the ratio of the amplitudes of voltage and current. The argument is the phase angle between voltage and current: the phase of the voltage is smaller than that of the current by , so the current leads the voltage by . Since , the circuit is capacitive — as expected, because apart from the resistor it contains only a capacitor. Both quantities that an electrical engineer wants to know can be read directly from the exponential form — in the algebraic form , you do not see them at first glance.   "
},
{
  "id": "thm-multiplikation-division-exponentialform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#thm-multiplikation-division-exponentialform",
  "type": "Theorem",
  "number": "1.1.51",
  "title": "Multiplication and division in exponential form.",
  "body": " Multiplication and division in exponential form   For and , we have Geometrically, multiplication means: multiply the moduli, add the angles ; division means: divide the moduli, subtract the angles .    This follows directly from the laws of exponents for the exponential function: and .   "
},
{
  "id": "ex-multiplikation-exponentialform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-multiplikation-exponentialform",
  "type": "Example",
  "number": "1.1.52",
  "title": "Product and quotient via the exponential form.",
  "body": " Product and quotient via the exponential form   Compute and for and , and give both results in algebraic form.    Multiply or divide the moduli, add or subtract the angles; we read off the values of and from : For comparison: in algebraic form (again using ), and — multiplying out and multiplying by the conjugate of the denominator lead to the same result, but with considerably more computation.   "
},
{
  "id": "ex-potenz-exponentialform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-potenz-exponentialform",
  "type": "Example",
  "number": "1.1.53",
  "title": "Powers via the exponential form.",
  "body": " Powers via the exponential form   Compute and .    First, the exponential form of the base: , and normalized, ; so by , and . Hence where we used and read off .  For the second number, , and normalized, ; in , this is the point at the angle . Hence The sixth power is real — two full turns bring the angle back to the positive real axis. Multiplying out would hardly have let you guess that.   "
},
{
  "id": "prop-konjugation-exponentialform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#prop-konjugation-exponentialform",
  "type": "Proposition",
  "number": "1.1.54",
  "title": "Conjugation in exponential form.",
  "body": " Conjugation in exponential form   For , we have Geometrically, the modulus stays the same, and the sign of the angle is reversed.   "
},
{
  "id": "ex-anwendung-drehung-datenpunkte",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-drehung-datenpunkte",
  "type": "Example",
  "number": "1.1.55",
  "title": "Application: Rotating data points.",
  "body": " Application: Rotating data points   If we regard a point of the plane as the complex number , then by , multiplication by (modulus , angle ) is exactly a rotation about the origin by the angle : the modulus stays the same, and the angle increases by . Such rotations are needed, for example, when you rotate image data to augment a training data set or convert sensor data to a rotated coordinate system. Rotate the point counterclockwise by and by .    We read off the rotation factors from . For , , so For , , so Check: like , both image points have distance from the origin — a rotation does not change moduli ( ). Incidentally, this also explains why the powers of in go around in a circle: each multiplication by is a quarter turn.   The point , rotated by and by . All three points lie on the circle of radius .    A circle of radius around the origin. On it lie the point in the first quadrant, its image under a rotation by , , and its image under a rotation by , , in the second quadrant. Arrows from the origin lead to all three points; curved arrows show the counterclockwise direction of rotation.       "
},
{
  "id": "ex-anwendung-strom-rc-glied",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-strom-rc-glied",
  "type": "Example",
  "number": "1.1.57",
  "title": "Application: The current in the RC circuit (optional).",
  "body": " Application: The current in the RC circuit (optional)   An AC voltage with the phasor (amplitude , phase ) is applied to the series RC circuit from with . By Ohm's law for AC circuits ( ), the current phasor is . Determine the amplitude and phase of the current.    Division in exponential form — divide the moduli, subtract the angles: The current has amplitude and phase : it leads the voltage by an eighth of a period, as read off in . In algebraic form, we would have had to divide by and multiply by the conjugate of the denominator; in exponential form, it takes one line.   "
},
{
  "id": "ex-anwendung-phasor-additionstheorem",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-phasor-additionstheorem",
  "type": "Example",
  "number": "1.1.58",
  "title": "Application: Superposition of AC voltages (phasors).",
  "body": " Application: Superposition of AC voltages (phasors)   Oscillations with the same frequency are superposed by adding their phasors ( ). This is because the real part of a sum is the sum of the real parts:   Let and . Determine the amplitude and phase of the superposed oscillation .    The phasors are and . The sum phasor is Its modulus is ; normalized, . This number is not one of the marked points in — here only the arctangent helps: (first quadrant, so no correction), about . Still, the figure is useful as a check: the imaginary part lies between and , so the angle must lie between and — this is consistent. So , and the superposed oscillation is You can see directly: the amplitude of the sum is not the sum of the amplitudes — phase differences matter, and complex addition automatically takes them into account correctly.   "
},
{
  "id": "sub-zusammenfassung-1-1-2",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#sub-zusammenfassung-1-1-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Complex number: Modulus and distance: Conjugation: Computing in algebraic form: Polar and exponential form: Computing in exponential form: Rule of thumb: Application: "
},
{
  "id": "exercise-buch-grundrechenarten",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#exercise-buch-grundrechenarten",
  "type": "Exercise",
  "number": "1.1.4.1",
  "title": "",
  "body": "  Let and . Compute , , and in algebraic form.      For the division, we multiply the numerator and denominator by :    "
},
{
  "id": "exercise-buch-betrag-konjugierte",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#exercise-buch-betrag-konjugierte",
  "type": "Exercise",
  "number": "1.1.4.2",
  "title": "",
  "body": "  For , determine the real part, the imaginary part, the conjugate and the modulus .     , , , and    "
},
{
  "id": "exercise-buch-abstand-zahlenebene",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#exercise-buch-abstand-zahlenebene",
  "type": "Exercise",
  "number": "1.1.4.3",
  "title": "",
  "body": "  Plot and in the complex plane. Determine , and the distance between the two points.     is the point in the second quadrant, the point in the first quadrant. The distance is the modulus of the difference:    "
},
{
  "id": "exercise-buch-exponentialform-umrechnen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#exercise-buch-exponentialform-umrechnen",
  "type": "Exercise",
  "number": "1.1.4.4",
  "title": "",
  "body": "  Determine the exponential form of .     Normalized, with : In , this number belongs to the angle . Hence    "
},
{
  "id": "exercise-buch-potenz-exponentialform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#exercise-buch-potenz-exponentialform",
  "type": "Exercise",
  "number": "1.1.4.5",
  "title": "",
  "body": "  Compute via the exponential form.    We have and, normalized, ; so by , and . Hence (with from the same figure) (Check via the algebraic form: , so .)   "
},
{
  "id": "sec-algebraische-gleichungen-anwendungen",
  "level": "1",
  "url": "sec-algebraische-gleichungen-anwendungen.html",
  "type": "Section",
  "number": "1.2",
  "title": "Algebraic equations and applications of complex numbers",
  "body": " Algebraic equations and applications of complex numbers    After this section, you can    determine all solutions of a binomial equation and interpret them as a regular -gon in the complex plane;  state the th roots of unity and explain their role in the discrete Fourier transform;  solve quadratic equations in — with a negative discriminant, with complex coefficients and, by substitution, also biquadratic equations;  state the fundamental theorem of algebra and factor a polynomial into linear factors when one root is known;  factor real polynomials into irreducible real factors by combining pairs of complex conjugate roots;  translate a technical condition on an impedance or a filter into a real algebraic equation and solve it.     If you ask Python for the roots of the polynomial — with numpy.roots([1, -1, 1, -1]) — you get back not only the expected , but also the two numbers 1j and -1j (up to tiny rounding errors). The j is the engineering notation for , and this is not a programming error: numpy.roots looks for roots in from the start — and with good reason, because only there does the question always have a complete answer. A polynomial of degree has exactly roots in (counted with multiplicity). And even if you need only real results in the end — such as the real factorization — the fastest route leads through the complex roots.  We begin with the binomial equations  , whose solutions form a regular -gon and which are at the heart of the discrete Fourier transform. With them, the quadratic formula becomes usable in without restrictions. Then comes the fundamental theorem of algebra with the factorization into linear factors. Finally, examples from AC engineering show you how a complex impedance or a filter leads to a perfectly ordinary real equation. Keep the exponential form from at hand for this — it is the most important tool of this section.    Algebraic equations over   The starting point of this chapter was the equation , which has no solution in . With the imaginary unit , this equation can be solved in — and it even has two solutions, and . In , we also checked that solve the equation . To be honest, though, that was a bit of a cheat: the solutions were simply handed to us, and we only substituted them. We did not find them. We now make up for this systematically — starting with the simplest equations of all, where the exponential form shows its full strength.    Binomial equations of degree  How many solutions does the equation have? In , you find and . In , two more are added, because and as well. The four solutions lie on the circle of radius and form a square. This is no coincidence, but a general pattern.   Binomial equation of degree , roots   For and , the equation is called the binomial equation of degree . Its solutions are also called the roots of .    Watch out: a common trap. In , the symbol for denotes exactly one number, namely the nonnegative solution of . In , there is no such natural choice — both solutions of , that is, and , have the same claim to the name square root of . If you forget this and still apply the familiar rules for roots, you can prove astonishing things: The error lies in the equals sign with the question mark: the rule holds only for . We therefore use the radical sign only for nonnegative real numbers and otherwise speak of the solutions of . (Bombelli simply read as without worrying about it, and so did we in . This is a convenient shorthand for one of the two solutions of , but strictly speaking it is not unique: would have the same claim.)   Solution formula for binomial equations   Let . The equation has exactly distinct solutions in , namely In the complex plane, these numbers lie on a circle of radius around the origin and form a regular -gon there. For this reason, is also called a cyclotomic equation (from the Greek for circle-dividing ).    We write with . Then , and means: the moduli and the angles of both sides agree, where angles are determined only up to multiples of . So , that is, , and for some , that is, . For , these angles give distinct numbers, because two of them differ by with , and this is not a multiple of ; gives the angle of again (plus ), so nothing new.    The formula looks technical, but the recipe behind it is simple:  bring into exponential form , preferably with the recipe from ;  take the th (real) root of the modulus and divide the angle by — this gives the first solution ;  the other solutions arise by rotating the angle further, times, by each time.  Why exactly ? If you rotate a solution further by this angle, its th power rotates by , that is, by a full turn — and ends up at again.   Five solutions, one pentagon   Determine all solutions of .     Step 1:  ; normalized, . So by , and .   Step 2:  and , so .   Step 3: Rotate further by each time: with the angles . The solution for is — the only real solution, which you would have found even without complex numbers. The five solutions form a regular pentagon ( ).     The five solutions of form a regular pentagon on the circle of radius around the origin.    A coordinate system with a real and an imaginary axis and a circle of radius 2 around the origin. Five evenly spaced points are marked on this circle ( apart, at the angles ); they form a regular pentagon. One of the points lies on the negative real axis.       The third roots of unity   Determine all solutions of .    With , we have and . By with : so , and (we subtracted to land in ). In algebraic form, read off from : The numbers are called the third roots of unity ; in general, the solutions of are called the th roots of unity . They form an equilateral triangle on the unit circle, with one vertex at . Check for : by the laws of exponents, . If you do not trust the exponential form yet, you can also verify this in algebraic form: and , because is the conjugate of .    By the way, there is a famous story behind the roots of unity. The ancient Greeks could construct the regular triangle, square, pentagon and 15-gon with compass and straightedge. Whether further regular polygons could be added (apart from simply doubling the number of vertices) remained open for about two thousand years — until the 18-year-old Carl Friedrich Gauss showed in March 1796 that the regular 17-gon can also be constructed. His tool: the equation , that is, exactly the cyclotomic equation we are discussing here. The discovery is said to have persuaded him to study mathematics instead of languages. (The complete answer to the question of exactly which -gons can be constructed was given by Gauss in 1801 and Pierre Wantzel in 1837.)   Roots of a nonreal number   Determine all solutions of in algebraic form, and check your result.    The number has modulus and, by , lies at the angle , so . The first solution has the angle ; the second is rotated further by , to or (after subtracting ) . Read off from the figure: Check: . As in the real case, the two square roots differ only in sign — they lie opposite each other on the circle.    The roots of unity (the case ) are not just material for geometry and history: they appear wherever periodic processes are analyzed digitally.   Application: th roots of unity and the discrete Fourier transform   The th roots of unity from are more than a pretty geometric figure: they form the basis of the discrete Fourier transform (DFT) , one of the most important tools of digital signal processing and hence also of data science (spectral analysis of time series, image and audio compression, fast convolution in neural networks). The DFT decomposes a sampled signal, that is, values measured at equal time intervals, into contributions of different frequencies: the modulus indicates how strongly an oscillation with exactly periods per measurement window is present in the data. For a sequence of measured values , the DFT is defined as where is exactly the th root of unity with the smallest positive angle — every other th root of unity is a power of it.  For , determine all fourth roots of unity and write them as powers of . Then compute the DFT of the four measured values .    With , , , , gives the angles , so (read off from , with ) So the four roots of unity are exactly — all powers of the one number . This structure (every th root of unity as a power of a single generating root) is exactly what the fast Fourier transform (FFT) exploits algorithmically to evaluate the DFT in instead of computational steps.  For the DFT, we need . Since only and are nonzero, two terms remain in each case: The measured values are samples of , that is, of an oscillation that runs through exactly one period in four measurement points. The DFT shows exactly this: a peak at (one period per measurement window) and its mirror image at , nothing else. This is how hidden periodicities are detected in real-world time series — electricity consumption, sales figures, vibration data. Incidentally, the library function numpy.fft.fft([2, 0, -2, 0]) returns exactly these four values (as complex floating-point numbers).      Quadratic equations in  You know the quadratic formula and its normalized version, the quadratic formula in its form, from school. Its derivation uses only completing the square, that is, adding, multiplying and rearranging — and all of this works in just as in . The only step where things get stuck in the real numbers is taking the square root of the discriminant. But we have just solved exactly this problem: by , every complex number has exactly two square roots, and the two differ only in sign. The in the formula ensures that both are used.   The quadratic formula in its form in   Let . If is a solution of , then the equation has the solutions The solutions coincide if and only if .    Completing the square gives (difference of two squares). A product is zero if and only if one of its factors is zero.    For real with a negative discriminant , this is particularly convenient: then is purely imaginary, because .   Quadratic equations with a negative discriminant   Solve and in .    For , we have and , so . One solution of is , and the quadratic formula in its form gives These are exactly the solutions that we only checked in — now we have really found them. Likewise, for the second equation, , so In both cases, the solutions are conjugates of each other. This is due to the in front of the purely imaginary root — and, as we will see later in this section, it has a deeper reason.    If the coefficients themselves are complex, the discriminant is usually neither positive nor negative, but some complex number. Then you determine its square roots with the solution formula for — or, if the angle is awkward, by comparing real and imaginary parts as in .   A quadratic equation with complex coefficients   Solve .    Here and . The discriminant is We are looking for a number with . Method 1, exponential form:  has modulus ; normalized, it is , so by , . Hence (again with the figure) is a solution. Method 2, comparing coefficients: With , we have . Comparing with gives and . Since , we have , and then , so . With , , we get the same result (the other choice , gives the second root ).  Hence Check via the linear factors: . This time, the two solutions are not conjugate — no contradiction, because the coefficients are not real.    One last trick belongs in the toolbox. If an equation of degree four contains only the powers , and a constant, it is called biquadratic . The substitution turns it into a quadratic equation in , and each of its solutions gives two values of via .   Biquadratic: Four solutions at once (optional)   Determine all solutions of in .    With , the equation reads , so From , it follows that ; from , it follows that . The four solutions are In , you would have found only half of them; the solution of the auxiliary equation would simply have been discarded.     When even the auxiliary equation becomes complex   Determine all solutions of in algebraic form.    With : . Here , so and . In exponential form: , and normalized, ; in , these are the points at the angles , so .  Now we solve two binomial equations of degree two. From , it follows (with the value at from the figure) that and from , likewise, . The four solutions lie on the circle of radius at the angles and — and form two conjugate pairs, as is to be expected for an equation with real coefficients.      Fundamental theorem of algebra and factorization into linear factors  Take a quick look back at how the number systems were built up. The equation cannot be solved in — so you add the negative numbers and arrive at . For , you need fractions, that is, ; for , the irrational numbers, that is, ; and finally, for , . Each time, a harmless equation forced a new number system. Does this go on forever? For , we have already seen that the solutions lie in . But do you perhaps need new numbers again for an equation as unwieldy as ?  The surprising answer is: no. With , the process comes to an end, at least for polynomial equations. This is the statement of one of the central theorems of mathematics.   Fundamental theorem of algebra   Every nonconstant polynomial with coefficients , , , has at least one root in .    The theorem was proved by Carl Friedrich Gauss in 1799 in his doctoral dissertation — three years after the 17-gon; the proof requires deeper methods and is not given here. It is remarkable that the theorem guarantees only the existence of a root, not how to find it. For degree , there is the quadratic formula; for degrees and , there are similar (very unwieldy) formulas; but for polynomials of degree , as Niels Henrik Abel showed in 1826, there is no longer a general solution formula in radicals. In practice, you guess a root (or it is given), split it off and continue with the remaining polynomial — or you leave the work to a numerical method such as numpy.roots . By hand, we proceed as in the following examples.   Factorization into linear factors   If is a root of (degree ), then the linear factor  can be split off: there is a polynomial of degree with Applying this repeatedly (the fundamental theorem guarantees a new root at each step as long as the degree stays ) gives the complete factorization into linear factors  which is unique up to the order of the factors. A root may occur more than once; the number of times it occurs is called its multiplicity . So a polynomial of degree always has exactly roots in , counted with multiplicity.     Counting roots correctly   How many roots does have in , and how many in ? Give the factorization into linear factors.    By the formula for the square of a sum, . In , , so has no root at all there. In , , so There are two distinct roots, and , each with multiplicity . Counted with multiplicity, these are roots — exactly as many as the degree promises. Without counting multiplicity, the neat rule degree number of roots would fail.     Factoring a cubic polynomial into linear factors   Determine the factorization into linear factors of . Use the fact that is a root.    Check: . We split off . We write with unknown coefficients; multiplying out gives and comparing coefficients with gives , , , so and : The quadratic formula in its form gives the roots of this factor: , so and So the complete factorization into linear factors is Instead of using unknown coefficients and comparing them, you can of course also determine the factor by polynomial division — both ways are equivalent. (Incidentally, the three equations for the coefficients with only two unknowns are a built-in check: if were not a root, they would contradict each other.)    Again, the two nonreal roots are conjugate, just as in and . Three times is no longer a coincidence: for polynomials with real coefficients, this is always the case.   Factorization of real polynomials   If a polynomial has only real coefficients, then the following holds: if is a root, then is also a root (so nonreal roots always occur in pairs of complex conjugates). Every real polynomial can therefore be factored into a product of real linear factors and quadratic polynomials with real coefficients that have no real root themselves (each of them comes from a pair of complex conjugate roots). This is called the factorization into irreducible real factors .    Let with and . Conjugation is compatible with sums and products, and holds for real coefficients. Conjugating this equation therefore gives so is also a root. For nonreal , the numbers and are distinct, and the factor has real coefficients (check with : ), but no real root.    A nice consequence to think about: a real polynomial of odd degree always has at least one real root. This is because the quadratic factors of the real factorization together contribute only an even degree — so if the total degree is odd, there must be at least one real linear factor, and it gives a real root.   Factorization into irreducible real factors   Determine the factorization of into irreducible real factors. Use the fact that is a root.    Check: . Since has real coefficients, tells us that is also a root. The corresponding real factor is . Dividing by gives the linear factor (write ; comparing coefficients gives ). Since has no real root, we have already reached the factorization into irreducible real factors: If you look closely, you can find the factorization without any complex numbers: . But such lucky cases are the exception — the route via the conjugate pair always works.    You can also go the other way: instead of factoring a polynomial, you build it from given roots. This is more useful than it sounds — in control engineering, for example, you fix the roots of a characteristic polynomial to enforce a desired system behavior and then work out the coefficients from them.   Working backward: A real polynomial with given roots   We are looking for a polynomial with real coefficients and leading coefficient that has the roots and . What is the smallest possible degree of ? Determine for this smallest degree.    Because must have real coefficients, must be a root along with ( ). So has at least three roots and therefore at least degree . The conjugate pair gives the real factor and hence Check: . There is of course also a polynomial of degree with the two roots and , namely — but its coefficients are not real.    This completes the story that began with . The imaginary unit was introduced to rescue one unsolvable equation. The result is a number system in which every polynomial equation can be solved completely — and only there does even the question of how to factor a real polynomial into real factors find its simple answer. Incidentally, such factorizations into real factors are the starting point of partial fraction decomposition , which splits a fraction of two polynomials into a sum of simpler fractions. It is used in this book only in a few places (for series and differential equations), but it is neither assumed nor covered in the lecture: wherever it occurs, the decomposition is given and can be checked by bringing the fractions to a common denominator. And the output of numpy.roots from the introduction is no longer a surprise: has the real root and the conjugate pair , which gives the real factor — three roots for degree , as the fundamental theorem promises.     Applications: AC engineering  In practice, hardly anyone poses the problem Solve . More often, a technical quantity is complex — an impedance, a phasor — and what you are looking for is a very concrete, real result: an amplitude, a component value, a frequency. This is exactly where the computational techniques from meet the algebraic equations of this section.  The following four examples come from AC engineering, which you already know from and . They deal with the superposition of two voltages, a resistance value that has to satisfy a condition on the modulus, a filter that suppresses measurement noise, and the resonance of an LC circuit. Notice how each time a complex computation leads to a real result — in the last three examples via a real algebraic equation.   Application: Superposition of two AC voltages   A sinusoidal AC voltage is represented by its phasor ( ); voltages with the same frequency are superposed by adding their phasors ( ). Let Determine the superposed voltage in complex and in real form.    The first voltage is given as a sine, but the phasor notation requires a cosine. With (the sine lags behind the cosine by a quarter period), we have . So, with the values of and from , the phasors are The sum phasor is Amplitude: a remarkably neat exact form. It is no coincidence: , and the two phasors enclose the angle , so the law of cosines gives . The normalized phasor is not one of the standard points in , so we need the arctangent. Since and (fourth quadrant), no correction is needed: Check with the figure: the imaginary part is smaller than , so must lie between and — this fits. So the complex voltage is (in electrical engineering, the underline marks complex quantities), and in real form As a plausibility check: the amplitude lies between and volts, as it must for a superposition. It would reach the upper limit only if both oscillations were in phase.    The superposition was a direct computation. In the next two examples, the direction is reversed: the result is given, and a component value or a frequency is sought. A rule that follows immediately from the exponential form helps here ( ): the modulus of a product is the product of the moduli, and the modulus of a quotient is the quotient of the moduli, So you do not need to bring a complicated fraction into algebraic form if you only need its modulus.  We also need to know how the impedances of several components combine into a total impedance . The same rules apply as for resistors, only with complex numbers, and both follow from Ohm's law for AC circuits, ( ):  In a series circuit , the same current flows through all components, and their voltages add up. So the impedances add, — just as in .  In a parallel circuit , the same voltage is applied to all components, and their currents add up. So the reciprocals of the impedances add, for two components, .     Application: Component value from an impedance condition   A capacitor has the purely imaginary impedance ; the positive quantity is called its reactance (in general, this is the name for the imaginary part of an impedance; for a capacitor, the absolute value is usually given). It is called reactance rather than resistance because the capacitor does impede the current, but it does not turn the energy into heat as a resistor does; it only stores the energy and gives it back.  A resistor and a capacitor with reactance are connected in parallel ( ). For the total impedance of a parallel circuit of and , we have For which value of does the circuit have the modulus ?   Parallel RC circuit: the current from the source divides between the resistor and the capacitor with reactance .    Circuit diagram: on the left, an AC voltage source (a circle with a sine wave). Two wires lead from it to the right; between them, two branches lie side by side: a resistor (a rectangle) and a capacitor (two parallel plates) labeled . So both components are connected to the same voltage.        By the quotient rule for moduli, Substituting and , we obtain an algebraic equation for : Multiplying by the denominator and squaring (allowed because both sides are positive for ) turns this into a quadratic equation for (without a linear term): The positive solution is Check: . Even though the quantity we start from (the impedance ) is complex, a condition on its modulus leads to a purely real algebraic equation — exactly the kind of equation that is at the center of this section. Incidentally, the parallel circuit has a smaller modulus than each of its two components ( and ) — as with two resistors in parallel, where the current can split between two paths. For and in parallel, this is always the case; for a coil and a capacitor in parallel, however, it is not, as will show.     Application: The cutoff frequency of a low-pass filter (optional)   A measurement signal — for example, the voltage of a temperature sensor — almost always has high-frequency noise superposed on it. A simple way to smooth it is an RC low-pass filter : the input voltage is applied to a series circuit of a resistor and a capacitor , and the output voltage is taken across the capacitor ( ).   RC low-pass filter: the input voltage is applied to the series circuit of and ; the output voltage is taken across the capacitor.    Circuit diagram with two input terminals on the left and two output terminals on the right. From the upper input terminal, the wire leads through a resistor (a rectangle) to the upper output terminal; the lower wire connects the two lower terminals directly. To the right of the resistor, a capacitor connects the upper and the lower wire. Voltage arrows mark the input voltage between the left terminals and the output voltage between the right terminals, that is, across the capacitor.      For a sinusoidal input voltage with angular frequency , the input and output voltages are described by their phasors and ( ). Their quotient is called the transfer function (also frequency response ) of the filter: its modulus indicates what fraction of the amplitude of an oscillation with angular frequency passes through the filter, and its argument indicates by what angle the output voltage is phase-shifted relative to the input voltage. Because the same current flows through and , we have and ( voltage divider rule ), so   Let and , so .  At which angular frequency is ? (This frequency is called the cutoff frequency of the filter.)  Above which angular frequency does at most of the amplitude get through?  What phase shift does an oscillation at the cutoff frequency undergo?      Again, the quotient rule for moduli helps:   if and only if , that is, (for ):  if and only if , that is, . From about on, that is, just under ten times the cutoff frequency, the amplitude is reduced to at most one tenth.  At , we have with ; normalized, , so by , : the output voltage lags behind the input voltage by .    Slow changes in the measurement signal (small , so ) pass through the filter practically unchanged; fast noise is suppressed. This is the analog counterpart of the exponentially weighted moving average (EMA), which is used in time series analysis to smooth noisy data. And one more observation that may make you smile: the values , and are exactly those from . So the circuit studied there ran exactly at its cutoff frequency — and this is why gave a phase angle of exactly .    In the last example, we work with symbols instead of numbers. In engineering, this is the usual situation: you want to know how a result depends on the component values, not just what comes out for one particular choice. The cutoff frequency above was already an example of such a formula.   Application: Resonance condition of a parallel resonant circuit (optional)   A coil with inductance and a capacitor with capacitance are connected in parallel ( ). The total impedance is given by    Parallel resonant circuit: the coil and the capacitor are connected in parallel to the AC voltage source .    Circuit diagram: on the left, an AC voltage source (a circle with a sine wave). Two wires lead from it to the right; between them, two branches lie side by side: a coil (a filled rectangle, the DIN circuit symbol) and a capacitor (two parallel plates). So both components are connected to the same voltage.      When designing a circuit, you often specify what reactance (the imaginary part of ) it should have at the operating frequency, for example to compensate for the reactance of another component. Then you look for the matching frequency or the matching component values. The value (in ohms, if , and are measured in SI units) stands here for such a target value; with any other value, the computation is the same. For which angular frequency does the reactance have the value  ?    Taking the reciprocal (and multiplying the numerator and denominator by to make the denominator real), we obtain so . After multiplying by the denominator, the condition gives the quadratic equation in  whose solution from the quadratic formula (the one relevant for ) is For an arbitrary target value instead of , the same computation leads to . The denominator of is also interesting: for , that is, , becomes unbounded — this is the resonant frequency of the circuit, at which it blocks the current completely. We will meet the same quantity again in as the natural frequency of the RLC circuit.    All four examples follow the same pattern: complex numbers describe the circuit compactly, and the modulus, real part or imaginary part turns this description into real quantities — in the last three cases via an ordinary equation, here a quadratic one. Complex numbers are not an end in themselves here, but the shortest route to a real result. A witty remark by the French mathematician Paul Painlevé, made famous by his colleague Jacques Hadamard, sums it up: the shortest path between two truths about real numbers often passes through the complex numbers.    Summary     Binomial equation  : exactly solutions the vertices of a regular -gon on the circle of radius .   th roots of unity: the solutions of ; all of them are powers of . They form the basis of the discrete Fourier transform (DFT).   Quadratic equations: for all , has the solutions , where is a solution of ; for real and a negative discriminant, is purely imaginary. For example, has the solutions . Biquadratic equations are solved with the substitution . Caution: use the radical sign only for — only there is it unique, and only there does hold.   Fundamental theorem of algebra: every polynomial of degree has at least one root in and, counted with multiplicity, exactly roots; hence the factorization into linear factors .   Real coefficients: nonreal roots occur in conjugate pairs ; each pair gives the real quadratic factor , which has no real root. A real polynomial of odd degree therefore always has a real root.   Practical procedure: guess a root or take it from the problem; split off the linear factor (or the real quadratic factor) by writing the product with unknown coefficients and comparing coefficients; treat the remaining polynomial with the quadratic formula.   Application: in series, impedances add; in parallel, their reciprocals add. Conditions on the modulus or the imaginary part of a complex impedance lead to real algebraic equations for component values or frequencies; helps here.      Exercises    Determine all solutions of .    We have ; normalized, . So by , and . With and , the solution formula for binomial equations gives the angles , , that is, , , and . The last two do not lie in ; after subtracting , they are and . With the values from the figure:       Solve the equation in , and check one of the two solutions.    With and , we have . The number has modulus ; normalized, it is , so by , . Hence (with the value at from the same figure) is a solution of (check: ). The quadratic formula in its form gives Check for : . The two solutions are not conjugates of each other — but then, the coefficients are not real either.      Determine the factorization into linear factors of . Use the fact that is a root.    Check: . We write with unknown coefficients; multiplying out and comparing coefficients gives The quadratic formula (or taking the square root directly) gives . So the complete factorization into linear factors is       Determine the factorization of into irreducible real factors. Use the fact that is a root.    Check: . Since has real coefficients, is also a root, and the corresponding real factor is . Dividing by (write ; comparing coefficients gives ) yields Since has no real root, this is already the factorization into irreducible real factors.      Determine all sixth roots of unity (the solutions of ), and show that their sum equals .    With , , , , the solutions are , . After subtracting , the angles and correspond to the angles and ; from , we read off: If you add the real parts and the imaginary parts separately, both cancel in pairs:      "
},
{
  "id": "sec-algebraische-gleichungen-anwendungen-2",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#sec-algebraische-gleichungen-anwendungen-2",
  "type": "Objectives",
  "number": "1.2",
  "title": "",
  "body": "  After this section, you can    determine all solutions of a binomial equation and interpret them as a regular -gon in the complex plane;  state the th roots of unity and explain their role in the discrete Fourier transform;  solve quadratic equations in — with a negative discriminant, with complex coefficients and, by substitution, also biquadratic equations;  state the fundamental theorem of algebra and factor a polynomial into linear factors when one root is known;  factor real polynomials into irreducible real factors by combining pairs of complex conjugate roots;  translate a technical condition on an impedance or a filter into a real algebraic equation and solve it.   "
},
{
  "id": "def-reine-gleichung-nten-grades",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#def-reine-gleichung-nten-grades",
  "type": "Definition",
  "number": "1.2.1",
  "title": "Binomial equation of degree <span class=\"process-math\">\\(n\\text{,}\\)<\/span> roots.",
  "body": " Binomial equation of degree , roots   For and , the equation is called the binomial equation of degree . Its solutions are also called the roots of .   "
},
{
  "id": "thm-loesungen-reine-gleichung",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#thm-loesungen-reine-gleichung",
  "type": "Theorem",
  "number": "1.2.2",
  "title": "Solution formula for binomial equations.",
  "body": " Solution formula for binomial equations   Let . The equation has exactly distinct solutions in , namely In the complex plane, these numbers lie on a circle of radius around the origin and form a regular -gon there. For this reason, is also called a cyclotomic equation (from the Greek for circle-dividing ).    We write with . Then , and means: the moduli and the angles of both sides agree, where angles are determined only up to multiples of . So , that is, , and for some , that is, . For , these angles give distinct numbers, because two of them differ by with , and this is not a multiple of ; gives the angle of again (plus ), so nothing new.   "
},
{
  "id": "ex-reine-gleichung-fuenften-grades",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-reine-gleichung-fuenften-grades",
  "type": "Example",
  "number": "1.2.3",
  "title": "Five solutions, one pentagon.",
  "body": " Five solutions, one pentagon   Determine all solutions of .     Step 1:  ; normalized, . So by , and .   Step 2:  and , so .   Step 3: Rotate further by each time: with the angles . The solution for is — the only real solution, which you would have found even without complex numbers. The five solutions form a regular pentagon ( ).   "
},
{
  "id": "fig-nte-wurzeln-fuenfeck",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#fig-nte-wurzeln-fuenfeck",
  "type": "Figure",
  "number": "1.2.4",
  "title": "",
  "body": " The five solutions of form a regular pentagon on the circle of radius around the origin.    A coordinate system with a real and an imaginary axis and a circle of radius 2 around the origin. Five evenly spaced points are marked on this circle ( apart, at the angles ); they form a regular pentagon. One of the points lies on the negative real axis.     "
},
{
  "id": "ex-kubikwurzeln-einheit",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-kubikwurzeln-einheit",
  "type": "Example",
  "number": "1.2.5",
  "title": "The third roots of unity.",
  "body": " The third roots of unity   Determine all solutions of .    With , we have and . By with : so , and (we subtracted to land in ). In algebraic form, read off from : The numbers are called the third roots of unity ; in general, the solutions of are called the th roots of unity . They form an equilateral triangle on the unit circle, with one vertex at . Check for : by the laws of exponents, . If you do not trust the exponential form yet, you can also verify this in algebraic form: and , because is the conjugate of .   "
},
{
  "id": "ex-quadratwurzeln-aus-i",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-quadratwurzeln-aus-i",
  "type": "Example",
  "number": "1.2.6",
  "title": "Roots of a nonreal number.",
  "body": " Roots of a nonreal number   Determine all solutions of in algebraic form, and check your result.    The number has modulus and, by , lies at the angle , so . The first solution has the angle ; the second is rotated further by , to or (after subtracting ) . Read off from the figure: Check: . As in the real case, the two square roots differ only in sign — they lie opposite each other on the circle.   "
},
{
  "id": "ex-anwendung-einheitswurzeln-dft",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-anwendung-einheitswurzeln-dft",
  "type": "Example",
  "number": "1.2.7",
  "title": "Application: <span class=\"process-math\">\\(n\\)<\/span>th roots of unity and the discrete Fourier transform.",
  "body": " Application: th roots of unity and the discrete Fourier transform   The th roots of unity from are more than a pretty geometric figure: they form the basis of the discrete Fourier transform (DFT) , one of the most important tools of digital signal processing and hence also of data science (spectral analysis of time series, image and audio compression, fast convolution in neural networks). The DFT decomposes a sampled signal, that is, values measured at equal time intervals, into contributions of different frequencies: the modulus indicates how strongly an oscillation with exactly periods per measurement window is present in the data. For a sequence of measured values , the DFT is defined as where is exactly the th root of unity with the smallest positive angle — every other th root of unity is a power of it.  For , determine all fourth roots of unity and write them as powers of . Then compute the DFT of the four measured values .    With , , , , gives the angles , so (read off from , with ) So the four roots of unity are exactly — all powers of the one number . This structure (every th root of unity as a power of a single generating root) is exactly what the fast Fourier transform (FFT) exploits algorithmically to evaluate the DFT in instead of computational steps.  For the DFT, we need . Since only and are nonzero, two terms remain in each case: The measured values are samples of , that is, of an oscillation that runs through exactly one period in four measurement points. The DFT shows exactly this: a peak at (one period per measurement window) and its mirror image at , nothing else. This is how hidden periodicities are detected in real-world time series — electricity consumption, sales figures, vibration data. Incidentally, the library function numpy.fft.fft([2, 0, -2, 0]) returns exactly these four values (as complex floating-point numbers).   "
},
{
  "id": "thm-pq-formel-komplex",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#thm-pq-formel-komplex",
  "type": "Theorem",
  "number": "1.2.8",
  "title": "The quadratic formula in its <span class=\"process-math\">\\(pq\\)<\/span> form in <span class=\"process-math\">\\(\\C\\)<\/span>.",
  "body": " The quadratic formula in its form in   Let . If is a solution of , then the equation has the solutions The solutions coincide if and only if .    Completing the square gives (difference of two squares). A product is zero if and only if one of its factors is zero.   "
},
{
  "id": "ex-quadratische-gleichung-komplex",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-quadratische-gleichung-komplex",
  "type": "Example",
  "number": "1.2.9",
  "title": "Quadratic equations with a negative discriminant.",
  "body": " Quadratic equations with a negative discriminant   Solve and in .    For , we have and , so . One solution of is , and the quadratic formula in its form gives These are exactly the solutions that we only checked in — now we have really found them. Likewise, for the second equation, , so In both cases, the solutions are conjugates of each other. This is due to the in front of the purely imaginary root — and, as we will see later in this section, it has a deeper reason.   "
},
{
  "id": "ex-quadratische-gleichung-komplexe-koeffizienten",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-quadratische-gleichung-komplexe-koeffizienten",
  "type": "Example",
  "number": "1.2.10",
  "title": "A quadratic equation with complex coefficients.",
  "body": " A quadratic equation with complex coefficients   Solve .    Here and . The discriminant is We are looking for a number with . Method 1, exponential form:  has modulus ; normalized, it is , so by , . Hence (again with the figure) is a solution. Method 2, comparing coefficients: With , we have . Comparing with gives and . Since , we have , and then , so . With , , we get the same result (the other choice , gives the second root ).  Hence Check via the linear factors: . This time, the two solutions are not conjugate — no contradiction, because the coefficients are not real.   "
},
{
  "id": "ssub-quadratische-gleichungen-komplex-8",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ssub-quadratische-gleichungen-komplex-8",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "biquadratic "
},
{
  "id": "ex-biquadratische-gleichung",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-biquadratische-gleichung",
  "type": "Example",
  "number": "1.2.11",
  "title": "Biquadratic: Four solutions at once (optional).",
  "body": " Biquadratic: Four solutions at once (optional)   Determine all solutions of in .    With , the equation reads , so From , it follows that ; from , it follows that . The four solutions are In , you would have found only half of them; the solution of the auxiliary equation would simply have been discarded.   "
},
{
  "id": "ex-biquadratisch-komplexe-substitution",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-biquadratisch-komplexe-substitution",
  "type": "Example",
  "number": "1.2.12",
  "title": "When even the auxiliary equation becomes complex.",
  "body": " When even the auxiliary equation becomes complex   Determine all solutions of in algebraic form.    With : . Here , so and . In exponential form: , and normalized, ; in , these are the points at the angles , so .  Now we solve two binomial equations of degree two. From , it follows (with the value at from the figure) that and from , likewise, . The four solutions lie on the circle of radius at the angles and — and form two conjugate pairs, as is to be expected for an equation with real coefficients.   "
},
{
  "id": "thm-fundamentalsatz-algebra",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#thm-fundamentalsatz-algebra",
  "type": "Theorem",
  "number": "1.2.13",
  "title": "Fundamental theorem of algebra.",
  "body": " Fundamental theorem of algebra   Every nonconstant polynomial with coefficients , , , has at least one root in .   "
},
{
  "id": "thm-linearfaktorisierung",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#thm-linearfaktorisierung",
  "type": "Theorem",
  "number": "1.2.14",
  "title": "Factorization into linear factors.",
  "body": " Factorization into linear factors   If is a root of (degree ), then the linear factor  can be split off: there is a polynomial of degree with Applying this repeatedly (the fundamental theorem guarantees a new root at each step as long as the degree stays ) gives the complete factorization into linear factors  which is unique up to the order of the factors. A root may occur more than once; the number of times it occurs is called its multiplicity . So a polynomial of degree always has exactly roots in , counted with multiplicity.   "
},
{
  "id": "ex-nullstellen-vielfachheit",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-nullstellen-vielfachheit",
  "type": "Example",
  "number": "1.2.15",
  "title": "Counting roots correctly.",
  "body": " Counting roots correctly   How many roots does have in , and how many in ? Give the factorization into linear factors.    By the formula for the square of a sum, . In , , so has no root at all there. In , , so There are two distinct roots, and , each with multiplicity . Counted with multiplicity, these are roots — exactly as many as the degree promises. Without counting multiplicity, the neat rule degree number of roots would fail.   "
},
{
  "id": "ex-linearfaktorisierung-kubisch",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-linearfaktorisierung-kubisch",
  "type": "Example",
  "number": "1.2.16",
  "title": "Factoring a cubic polynomial into linear factors.",
  "body": " Factoring a cubic polynomial into linear factors   Determine the factorization into linear factors of . Use the fact that is a root.    Check: . We split off . We write with unknown coefficients; multiplying out gives and comparing coefficients with gives , , , so and : The quadratic formula in its form gives the roots of this factor: , so and So the complete factorization into linear factors is Instead of using unknown coefficients and comparing them, you can of course also determine the factor by polynomial division — both ways are equivalent. (Incidentally, the three equations for the coefficients with only two unknowns are a built-in check: if were not a root, they would contradict each other.)   "
},
{
  "id": "thm-reelle-faktorisierung",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#thm-reelle-faktorisierung",
  "type": "Theorem",
  "number": "1.2.17",
  "title": "Factorization of real polynomials.",
  "body": " Factorization of real polynomials   If a polynomial has only real coefficients, then the following holds: if is a root, then is also a root (so nonreal roots always occur in pairs of complex conjugates). Every real polynomial can therefore be factored into a product of real linear factors and quadratic polynomials with real coefficients that have no real root themselves (each of them comes from a pair of complex conjugate roots). This is called the factorization into irreducible real factors .    Let with and . Conjugation is compatible with sums and products, and holds for real coefficients. Conjugating this equation therefore gives so is also a root. For nonreal , the numbers and are distinct, and the factor has real coefficients (check with : ), but no real root.   "
},
{
  "id": "ex-reelle-faktorisierung-kubisch",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-reelle-faktorisierung-kubisch",
  "type": "Example",
  "number": "1.2.18",
  "title": "Factorization into irreducible real factors.",
  "body": " Factorization into irreducible real factors   Determine the factorization of into irreducible real factors. Use the fact that is a root.    Check: . Since has real coefficients, tells us that is also a root. The corresponding real factor is . Dividing by gives the linear factor (write ; comparing coefficients gives ). Since has no real root, we have already reached the factorization into irreducible real factors: If you look closely, you can find the factorization without any complex numbers: . But such lucky cases are the exception — the route via the conjugate pair always works.   "
},
{
  "id": "ex-polynom-aus-nullstellen",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-polynom-aus-nullstellen",
  "type": "Example",
  "number": "1.2.19",
  "title": "Working backward: A real polynomial with given roots.",
  "body": " Working backward: A real polynomial with given roots   We are looking for a polynomial with real coefficients and leading coefficient that has the roots and . What is the smallest possible degree of ? Determine for this smallest degree.    Because must have real coefficients, must be a root along with ( ). So has at least three roots and therefore at least degree . The conjugate pair gives the real factor and hence Check: . There is of course also a polynomial of degree with the two roots and , namely — but its coefficients are not real.   "
},
{
  "id": "ssub-fundamentalsatz-linearfaktorisierung-15",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ssub-fundamentalsatz-linearfaktorisierung-15",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "partial fraction decomposition "
},
{
  "id": "ex-anwendung-ueberlagerung-zwei-spannungen",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-anwendung-ueberlagerung-zwei-spannungen",
  "type": "Example",
  "number": "1.2.20",
  "title": "Application: Superposition of two AC voltages.",
  "body": " Application: Superposition of two AC voltages   A sinusoidal AC voltage is represented by its phasor ( ); voltages with the same frequency are superposed by adding their phasors ( ). Let Determine the superposed voltage in complex and in real form.    The first voltage is given as a sine, but the phasor notation requires a cosine. With (the sine lags behind the cosine by a quarter period), we have . So, with the values of and from , the phasors are The sum phasor is Amplitude: a remarkably neat exact form. It is no coincidence: , and the two phasors enclose the angle , so the law of cosines gives . The normalized phasor is not one of the standard points in , so we need the arctangent. Since and (fourth quadrant), no correction is needed: Check with the figure: the imaginary part is smaller than , so must lie between and — this fits. So the complex voltage is (in electrical engineering, the underline marks complex quantities), and in real form As a plausibility check: the amplitude lies between and volts, as it must for a superposition. It would reach the upper limit only if both oscillations were in phase.   "
},
{
  "id": "sub-anwendungen-komplexer-zahlen-6",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#sub-anwendungen-komplexer-zahlen-6",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "series circuit parallel circuit "
},
{
  "id": "ex-anwendung-bauteilwert-aus-impedanz",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-anwendung-bauteilwert-aus-impedanz",
  "type": "Example",
  "number": "1.2.21",
  "title": "Application: Component value from an impedance condition.",
  "body": " Application: Component value from an impedance condition   A capacitor has the purely imaginary impedance ; the positive quantity is called its reactance (in general, this is the name for the imaginary part of an impedance; for a capacitor, the absolute value is usually given). It is called reactance rather than resistance because the capacitor does impede the current, but it does not turn the energy into heat as a resistor does; it only stores the energy and gives it back.  A resistor and a capacitor with reactance are connected in parallel ( ). For the total impedance of a parallel circuit of and , we have For which value of does the circuit have the modulus ?   Parallel RC circuit: the current from the source divides between the resistor and the capacitor with reactance .    Circuit diagram: on the left, an AC voltage source (a circle with a sine wave). Two wires lead from it to the right; between them, two branches lie side by side: a resistor (a rectangle) and a capacitor (two parallel plates) labeled . So both components are connected to the same voltage.        By the quotient rule for moduli, Substituting and , we obtain an algebraic equation for : Multiplying by the denominator and squaring (allowed because both sides are positive for ) turns this into a quadratic equation for (without a linear term): The positive solution is Check: . Even though the quantity we start from (the impedance ) is complex, a condition on its modulus leads to a purely real algebraic equation — exactly the kind of equation that is at the center of this section. Incidentally, the parallel circuit has a smaller modulus than each of its two components ( and ) — as with two resistors in parallel, where the current can split between two paths. For and in parallel, this is always the case; for a coil and a capacitor in parallel, however, it is not, as will show.   "
},
{
  "id": "ex-anwendung-tiefpass-grenzfrequenz",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-anwendung-tiefpass-grenzfrequenz",
  "type": "Example",
  "number": "1.2.23",
  "title": "Application: The cutoff frequency of a low-pass filter (optional).",
  "body": " Application: The cutoff frequency of a low-pass filter (optional)   A measurement signal — for example, the voltage of a temperature sensor — almost always has high-frequency noise superposed on it. A simple way to smooth it is an RC low-pass filter : the input voltage is applied to a series circuit of a resistor and a capacitor , and the output voltage is taken across the capacitor ( ).   RC low-pass filter: the input voltage is applied to the series circuit of and ; the output voltage is taken across the capacitor.    Circuit diagram with two input terminals on the left and two output terminals on the right. From the upper input terminal, the wire leads through a resistor (a rectangle) to the upper output terminal; the lower wire connects the two lower terminals directly. To the right of the resistor, a capacitor connects the upper and the lower wire. Voltage arrows mark the input voltage between the left terminals and the output voltage between the right terminals, that is, across the capacitor.      For a sinusoidal input voltage with angular frequency , the input and output voltages are described by their phasors and ( ). Their quotient is called the transfer function (also frequency response ) of the filter: its modulus indicates what fraction of the amplitude of an oscillation with angular frequency passes through the filter, and its argument indicates by what angle the output voltage is phase-shifted relative to the input voltage. Because the same current flows through and , we have and ( voltage divider rule ), so   Let and , so .  At which angular frequency is ? (This frequency is called the cutoff frequency of the filter.)  Above which angular frequency does at most of the amplitude get through?  What phase shift does an oscillation at the cutoff frequency undergo?      Again, the quotient rule for moduli helps:   if and only if , that is, (for ):  if and only if , that is, . From about on, that is, just under ten times the cutoff frequency, the amplitude is reduced to at most one tenth.  At , we have with ; normalized, , so by , : the output voltage lags behind the input voltage by .    Slow changes in the measurement signal (small , so ) pass through the filter practically unchanged; fast noise is suppressed. This is the analog counterpart of the exponentially weighted moving average (EMA), which is used in time series analysis to smooth noisy data. And one more observation that may make you smile: the values , and are exactly those from . So the circuit studied there ran exactly at its cutoff frequency — and this is why gave a phase angle of exactly .   "
},
{
  "id": "ex-anwendung-schwingkreis-symbolisch",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-anwendung-schwingkreis-symbolisch",
  "type": "Example",
  "number": "1.2.25",
  "title": "Application: Resonance condition of a parallel resonant circuit (optional).",
  "body": " Application: Resonance condition of a parallel resonant circuit (optional)   A coil with inductance and a capacitor with capacitance are connected in parallel ( ). The total impedance is given by    Parallel resonant circuit: the coil and the capacitor are connected in parallel to the AC voltage source .    Circuit diagram: on the left, an AC voltage source (a circle with a sine wave). Two wires lead from it to the right; between them, two branches lie side by side: a coil (a filled rectangle, the DIN circuit symbol) and a capacitor (two parallel plates). So both components are connected to the same voltage.      When designing a circuit, you often specify what reactance (the imaginary part of ) it should have at the operating frequency, for example to compensate for the reactance of another component. Then you look for the matching frequency or the matching component values. The value (in ohms, if , and are measured in SI units) stands here for such a target value; with any other value, the computation is the same. For which angular frequency does the reactance have the value  ?    Taking the reciprocal (and multiplying the numerator and denominator by to make the denominator real), we obtain so . After multiplying by the denominator, the condition gives the quadratic equation in  whose solution from the quadratic formula (the one relevant for ) is For an arbitrary target value instead of , the same computation leads to . The denominator of is also interesting: for , that is, , becomes unbounded — this is the resonant frequency of the circuit, at which it blocks the current completely. We will meet the same quantity again in as the natural frequency of the RLC circuit.   "
},
{
  "id": "sub-zusammenfassung-1-2-2",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#sub-zusammenfassung-1-2-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Binomial equation th roots of unity: Quadratic equations: Fundamental theorem of algebra: Real coefficients: Practical procedure: Application: "
},
{
  "id": "exercise-buch-reine-gleichung-vierten-grades",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#exercise-buch-reine-gleichung-vierten-grades",
  "type": "Exercise",
  "number": "1.2.4.1",
  "title": "",
  "body": "  Determine all solutions of .    We have ; normalized, . So by , and . With and , the solution formula for binomial equations gives the angles , , that is, , , and . The last two do not lie in ; after subtracting , they are and . With the values from the figure:    "
},
{
  "id": "exercise-buch-quadratische-gleichung-komplexe-koeffizienten",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#exercise-buch-quadratische-gleichung-komplexe-koeffizienten",
  "type": "Exercise",
  "number": "1.2.4.2",
  "title": "",
  "body": "  Solve the equation in , and check one of the two solutions.    With and , we have . The number has modulus ; normalized, it is , so by , . Hence (with the value at from the same figure) is a solution of (check: ). The quadratic formula in its form gives Check for : . The two solutions are not conjugates of each other — but then, the coefficients are not real either.   "
},
{
  "id": "exercise-buch-linearfaktorzerlegung-kubisch",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#exercise-buch-linearfaktorzerlegung-kubisch",
  "type": "Exercise",
  "number": "1.2.4.3",
  "title": "",
  "body": "  Determine the factorization into linear factors of . Use the fact that is a root.    Check: . We write with unknown coefficients; multiplying out and comparing coefficients gives The quadratic formula (or taking the square root directly) gives . So the complete factorization into linear factors is    "
},
{
  "id": "exercise-buch-reelle-faktorisierung-kubisch",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#exercise-buch-reelle-faktorisierung-kubisch",
  "type": "Exercise",
  "number": "1.2.4.4",
  "title": "",
  "body": "  Determine the factorization of into irreducible real factors. Use the fact that is a root.    Check: . Since has real coefficients, is also a root, and the corresponding real factor is . Dividing by (write ; comparing coefficients gives ) yields Since has no real root, this is already the factorization into irreducible real factors.   "
},
{
  "id": "exercise-buch-einheitswurzeln-summe",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#exercise-buch-einheitswurzeln-summe",
  "type": "Exercise",
  "number": "1.2.4.5",
  "title": "",
  "body": "  Determine all sixth roots of unity (the solutions of ), and show that their sum equals .    With , , , , the solutions are , . After subtracting , the angles and correspond to the angles and ; from , we read off: If you add the real parts and the imaginary parts separately, both cancel in pairs:    "
},
{
  "id": "sec-folgen",
  "level": "1",
  "url": "sec-folgen.html",
  "type": "Section",
  "number": "2.1",
  "title": "Sequences",
  "body": " Sequences    After this section, you can    describe sequences explicitly and recursively, compute their first terms and distinguish arithmetic from geometric sequences;  prove boundedness and monotonicity of a sequence;  explain the -definition of convergence in your own words and apply it to simple examples;  determine limits with the limit laws, by comparing growth rates and with the squeeze theorem;  use the theorem on monotonic, bounded sequences and determine the limit of a recursive sequence from its fixed-point equation;  describe depreciation, compound interest, customer bases and gradient descent as sequences and assess their long-run behavior.     A learning algorithm reports its error after each training epoch: ; ; ; ; ; ; Is it worth continuing to train? Will the error reach zero at some point, or will it level off at about ? And how can you tell without waiting forever? These are exactly the questions that mathematics asks about a sequence : an infinite list of numbers — the account balance after each additional year, the approximation after each additional iteration step, the training error after each epoch. By the end of this section, you will be able to answer the question — and you will know where the answer reaches its limits.  To answer the question Does the list settle down? we first need a precise version of settles down — the limit — and then tools for actually computing limits without going back to the definition every time. This section proceeds in exactly this order. Along the way, you will meet rabbits, depreciation, loans, customer bases, a two-thousand-year-old method for computing square roots, and gradient descent from machine learning. You may already know some of this from school — compound interest, limits of rational expressions. What is new is above all the precision with which we now talk about the infinite.     The concept of a sequence   What comes next: ? The answer is obvious — each number is twice the previous one. Now a small experiment: mark points on a circle, connect each of them with every other one by a straight line segment, and count how many pieces the disk is cut into (with the points chosen so that no three segments ever meet in one point). For points, you get pieces. But for points, there are , not .  The lesson: a few initial values do not determine an infinite list of numbers. You need a rule that says how each term comes about. Such lists with a rule are called sequences .  In this subsection, we agree on how to write down sequences, introduce the two most important basic types, and collect two properties that are crucial for the long-run behavior: does the sequence stay within a fixed range ( boundedness ), and does it always move in the same direction ( monotonicity )? In the next subsection, we will see that the two together already guarantee convergence.    Explicit and recursive sequences   Sequence   A real sequence  is a function (or ) that assigns a real (or complex) number to every natural number . The number is called the th term of the sequence.  A sequence can be given explicitly , by a formula for in terms of (e.g., ), or recursively , by fixing one or more initial terms and computing each subsequent term from the previous ones (e.g., , ).    An explicit formula is convenient: you can compute any term directly, say , without knowing the 999 terms before it. A recursive rule, on the other hand, is often the natural description of a process — it says how to get from today's state to tomorrow's. This is exactly how computer programs work, too: in a loop that computes the new value from the old one.   Explicit and recursive description   Give the first four terms of the sequence . Also give the first four terms of the recursively defined sequence , .    Substituting gives , , , . For the recursive sequence, , , , — here we even get the explicit formula , but this is not so easy for every recursive sequence.    A recursion may also refer back to several predecessors. The most famous sequence of this kind comes from a book on arithmetic that Leonardo of Pisa, known today as Fibonacci, published in 1202. He asked how a population of rabbits develops if every pair produces a new pair every month, starting from its second month of life. The number of pairs in the th month is that is, : each term is the sum of the two previous ones. The rabbits are not very realistic biologically, but the sequence still turns up in a surprising number of places today, from sunflower seeds to the running-time analysis of algorithms.  Two simple types of sequences occur so often that they have their own names: either the same amount is added in each step, or each step multiplies by the same factor.   Arithmetic and geometric sequences   A sequence with for a fixed number is called an arithmetic sequence ; explicitly, . A sequence with for a fixed number is called a geometric sequence ; explicitly, .    The sequence from is arithmetic with , and the recursion from the definition is geometric with . Arithmetic sequences grow (or fall) evenly, like a staircase with steps of equal height; geometric sequences speed up or slow down — a difference that decides everything in the long run.   Application: Straight-line and declining-balance depreciation   A company buys a machine for € . In the accounts, the machine loses value every year. With straight-line depreciation , € is deducted every year; with declining-balance depreciation , of the current book value is deducted every year. Give the book values and after years explicitly. In which year is the book value under declining-balance depreciation higher than under straight-line depreciation for the first time?    Straight-line depreciation is an arithmetic sequence with , declining-balance depreciation a geometric one with : A small table of values (in €):                               At first, the declining-balance method depreciates faster — in the first year, € instead of € . But because it always deducts only of the remainder , its steps get smaller and smaller, while the straight-line staircase continues evenly. After nine years, the declining-balance book value (€ ) is higher than the straight-line one (€ ) for the first time. For the years that are missing from the table, it is easy to check that it is always lower before that, for example euros compared with euros. Finally, after ten years, the machine is fully depreciated under the straight-line method, but never under the declining-balance method: becomes arbitrarily small, but never zero. In practice, companies therefore switch from declining-balance to straight-line depreciation at some point.     Application: Paying off a loan   A company takes out a loan of € at interest per year. At the end of each year, the interest is due, and the company pays an installment of € . Set up a recursion for the outstanding balance after years, and determine in which year the loan is paid off.    Each year, the debt grows by and then decreases by the installment: Step by step: At the end of the fourth year, only euros are still owed. So the last payment is smaller than a full installment, and after four years the loan is paid off. The recursion describes the process exactly as a spreadsheet would compute it, row by row. It is neither arithmetic nor geometric, but a mixture of both: first multiply by , then subtract . Still, there is an explicit formula for ; you get it with the geometric sum formula from .    Whether a sequence starts at or at is a convention and does not change its long-run behavior. In the loan example, is natural, because gives the balance after years, and the balance after zero years is the initial amount. In exercises, simply pay attention to where the counting starts.    Boundedness and monotonicity  To assess the long-run behavior of a sequence, the first question is: does it stay within a fixed range, or can it become arbitrarily large? The declining-balance book value from stays between and , whereas Fibonacci's rabbit population eventually becomes too large for any cage.   Bounded and unbounded sequences   A (real or complex) sequence is called bounded if there is a real number such that If this is not the case, is called unbounded .    For real sequences, often only one direction matters: if for all , the sequence is called bounded above ; if for all , it is called bounded below . It is bounded if and only if both hold. Pay attention to the order of the quantifiers in the definition: one bound must work for all terms at the same time. It is not enough that each individual term is finite — that is true of every real sequence.   Proving boundedness   Show that is bounded and that is unbounded.    For all , we have (the numerator is always smaller than the denominator), so : the sequence is bounded with . For , on the other hand, for every bound there is an with (e.g., ). So there is no common upper bound for all terms of the sequence, and is unbounded. However, is bounded below, for example by .    The second question is: does the sequence always go in the same direction?   Monotonic sequences   A real sequence is called monotonically increasing if and strictly increasing if even for all . Similarly, is called monotonically decreasing (strictly decreasing) if (or ) for all .    A few computed terms show which kind of monotonicity to expect — but they are not a proof, because a sequence can rise at first and fall later (and the circle experiment at the beginning of this subsection showed how deceptive the first terms can be). There are two standard ways to prove monotonicity: you show that the difference  always has the same sign, or — for sequences with positive terms — that the ratio  is always greater than or always less than .   Proving monotonicity via the difference   Show that is strictly increasing.    We consider the difference of two consecutive terms: Since for all , this difference is always positive, so for all : the sequence is strictly increasing. Together with , we now know that the terms keep rising but never exceed ( ). A quicker way to the same result: , and an ever smaller amount is subtracted from .     The first ten terms of : the sequence is strictly increasing and stays below the bound .    A coordinate system with from to on the horizontal axis and from to on the vertical axis. Ten points rise from at and level off as they approach the dashed horizontal line at height , without reaching it.       Proving monotonicity via the ratio   Compute the first four terms of and show that the sequence is monotonically decreasing.     , , , . The first two terms are equal; after that, the sequence decreases. Since all terms are positive, we examine the ratio: So for all : the sequence is monotonically decreasing, but because , it is not strictly decreasing. Here the ratio is more convenient than the difference, because the powers of two cancel.     Application: Compound interest as a monotonic, unbounded sequence   An amount earns interest once a year at a fixed interest rate ; no money is withdrawn or deposited. The balance after years is then . Show that is strictly increasing and unbounded.    Since , we have , so and since for all , it follows that : the sequence is strictly increasing. Since with the growing base grows beyond every bound, for every there is an with — so the sequence is unbounded. At , the balance roughly doubles every years ( ); after years, it has grown to more than times its initial value. So money that a great-grandfather invested would be a nice sum for his great-grandchildren — provided that the bank and the currency last that long. In Germany, this was not the case at least twice in the 20th century. In , we examine what happens if instead the compounding period is divided more and more finely, while the interest rate is reduced proportionally.       Convergence of sequences   The sequence from gets closer and closer to the number ; other sequences grow beyond all bounds or jump back and forth aimlessly. Closer and closer, however, is too vague to compute with: the sequence also gets closer to with every step — but in fact it tends to (if the increments keep halving).  If you have ever programmed an iterative method, you know the practical version of this question: after how many steps is the result accurate enough? This is exactly how we define the limit: for every tolerance , however small, there is an index from which onward the sequence stays within this tolerance. After that, we introduce tools for computing limits without going back to this definition every time, and finally a theorem that guarantees the convergence of recursive sequences.    What does convergence mean?   Convergent sequence, limit   A real or complex sequence is called convergent with limit  , written or , if the following holds: for every , there exists an such that for all , we have In other words: for every , almost all terms of the sequence (i.e., all but finitely many) must lie within the -strip around . A sequence that does not converge is called divergent .    Read the definition as a game between two players: one of them sets a tolerance , and the other must name an index from which onward all terms of the sequence are closer than to . Convergence means: the second player always wins, no matter how small the tolerance is. The smaller , the larger usually becomes ( ).   Convergence of to : for , all terms from on lie in the -strip (blue); lies exactly on the boundary and does not count yet because of the strict sign. If you make smaller, becomes larger — but there is always such an .    A coordinate system with on the horizontal axis and on the vertical axis. Twelve points jump alternately above and below the horizontal line and approach it. A blue strip between and surrounds the line; the first three points lie outside, the fourth exactly on the upper boundary, and all points from on inside the strip. A dotted line marks .       Bounded but divergent   Show that the sequence is bounded but not convergent.    Since for all , the sequence is bounded (with ). Suppose it converges to some . Then, for , all terms from some on would have to lie in the interval , which has length . But two consecutive terms are always and , so they are at distance from each other — they do not both fit into an open interval of length . Contradiction: the sequence diverges. It jumps back and forth between and forever, without settling on a value. So boundedness alone does not guarantee convergence; we will see shortly which additional condition does.    Similar arguments show two things that are always tacitly assumed. First, a sequence has at most one limit: if there were two different candidates and , we could choose as half the distance, — then the two -strips do not overlap, and almost all terms cannot lie in both at the same time. Second, every convergent sequence is bounded : from on, all terms lie in the strip around , and the finitely many terms before that can also be captured by a sufficiently large bound. So an unbounded sequence can never converge — this often makes any further computation unnecessary.   Proving convergence directly from the definition   For and , determine a suitable for the tolerances and . Then show directly from the -definition that .    For , we have For , we need , so , i.e., : is enough. For , we need , so . Here, ten times the accuracy costs ten times as many terms.  Now in general: let be arbitrary. The inequality is equivalent to . So we choose . Here denotes the smallest integer greater than or equal to : you round up (the ceiling function ); for example, and . Then, for all , and hence . Since was arbitrary, it follows that .     Divergence to infinity   A real sequence is said to diverge to (or to ) if for every there exists an such that We then write (or ), although the sequence does not converge in the strict sense — is not a real number.     Divergent to plus or minus infinity, or not?   Which of the sequences , and diverge to plus or minus infinity?    For every , we have for all ; so , albeit very slowly (for , you need ). Likewise, for , so . The sequence with the terms is unbounded, but it does not diverge to plus or minus infinity — every second term is negative, so it does not stay above from any index onward, and it does not stay below from any index onward either.      Computing limits  The -definition is the foundation, but not a tool for computation. In practice, you break a sequence down into simple building blocks whose limits you know, and put them back together with the following rules.   Limit laws   Let and be convergent sequences in with and , and let . Then:        , if  for (if defined)  If is continuous ( ; intuitively: without jumps) and is real, then    Moreover, the squeeze theorem holds: if , , are sequences with for almost all and , then also converges to .     Important limits  With the limit laws, you reduce limits to a few basic building blocks that you should know:    for every , in particular and ;  for , for , and diverges (jumping back and forth) for ;  for every , and even ;  — more on this shortly, with compound interest.      Limits of rational sequences   Use the limit laws to determine the limits of , and .    For , all three terms converge individually ( , , ), so by the sum law . For , the denominator converges, , so . For , we divide the numerator and denominator by the highest power that occurs, : Only the ratio of the leading coefficients remains; all lower powers vanish in the limit.    The trick divide by the highest power leads to a rule of thumb for rational sequences that you can apply at a glance after a little practice. If the degree of the numerator is smaller than the degree of the denominator, the sequence tends to (as for ); if the degrees are equal, the limit is the quotient of the leading coefficients (as for ); if the degree of the numerator is larger, the sequence diverges to , for example . Still, a check with a large never hurts: for , , already quite close to .  Caution: the limit laws require that the individual limits exist . If two terms tend to and , the sum law says nothing — can give anything. Then you first have to transform the sequence in a clever way.   A limit of the form   Determine the limit of .    Both terms grow beyond all bounds, so the rules cannot be applied directly. The trick: multiply and divide by the sum , so that the formula for the difference of two squares removes the root: Now we divide the numerator and denominator by (under the root by ): where we used the continuity of the square root. Check with : . The naive guess both terms are about , so the limit is would have been wrong.    If a sequence cannot be transformed directly, the squeeze theorem often helps: you bound it from above and below by two simpler sequences with the same limit.   Squeezing with the squeeze theorem   Determine the limit of .    Under the root, the larger term dominates. We use this for an estimate in both directions: Taking the th root preserves the inequalities: On the left is the constant sequence ; on the right, because ( ), a sequence with limit . So by the squeeze theorem, : in the long run, only the largest term counts.     Null sequences by comparing growth rates   Show that is a null sequence.    For , the binomial theorem (it is neither covered nor assumed in this course; see, for example, Binomial theorem ) gives We use only one fact from it: all terms of the sum are , so the sum is at least as large as its term for . Hence By the squeeze theorem (squeezed between the null sequence and the null sequence ), it follows that . By the same principle, one shows more generally that every power of grows more slowly than every exponential function with , and that every exponential function in turn grows more slowly than the factorial . This hierarchy of growth rates  is very useful for determining limits: a quotient of two such terms tends to if the denominator is further to the right in the hierarchy.      Monotonic sequences and iterative methods  For recursive sequences, the tools so far often fail, because there is no explicit formula for . Here, a theorem that needs no formula at all can help. The idea is intuitive: a sequence that keeps rising but cannot break through a ceiling must pile up somewhere below the ceiling — it cannot keep climbing in large steps forever.   Convergence of monotonic, bounded sequences   Every real sequence that is monotonic and bounded is convergent.     Application: Computing square roots with Heron's method   For , define recursively , — this is Heron's method , a special case of Newton's method for finding zeros numerically, here applied to . Show that converges, and determine the limit.    First: all terms of the sequence are positive. Indeed, , and each subsequent term is the mean of the two positive numbers and , so it is positive again.  For every , we have , so after multiplying out and rearranging, where in the last step we divided by . In particular (with ), for all , so for and, since both sides are positive, . Dividing by gives for , and it follows that the sequence is monotonically decreasing from on and bounded below by , so by it is convergent, say to . Since the two sides of the recursion converge to and to , respectively, as , the limit satisfies the fixed-point equation . Multiplying by , subtracting and multiplying by gives, one after the other, and since , we finally get .  The case shows how fast this goes. The first steps by hand: and, rounded, compared with . The number of correct digits roughly doubles with each step — after only four iterations, more than ten decimal places are correct. Similar iterative methods are used in calculators and software libraries.  This principle — improving an approximation step by step by applying a rule again and again until the sequence of approximations settles down — underlies not only Newton's method, but also the iterative optimization methods that are used in data science to determine the parameters of learning models. We now look at the simplest of them.     Application: Gradient descent as a geometric sequence    Gradient descent searches for the minimum of a loss function by beginning with a starting value and repeatedly going a small step downhill — for a function of one variable, against the sign of the slope. For the simplest loss function (minimum at , slope ), the rule with learning rate  is Of course, you do not need the method for the toy function — you can see its minimum immediately. The point is the idea: the same procedure works in exactly the same way when the loss function depends on billions of parameters, as in deep learning, and nobody can see its minimum anymore.  Determine an explicit formula for , and decide for which learning rates the sequence converges to the minimum . What happens specifically for , and ?    Each step multiplies by the same factor , so — a geometric sequence. By , if and only if , i.e., . We subtract everywhere and then divide by . Here the following rule applies: if you multiply or divide an inequality by a negative number, the inequality signs are reversed. so .    : , so — a slow, monotonic approach.  : , so — the minimum is hit in a single step.  : , so — the sequence jumps back and forth around the minimum with growing absolute value and diverges.     Gradient descent for with starting value : the points on the parabola for three learning rates. For , they move monotonically toward the minimum; for , already lands exactly at the minimum; for , they jump back and forth with growing absolute value (on the right, a larger range is shown).    Three small pictures side by side, each with the parabola and colored iterates connected by arrows. Left, blue, : the points start at and move along the right branch of the parabola toward the lowest point in smaller and smaller steps, without changing sides ( , , , and so on). Middle, green, : a single arrow from directly to the lowest point . Right, orange, , with a larger range from to : the arrows jump alternately to the left and the right branch and climb higher and higher ( , , , , ).      So even for the simplest loss function, the learning rate alone decides whether the method converges, how fast it does so, or whether it explodes. In , we will introduce the slope as the derivative and carry out gradient descent by hand for more general functions.    The Heron trick can be written down as a recipe: if a recursive sequence with continuous converges, its limit must satisfy the fixed-point equation  . But watch out: the fixed-point equation only gives a candidate ; the candidate is the limit only once convergence is established. The sequence with has the fixed-point equation with the solution — and still diverges to . So the fixed-point equation only says where the sequence would end up if it ends up anywhere at all.   Application: A customer base with churn   A streaming service has subscribers at the beginning of the year. Every year, of the customers cancel (the churn rate , one of the most important key metrics in customer analytics), and new ones join. So the customer base after years satisfies Show that converges, and determine the long-term customer base.    The first terms , , suggest that the customer base grows — but more and more slowly. The fixed-point equation gives the candidate for the limit, namely . Before we accept as the limit, we establish convergence — and the candidate directly provides the right bound for this.   Bounded: if , then . Since , the sequence therefore stays below , step by step. Monotonic:  , and this is positive as long as — that is, always. By , converges, and the limit is the fixed point .  We can even take a closer look: if we subtract the fixed-point equation from the recursion, that is, the second line from the first, the cancels, and we get So the distance to the equilibrium is a geometric sequence. Applying this relation again and again gives so Check: , as above. Since , half of the way to the equilibrium is covered after about seven years. Economically interesting: the final customer base does not depend on the starting value at all, only on the ratio new customers per year divided by churn rate. To increase it, you have to change one of these two quantities.  For comparison, the loan from : also has a fixed point, namely — at this outstanding balance, the installment would exactly cover the interest, and the debt would stay the same forever. There, however, the factor is , so the distance to the fixed point grows from year to year: if you start with less debt, you will be free of debt at some point; if you start with more, your debt grows larger and larger. Whether a fixed point attracts or repels is decided by the factor in front of .    The trick with the distance to the equilibrium works for every recursion of the form with . Its fixed point is , and if you subtract from the recursion, what remains is The distance to the fixed point is a geometric sequence: for , it shrinks, and (for negative , the sequence jumps alternately above and below the fixed point); for , it grows, and the sequence moves away from the fixed point — unless it starts exactly there.  One last warning before we come to continuous compounding, because there is a common trap there. For , one might argue: , and to any power is , so . The numbers say something else: The mistake: the base and the exponent change at the same time . The base does move closer to , but the exponent grows so fast that the two effects balance each other. So is an indeterminate form just like and not the result of a computation.   Application: From compound interest to continuous compounding   An amount earns interest for one year at the interest rate . Instead of adding interest once at the end of the year, we divide the year into periods of equal length and add interest in each period at the proportional rate ; the interest itself immediately earns interest from then on (compound interest). The final amount after one year is then What happens to if the compounding period is divided more and more finely, that is, if we let ?    The sequence is monotonically increasing and bounded (this can be verified with the binomial theorem; as in , it is neither covered nor assumed in this course, see Binomial theorem ), so by it is convergent. Its limit is exactly the value of the exponential function at : (For , this is one of the usual definitions of Euler's number .) Hence the sequence of final amounts converges to the limiting case of continuous compounding . Contrary to what one might expect, dividing the compounding period arbitrarily finely therefore does not lead to unlimited growth, but to a finite limit. This effect is used in financial mathematics to model continuous compounding. And the limit contains the same exponential function that we will meet again in growth and decay processes in .  A numerical example: for euros and , annual compounding gives € , monthly compounding gives euros, and continuous compounding gives euros. So the difference between monthly and continuous compounding is only eleven cents.    And the training error from the beginning of this section? For everyone who is interested, one possible resolution follows here as optional material.   Application: The training error from the beginning (optional)   A learning algorithm reports the errors after the training epochs . What value does the error probably tend to if you continue training, and is it worth it?     The data. Let denote the error after epoch and the decrease from epoch to epoch . The table shows both, together with the ratio of successive decreases:                                         The decreases. From epoch to epoch, the error decreases by , then by , then by , and . The ratios , and show: each decrease is roughly one third of the previous one; only the last one, with , is closer to one half.   The bridge to the model. As a model, we take the recursion from the paragraph after , with unknown constants and . It describes the error itself, not its decrease. If we write it down for two consecutive epochs, and subtract the second equation from the first, drops out: (for the second form, multiply both sides by ). So the decreases form a geometric sequence with the same factor as the recursion — exactly what we observe in the data, with . By the same paragraph, the distance of the error from the limit also shrinks by the factor . So three quantities are involved: the error tends to ; its decreases and its distance from the limit shrink to about one third in each epoch.   The series. By how much does the error still decrease in total after the last measurement? With the last decrease , the future decreases are , , and so on, so the total decrease still to come is an infinite sum of the terms of a geometric sequence. Its first partial sums for are , then , then, rounded, They grow, but more and more slowly, and seem to level off at . When such an infinite sum has a finite value, and how to compute it, is exactly the topic of the next section, .   The limit. Looking ahead, we use the formula from : for , we have (with the first term ) With , this gives , so With the last observed ratio , the remaining decrease would be and — also about . So the error tends to about , not to , and training for a long time beyond this point brings hardly any further improvement.   The caveat. But remember the circle experiment from the beginning of : six values prove nothing. The forecast depends entirely on the assumption that the decreases keep shrinking to about a third each time — a model assumption, not a conclusion from the data.       Summary     Sequence: a function , ; given explicitly by a formula for or recursively by an initial term and a rule . Arithmetic: ; geometric: .   Bounded:  for all . Monotonic:  (increasing) or (decreasing) for all ; proof via the difference or the ratio .   Convergence  : for every , almost all terms lie in the strip . Otherwise divergent; divergent to plus or minus infinity if . The limit is unique, and every convergent sequence is bounded; but boundedness alone is not enough ( ).   Limit laws: limits of sums, products and quotients are the sums, products and quotients of the limits. Rational sequences: divide by the highest power (degree of the numerator smaller: limit ; equal: quotient of the leading coefficients; larger: divergent to plus or minus infinity). Transform the sequence first if it has the indeterminate form or (e.g., multiply and divide so that the formula for the difference of two squares applies). Squeeze theorem:  and   .   Basic building blocks:  , for , , ; hierarchy of growth rates .   Monotonic and bounded convergent. For recursive sequences, the fixed-point equation (the recursion with ) then gives the limit — as in Heron's method, . The fixed-point equation only gives a candidate; the candidate is the limit only once convergence is established. For ( ), we have with : the distance to the fixed point shrinks for and grows for .   Applications: straight-line depreciation is arithmetic, declining-balance depreciation is geometric; a customer base with a churn rate tends to new customers divided by churn rate ; compound interest grows without bound, continuous compounding gives ; gradient descent for is the geometric sequence and converges exactly for .      Exercises    Give the first four terms of the sequence . Also give the first four terms of the recursively defined sequence , , and find an explicit formula for .    Substituting gives , , , . For the recursive sequence, , , , — each term is less than the one before, so .      Show that is monotonically decreasing and bounded, and determine the limit.    We rewrite: As grows, gets smaller, so is strictly decreasing. Since for all , we have , so the sequence is bounded below by ; because of the monotonicity, it is bounded above by . By the theorem on monotonic, bounded sequences, converges, and since ,       Determine .    Divide the numerator and denominator by the highest power that occurs, :       A patient takes  mg of a drug every morning; by the next morning, her body has broken down half of the amount present. For the amount of the drug (in mg) directly after the th dose, we have , .  Compute , and .  Show that for all and that the sequence is monotonically increasing.  Determine the limit.        , , .  If , then ; since , the bound therefore holds for all . Moreover, , because .  Monotonic and bounded, hence convergent. The limit satisfies the fixed-point equation , so : in the long run, the amount of the drug after each dose levels off at  mg, twice the daily dose.        Use the squeeze theorem to show that is a null sequence.    Since for all , we have Both bounding sequences and converge to . So by the squeeze theorem, also converges to .     "
},
{
  "id": "sec-folgen-2",
  "level": "2",
  "url": "sec-folgen.html#sec-folgen-2",
  "type": "Objectives",
  "number": "2.1",
  "title": "",
  "body": "  After this section, you can    describe sequences explicitly and recursively, compute their first terms and distinguish arithmetic from geometric sequences;  prove boundedness and monotonicity of a sequence;  explain the -definition of convergence in your own words and apply it to simple examples;  determine limits with the limit laws, by comparing growth rates and with the squeeze theorem;  use the theorem on monotonic, bounded sequences and determine the limit of a recursive sequence from its fixed-point equation;  describe depreciation, compound interest, customer bases and gradient descent as sequences and assess their long-run behavior.   "
},
{
  "id": "def-folge",
  "level": "2",
  "url": "sec-folgen.html#def-folge",
  "type": "Definition",
  "number": "2.1.1",
  "title": "Sequence.",
  "body": " Sequence   A real sequence  is a function (or ) that assigns a real (or complex) number to every natural number . The number is called the th term of the sequence.  A sequence can be given explicitly , by a formula for in terms of (e.g., ), or recursively , by fixing one or more initial terms and computing each subsequent term from the previous ones (e.g., , ).   "
},
{
  "id": "ex-explizit-rekursiv-folge",
  "level": "2",
  "url": "sec-folgen.html#ex-explizit-rekursiv-folge",
  "type": "Example",
  "number": "2.1.2",
  "title": "Explicit and recursive description.",
  "body": " Explicit and recursive description   Give the first four terms of the sequence . Also give the first four terms of the recursively defined sequence , .    Substituting gives , , , . For the recursive sequence, , , , — here we even get the explicit formula , but this is not so easy for every recursive sequence.   "
},
{
  "id": "def-arithmetische-geometrische-folge",
  "level": "2",
  "url": "sec-folgen.html#def-arithmetische-geometrische-folge",
  "type": "Definition",
  "number": "2.1.3",
  "title": "Arithmetic and geometric sequences.",
  "body": " Arithmetic and geometric sequences   A sequence with for a fixed number is called an arithmetic sequence ; explicitly, . A sequence with for a fixed number is called a geometric sequence ; explicitly, .   "
},
{
  "id": "ex-anwendung-abschreibung",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-abschreibung",
  "type": "Example",
  "number": "2.1.4",
  "title": "Application: Straight-line and declining-balance depreciation.",
  "body": " Application: Straight-line and declining-balance depreciation   A company buys a machine for € . In the accounts, the machine loses value every year. With straight-line depreciation , € is deducted every year; with declining-balance depreciation , of the current book value is deducted every year. Give the book values and after years explicitly. In which year is the book value under declining-balance depreciation higher than under straight-line depreciation for the first time?    Straight-line depreciation is an arithmetic sequence with , declining-balance depreciation a geometric one with : A small table of values (in €):                               At first, the declining-balance method depreciates faster — in the first year, € instead of € . But because it always deducts only of the remainder , its steps get smaller and smaller, while the straight-line staircase continues evenly. After nine years, the declining-balance book value (€ ) is higher than the straight-line one (€ ) for the first time. For the years that are missing from the table, it is easy to check that it is always lower before that, for example euros compared with euros. Finally, after ten years, the machine is fully depreciated under the straight-line method, but never under the declining-balance method: becomes arbitrarily small, but never zero. In practice, companies therefore switch from declining-balance to straight-line depreciation at some point.   "
},
{
  "id": "ex-anwendung-kredit-rekursiv",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-kredit-rekursiv",
  "type": "Example",
  "number": "2.1.5",
  "title": "Application: Paying off a loan.",
  "body": " Application: Paying off a loan   A company takes out a loan of € at interest per year. At the end of each year, the interest is due, and the company pays an installment of € . Set up a recursion for the outstanding balance after years, and determine in which year the loan is paid off.    Each year, the debt grows by and then decreases by the installment: Step by step: At the end of the fourth year, only euros are still owed. So the last payment is smaller than a full installment, and after four years the loan is paid off. The recursion describes the process exactly as a spreadsheet would compute it, row by row. It is neither arithmetic nor geometric, but a mixture of both: first multiply by , then subtract . Still, there is an explicit formula for ; you get it with the geometric sum formula from .   "
},
{
  "id": "def-beschraenkte-folge",
  "level": "2",
  "url": "sec-folgen.html#def-beschraenkte-folge",
  "type": "Definition",
  "number": "2.1.6",
  "title": "Bounded and unbounded sequences.",
  "body": " Bounded and unbounded sequences   A (real or complex) sequence is called bounded if there is a real number such that If this is not the case, is called unbounded .   "
},
{
  "id": "ssub-beschraenktheit-monotonie-4",
  "level": "2",
  "url": "sec-folgen.html#ssub-beschraenktheit-monotonie-4",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "bounded above bounded below "
},
{
  "id": "ex-beschraenktheit-nachweis",
  "level": "2",
  "url": "sec-folgen.html#ex-beschraenktheit-nachweis",
  "type": "Example",
  "number": "2.1.7",
  "title": "Proving boundedness.",
  "body": " Proving boundedness   Show that is bounded and that is unbounded.    For all , we have (the numerator is always smaller than the denominator), so : the sequence is bounded with . For , on the other hand, for every bound there is an with (e.g., ). So there is no common upper bound for all terms of the sequence, and is unbounded. However, is bounded below, for example by .   "
},
{
  "id": "def-monotone-folge",
  "level": "2",
  "url": "sec-folgen.html#def-monotone-folge",
  "type": "Definition",
  "number": "2.1.8",
  "title": "Monotonic sequences.",
  "body": " Monotonic sequences   A real sequence is called monotonically increasing if and strictly increasing if even for all . Similarly, is called monotonically decreasing (strictly decreasing) if (or ) for all .   "
},
{
  "id": "ex-monotonie-nachweis-differenz",
  "level": "2",
  "url": "sec-folgen.html#ex-monotonie-nachweis-differenz",
  "type": "Example",
  "number": "2.1.9",
  "title": "Proving monotonicity via the difference.",
  "body": " Proving monotonicity via the difference   Show that is strictly increasing.    We consider the difference of two consecutive terms: Since for all , this difference is always positive, so for all : the sequence is strictly increasing. Together with , we now know that the terms keep rising but never exceed ( ). A quicker way to the same result: , and an ever smaller amount is subtracted from .   "
},
{
  "id": "fig-folge-n-durch-n-plus-1",
  "level": "2",
  "url": "sec-folgen.html#fig-folge-n-durch-n-plus-1",
  "type": "Figure",
  "number": "2.1.10",
  "title": "",
  "body": " The first ten terms of : the sequence is strictly increasing and stays below the bound .    A coordinate system with from to on the horizontal axis and from to on the vertical axis. Ten points rise from at and level off as they approach the dashed horizontal line at height , without reaching it.     "
},
{
  "id": "ex-monotonie-nachweis-quotient",
  "level": "2",
  "url": "sec-folgen.html#ex-monotonie-nachweis-quotient",
  "type": "Example",
  "number": "2.1.11",
  "title": "Proving monotonicity via the ratio.",
  "body": " Proving monotonicity via the ratio   Compute the first four terms of and show that the sequence is monotonically decreasing.     , , , . The first two terms are equal; after that, the sequence decreases. Since all terms are positive, we examine the ratio: So for all : the sequence is monotonically decreasing, but because , it is not strictly decreasing. Here the ratio is more convenient than the difference, because the powers of two cancel.   "
},
{
  "id": "ex-anwendung-zinseszins-monoton",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-zinseszins-monoton",
  "type": "Example",
  "number": "2.1.12",
  "title": "Application: Compound interest as a monotonic, unbounded sequence.",
  "body": " Application: Compound interest as a monotonic, unbounded sequence   An amount earns interest once a year at a fixed interest rate ; no money is withdrawn or deposited. The balance after years is then . Show that is strictly increasing and unbounded.    Since , we have , so and since for all , it follows that : the sequence is strictly increasing. Since with the growing base grows beyond every bound, for every there is an with — so the sequence is unbounded. At , the balance roughly doubles every years ( ); after years, it has grown to more than times its initial value. So money that a great-grandfather invested would be a nice sum for his great-grandchildren — provided that the bank and the currency last that long. In Germany, this was not the case at least twice in the 20th century. In , we examine what happens if instead the compounding period is divided more and more finely, while the interest rate is reduced proportionally.   "
},
{
  "id": "def-konvergente-folge",
  "level": "2",
  "url": "sec-folgen.html#def-konvergente-folge",
  "type": "Definition",
  "number": "2.1.13",
  "title": "Convergent sequence, limit.",
  "body": " Convergent sequence, limit   A real or complex sequence is called convergent with limit  , written or , if the following holds: for every , there exists an such that for all , we have In other words: for every , almost all terms of the sequence (i.e., all but finitely many) must lie within the -strip around . A sequence that does not converge is called divergent .   "
},
{
  "id": "fig-epsilon-streifen",
  "level": "2",
  "url": "sec-folgen.html#fig-epsilon-streifen",
  "type": "Figure",
  "number": "2.1.14",
  "title": "",
  "body": " Convergence of to : for , all terms from on lie in the -strip (blue); lies exactly on the boundary and does not count yet because of the strict sign. If you make smaller, becomes larger — but there is always such an .    A coordinate system with on the horizontal axis and on the vertical axis. Twelve points jump alternately above and below the horizontal line and approach it. A blue strip between and surrounds the line; the first three points lie outside, the fourth exactly on the upper boundary, and all points from on inside the strip. A dotted line marks .     "
},
{
  "id": "ex-beschraenkt-aber-divergent",
  "level": "2",
  "url": "sec-folgen.html#ex-beschraenkt-aber-divergent",
  "type": "Example",
  "number": "2.1.15",
  "title": "Bounded but divergent.",
  "body": " Bounded but divergent   Show that the sequence is bounded but not convergent.    Since for all , the sequence is bounded (with ). Suppose it converges to some . Then, for , all terms from some on would have to lie in the interval , which has length . But two consecutive terms are always and , so they are at distance from each other — they do not both fit into an open interval of length . Contradiction: the sequence diverges. It jumps back and forth between and forever, without settling on a value. So boundedness alone does not guarantee convergence; we will see shortly which additional condition does.   "
},
{
  "id": "ex-epsilon-nachweis-buch",
  "level": "2",
  "url": "sec-folgen.html#ex-epsilon-nachweis-buch",
  "type": "Example",
  "number": "2.1.16",
  "title": "Proving convergence directly from the definition.",
  "body": " Proving convergence directly from the definition   For and , determine a suitable for the tolerances and . Then show directly from the -definition that .    For , we have For , we need , so , i.e., : is enough. For , we need , so . Here, ten times the accuracy costs ten times as many terms.  Now in general: let be arbitrary. The inequality is equivalent to . So we choose . Here denotes the smallest integer greater than or equal to : you round up (the ceiling function ); for example, and . Then, for all , and hence . Since was arbitrary, it follows that .   "
},
{
  "id": "def-bestimmt-divergent",
  "level": "2",
  "url": "sec-folgen.html#def-bestimmt-divergent",
  "type": "Definition",
  "number": "2.1.17",
  "title": "Divergence to infinity.",
  "body": " Divergence to infinity   A real sequence is said to diverge to (or to ) if for every there exists an such that We then write (or ), although the sequence does not converge in the strict sense — is not a real number.   "
},
{
  "id": "ex-bestimmt-divergent",
  "level": "2",
  "url": "sec-folgen.html#ex-bestimmt-divergent",
  "type": "Example",
  "number": "2.1.18",
  "title": "Divergent to plus or minus infinity, or not?",
  "body": " Divergent to plus or minus infinity, or not?   Which of the sequences , and diverge to plus or minus infinity?    For every , we have for all ; so , albeit very slowly (for , you need ). Likewise, for , so . The sequence with the terms is unbounded, but it does not diverge to plus or minus infinity — every second term is negative, so it does not stay above from any index onward, and it does not stay below from any index onward either.   "
},
{
  "id": "thm-rechenregeln-grenzwerte",
  "level": "2",
  "url": "sec-folgen.html#thm-rechenregeln-grenzwerte",
  "type": "Theorem",
  "number": "2.1.19",
  "title": "Limit laws.",
  "body": " Limit laws   Let and be convergent sequences in with and , and let . Then:        , if  for (if defined)  If is continuous ( ; intuitively: without jumps) and is real, then    Moreover, the squeeze theorem holds: if , , are sequences with for almost all and , then also converges to .   "
},
{
  "id": "rem-wichtige-grenzwerte",
  "level": "2",
  "url": "sec-folgen.html#rem-wichtige-grenzwerte",
  "type": "Remark",
  "number": "2.1.20",
  "title": "Important limits.",
  "body": " Important limits  With the limit laws, you reduce limits to a few basic building blocks that you should know:    for every , in particular and ;  for , for , and diverges (jumping back and forth) for ;  for every , and even ;  — more on this shortly, with compound interest.    "
},
{
  "id": "ex-grenzwertsaetze-gebrochen-rational",
  "level": "2",
  "url": "sec-folgen.html#ex-grenzwertsaetze-gebrochen-rational",
  "type": "Example",
  "number": "2.1.21",
  "title": "Limits of rational sequences.",
  "body": " Limits of rational sequences   Use the limit laws to determine the limits of , and .    For , all three terms converge individually ( , , ), so by the sum law . For , the denominator converges, , so . For , we divide the numerator and denominator by the highest power that occurs, : Only the ratio of the leading coefficients remains; all lower powers vanish in the limit.   "
},
{
  "id": "ex-wurzeldifferenz-grenzwert",
  "level": "2",
  "url": "sec-folgen.html#ex-wurzeldifferenz-grenzwert",
  "type": "Example",
  "number": "2.1.22",
  "title": "A limit of the form “<span class=\"process-math\">\\(\\infty-\\infty\\)<\/span>”.",
  "body": " A limit of the form   Determine the limit of .    Both terms grow beyond all bounds, so the rules cannot be applied directly. The trick: multiply and divide by the sum , so that the formula for the difference of two squares removes the root: Now we divide the numerator and denominator by (under the root by ): where we used the continuity of the square root. Check with : . The naive guess both terms are about , so the limit is would have been wrong.   "
},
{
  "id": "ex-sandwich-n-te-wurzel",
  "level": "2",
  "url": "sec-folgen.html#ex-sandwich-n-te-wurzel",
  "type": "Example",
  "number": "2.1.23",
  "title": "Squeezing with the squeeze theorem.",
  "body": " Squeezing with the squeeze theorem   Determine the limit of .    Under the root, the larger term dominates. We use this for an estimate in both directions: Taking the th root preserves the inequalities: On the left is the constant sequence ; on the right, because ( ), a sequence with limit . So by the squeeze theorem, : in the long run, only the largest term counts.   "
},
{
  "id": "ex-nullfolgen-wachstumsvergleich",
  "level": "2",
  "url": "sec-folgen.html#ex-nullfolgen-wachstumsvergleich",
  "type": "Example",
  "number": "2.1.24",
  "title": "Null sequences by comparing growth rates.",
  "body": " Null sequences by comparing growth rates   Show that is a null sequence.    For , the binomial theorem (it is neither covered nor assumed in this course; see, for example, Binomial theorem ) gives We use only one fact from it: all terms of the sum are , so the sum is at least as large as its term for . Hence By the squeeze theorem (squeezed between the null sequence and the null sequence ), it follows that . By the same principle, one shows more generally that every power of grows more slowly than every exponential function with , and that every exponential function in turn grows more slowly than the factorial . This hierarchy of growth rates  is very useful for determining limits: a quotient of two such terms tends to if the denominator is further to the right in the hierarchy.   "
},
{
  "id": "thm-monotone-beschraenkte-folgen",
  "level": "2",
  "url": "sec-folgen.html#thm-monotone-beschraenkte-folgen",
  "type": "Theorem",
  "number": "2.1.25",
  "title": "Convergence of monotonic, bounded sequences.",
  "body": " Convergence of monotonic, bounded sequences   Every real sequence that is monotonic and bounded is convergent.   "
},
{
  "id": "ex-anwendung-heron-verfahren",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-heron-verfahren",
  "type": "Example",
  "number": "2.1.26",
  "title": "Application: Computing square roots with Heron’s method.",
  "body": " Application: Computing square roots with Heron's method   For , define recursively , — this is Heron's method , a special case of Newton's method for finding zeros numerically, here applied to . Show that converges, and determine the limit.    First: all terms of the sequence are positive. Indeed, , and each subsequent term is the mean of the two positive numbers and , so it is positive again.  For every , we have , so after multiplying out and rearranging, where in the last step we divided by . In particular (with ), for all , so for and, since both sides are positive, . Dividing by gives for , and it follows that the sequence is monotonically decreasing from on and bounded below by , so by it is convergent, say to . Since the two sides of the recursion converge to and to , respectively, as , the limit satisfies the fixed-point equation . Multiplying by , subtracting and multiplying by gives, one after the other, and since , we finally get .  The case shows how fast this goes. The first steps by hand: and, rounded, compared with . The number of correct digits roughly doubles with each step — after only four iterations, more than ten decimal places are correct. Similar iterative methods are used in calculators and software libraries.  This principle — improving an approximation step by step by applying a rule again and again until the sequence of approximations settles down — underlies not only Newton's method, but also the iterative optimization methods that are used in data science to determine the parameters of learning models. We now look at the simplest of them.   "
},
{
  "id": "ex-anwendung-gradientenabstieg-folge",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-gradientenabstieg-folge",
  "type": "Example",
  "number": "2.1.27",
  "title": "Application: Gradient descent as a geometric sequence.",
  "body": " Application: Gradient descent as a geometric sequence    Gradient descent searches for the minimum of a loss function by beginning with a starting value and repeatedly going a small step downhill — for a function of one variable, against the sign of the slope. For the simplest loss function (minimum at , slope ), the rule with learning rate  is Of course, you do not need the method for the toy function — you can see its minimum immediately. The point is the idea: the same procedure works in exactly the same way when the loss function depends on billions of parameters, as in deep learning, and nobody can see its minimum anymore.  Determine an explicit formula for , and decide for which learning rates the sequence converges to the minimum . What happens specifically for , and ?    Each step multiplies by the same factor , so — a geometric sequence. By , if and only if , i.e., . We subtract everywhere and then divide by . Here the following rule applies: if you multiply or divide an inequality by a negative number, the inequality signs are reversed. so .    : , so — a slow, monotonic approach.  : , so — the minimum is hit in a single step.  : , so — the sequence jumps back and forth around the minimum with growing absolute value and diverges.     Gradient descent for with starting value : the points on the parabola for three learning rates. For , they move monotonically toward the minimum; for , already lands exactly at the minimum; for , they jump back and forth with growing absolute value (on the right, a larger range is shown).    Three small pictures side by side, each with the parabola and colored iterates connected by arrows. Left, blue, : the points start at and move along the right branch of the parabola toward the lowest point in smaller and smaller steps, without changing sides ( , , , and so on). Middle, green, : a single arrow from directly to the lowest point . Right, orange, , with a larger range from to : the arrows jump alternately to the left and the right branch and climb higher and higher ( , , , , ).      So even for the simplest loss function, the learning rate alone decides whether the method converges, how fast it does so, or whether it explodes. In , we will introduce the slope as the derivative and carry out gradient descent by hand for more general functions.   "
},
{
  "id": "ssub-monotone-folgen-iterationen-6",
  "level": "2",
  "url": "sec-folgen.html#ssub-monotone-folgen-iterationen-6",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "fixed-point equation "
},
{
  "id": "ex-anwendung-kundenstamm-fixpunkt",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-kundenstamm-fixpunkt",
  "type": "Example",
  "number": "2.1.29",
  "title": "Application: A customer base with churn.",
  "body": " Application: A customer base with churn   A streaming service has subscribers at the beginning of the year. Every year, of the customers cancel (the churn rate , one of the most important key metrics in customer analytics), and new ones join. So the customer base after years satisfies Show that converges, and determine the long-term customer base.    The first terms , , suggest that the customer base grows — but more and more slowly. The fixed-point equation gives the candidate for the limit, namely . Before we accept as the limit, we establish convergence — and the candidate directly provides the right bound for this.   Bounded: if , then . Since , the sequence therefore stays below , step by step. Monotonic:  , and this is positive as long as — that is, always. By , converges, and the limit is the fixed point .  We can even take a closer look: if we subtract the fixed-point equation from the recursion, that is, the second line from the first, the cancels, and we get So the distance to the equilibrium is a geometric sequence. Applying this relation again and again gives so Check: , as above. Since , half of the way to the equilibrium is covered after about seven years. Economically interesting: the final customer base does not depend on the starting value at all, only on the ratio new customers per year divided by churn rate. To increase it, you have to change one of these two quantities.  For comparison, the loan from : also has a fixed point, namely — at this outstanding balance, the installment would exactly cover the interest, and the debt would stay the same forever. There, however, the factor is , so the distance to the fixed point grows from year to year: if you start with less debt, you will be free of debt at some point; if you start with more, your debt grows larger and larger. Whether a fixed point attracts or repels is decided by the factor in front of .   "
},
{
  "id": "ex-anwendung-stetige-verzinsung",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-stetige-verzinsung",
  "type": "Example",
  "number": "2.1.30",
  "title": "Application: From compound interest to continuous compounding.",
  "body": " Application: From compound interest to continuous compounding   An amount earns interest for one year at the interest rate . Instead of adding interest once at the end of the year, we divide the year into periods of equal length and add interest in each period at the proportional rate ; the interest itself immediately earns interest from then on (compound interest). The final amount after one year is then What happens to if the compounding period is divided more and more finely, that is, if we let ?    The sequence is monotonically increasing and bounded (this can be verified with the binomial theorem; as in , it is neither covered nor assumed in this course, see Binomial theorem ), so by it is convergent. Its limit is exactly the value of the exponential function at : (For , this is one of the usual definitions of Euler's number .) Hence the sequence of final amounts converges to the limiting case of continuous compounding . Contrary to what one might expect, dividing the compounding period arbitrarily finely therefore does not lead to unlimited growth, but to a finite limit. This effect is used in financial mathematics to model continuous compounding. And the limit contains the same exponential function that we will meet again in growth and decay processes in .  A numerical example: for euros and , annual compounding gives € , monthly compounding gives euros, and continuous compounding gives euros. So the difference between monthly and continuous compounding is only eleven cents.   "
},
{
  "id": "ex-anwendung-trainingsfehler",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-trainingsfehler",
  "type": "Example",
  "number": "2.1.31",
  "title": "Application: The training error from the beginning (optional).",
  "body": " Application: The training error from the beginning (optional)   A learning algorithm reports the errors after the training epochs . What value does the error probably tend to if you continue training, and is it worth it?     The data. Let denote the error after epoch and the decrease from epoch to epoch . The table shows both, together with the ratio of successive decreases:                                         The decreases. From epoch to epoch, the error decreases by , then by , then by , and . The ratios , and show: each decrease is roughly one third of the previous one; only the last one, with , is closer to one half.   The bridge to the model. As a model, we take the recursion from the paragraph after , with unknown constants and . It describes the error itself, not its decrease. If we write it down for two consecutive epochs, and subtract the second equation from the first, drops out: (for the second form, multiply both sides by ). So the decreases form a geometric sequence with the same factor as the recursion — exactly what we observe in the data, with . By the same paragraph, the distance of the error from the limit also shrinks by the factor . So three quantities are involved: the error tends to ; its decreases and its distance from the limit shrink to about one third in each epoch.   The series. By how much does the error still decrease in total after the last measurement? With the last decrease , the future decreases are , , and so on, so the total decrease still to come is an infinite sum of the terms of a geometric sequence. Its first partial sums for are , then , then, rounded, They grow, but more and more slowly, and seem to level off at . When such an infinite sum has a finite value, and how to compute it, is exactly the topic of the next section, .   The limit. Looking ahead, we use the formula from : for , we have (with the first term ) With , this gives , so With the last observed ratio , the remaining decrease would be and — also about . So the error tends to about , not to , and training for a long time beyond this point brings hardly any further improvement.   The caveat. But remember the circle experiment from the beginning of : six values prove nothing. The forecast depends entirely on the assumption that the decreases keep shrinking to about a third each time — a model assumption, not a conclusion from the data.   "
},
{
  "id": "sub-zusammenfassung-2-1-2",
  "level": "2",
  "url": "sec-folgen.html#sub-zusammenfassung-2-1-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Sequence: Bounded: Monotonic: Convergence Limit laws: Squeeze theorem: Basic building blocks: Monotonic and bounded convergent. Applications: "
},
{
  "id": "exercise-buch-explizit-rekursiv",
  "level": "2",
  "url": "sec-folgen.html#exercise-buch-explizit-rekursiv",
  "type": "Exercise",
  "number": "2.1.4.1",
  "title": "",
  "body": "  Give the first four terms of the sequence . Also give the first four terms of the recursively defined sequence , , and find an explicit formula for .    Substituting gives , , , . For the recursive sequence, , , , — each term is less than the one before, so .   "
},
{
  "id": "exercise-buch-monotonie-grenzwert",
  "level": "2",
  "url": "sec-folgen.html#exercise-buch-monotonie-grenzwert",
  "type": "Exercise",
  "number": "2.1.4.2",
  "title": "",
  "body": "  Show that is monotonically decreasing and bounded, and determine the limit.    We rewrite: As grows, gets smaller, so is strictly decreasing. Since for all , we have , so the sequence is bounded below by ; because of the monotonicity, it is bounded above by . By the theorem on monotonic, bounded sequences, converges, and since ,    "
},
{
  "id": "exercise-buch-grenzwertsaetze-rational",
  "level": "2",
  "url": "sec-folgen.html#exercise-buch-grenzwertsaetze-rational",
  "type": "Exercise",
  "number": "2.1.4.3",
  "title": "",
  "body": "  Determine .    Divide the numerator and denominator by the highest power that occurs, :    "
},
{
  "id": "exercise-buch-medikamentenspiegel",
  "level": "2",
  "url": "sec-folgen.html#exercise-buch-medikamentenspiegel",
  "type": "Exercise",
  "number": "2.1.4.4",
  "title": "",
  "body": "  A patient takes  mg of a drug every morning; by the next morning, her body has broken down half of the amount present. For the amount of the drug (in mg) directly after the th dose, we have , .  Compute , and .  Show that for all and that the sequence is monotonically increasing.  Determine the limit.        , , .  If , then ; since , the bound therefore holds for all . Moreover, , because .  Monotonic and bounded, hence convergent. The limit satisfies the fixed-point equation , so : in the long run, the amount of the drug after each dose levels off at  mg, twice the daily dose.     "
},
{
  "id": "exercise-buch-sandwich-sinus",
  "level": "2",
  "url": "sec-folgen.html#exercise-buch-sandwich-sinus",
  "type": "Exercise",
  "number": "2.1.4.5",
  "title": "",
  "body": "  Use the squeeze theorem to show that is a null sequence.    Since for all , we have Both bounding sequences and converge to . So by the squeeze theorem, also converges to .   "
},
{
  "id": "sec-reihen",
  "level": "1",
  "url": "sec-reihen.html",
  "type": "Section",
  "number": "2.2",
  "title": "Series",
  "body": " Series    After this section, you can    explain a series as the sequence of its partial sums and say what convergence and absolute convergence of a series mean;  sum geometric series, also with a shifted starting index;  apply the term test, the comparison test (with a majorant or a minorant), the ratio test, the root test and the alternating series test — and choose the right test for a given series;  use the harmonic and the alternating harmonic series to explain why null sequence is not enough and why convergent does not mean absolutely convergent;  read annuity payments, present values, discounted rewards and conditions on learning rates as series, and bound the truncation error of a series with a geometric majorant.     Can a sum of infinitely many positive numbers be finite? says yes — the sum is . says no — it grows without bound, although its terms also go to zero. The difference is not obvious. This is exactly why we need a precise notion of convergence for infinite sums and a handful of tests that decide convergence without knowing the sum.  The section begins with the notion of a series and its most important representative, the geometric series. With it, you compute loans, annuities and discounted returns in reinforcement learning. Then come the convergence tests, each with examples that show what it can do and what its limitations are. Along the way, books stick out over the edge of a table, a computer calculates , and a series changes its sum just because its terms are rearranged.    The notion of a series   Imagine you are walking toward a wall that is two meters away. With the first step, you cover one meter; with every further step, half of the previous one: , then , then meter, and so on. Do you ever reach the wall? After every step, the remaining distance is exactly as long as your last step — so you never reach the wall, but you get arbitrarily close to it. The total distance you cover is   Such thought experiments go back to the Greek philosopher Zeno of Elea (5th century BC) — but Zeno used them to prove that motion is impossible. Behind them lies exactly the question from the beginning of this section. The answer comes from the notion of a limit in . We add step by step, look at the sequence of intermediate results and ask whether it converges. So a series is nothing but a sequence of a very special kind, and everything we know about sequences carries over to infinite sums.     Series and partial sums   Series, partial sum, convergence   Let be a real or complex sequence. The formal expression is called an (infinite) series . The sequence of partial sums  is itself an ordinary sequence. If converges, the series is called convergent , and is called the sum of the series , written . A series that does not converge is called divergent . The series is called absolutely convergent if the series of absolute values converges. In particular, every absolutely convergent series is also convergent — the converse does not hold, as we will see in this section.     A series is not really an infinite sum  In mathematics, there are no actual infinite sums: the notation is a purely symbolic abbreviation. For a convergent series, the expression stands exactly for the well-defined fact — nothing else. This precision is more than a technicality: rules that are obvious for finite sums (such as rearranging the terms in any order) do not automatically hold for infinite series in general. We will state the valid rules for convergent series explicitly further below.    The partial sums of the running example   For , compute the partial sums , find a formula for , and determine the sum of the series.    We add step by step: The distance to is halved with every step: , , , …; in general, Since , converges to , so ( ). Note: no partial sum reaches the sum; the sum is the limit.   The partial sums of on the number line: each term covers half of the remaining distance to .    A number line from to . The partial sums , , , and are marked. Arcs above the line show the terms , , , , which get shorter and shorter and approach .        There is no guarantee that a series converges. The simplest series of all shows the opposite — and it comes with a famous anecdote.   Young Gauss and a divergent series (optional)   When Carl Friedrich Gauss was in elementary school, his teacher is said to have given him the task of adding the numbers from to — hoping for a quiet hour. Gauss was done after a few moments. Determine the partial sums of the series as cleverly as he did. Does the series converge?    The trick: write the sum twice, one above the other, once forward and once backward, and add column by column. So ; for young Gauss, . The sequence of partial sums grows without bound, so the series diverges to — which is not very surprising, since the terms keep getting larger. Things only get interesting when the terms go to . Then anything can happen, as you will see shortly.      The geometric series  In the running example, each term is the previous one multiplied by the same factor . Series of this kind are the most important of all — in financial mathematics as well as for comparison with other series — and there is a closed formula for them.   The geometric series   For (or ) and (or ), is called a geometric series — exactly the kind of series that our opening example is (there, , ). Derive a closed formula for the partial sum , and determine for which the series converges.    For , we have , which does not converge for . So let . The trick is to multiply by — the sum then telescopes. We write out and , one below the other, so that equal terms are lined up vertically: If we subtract the second line from the first, all terms from to cancel, and what remains is Written briefly in summation notation, the same computation is since all the middle terms cancel each other. Dividing by gives the closed formula For , we have ( ), so converges to For and , is not a null sequence, so the series diverges (the term test, , shows this immediately; for , you can also see it directly from the formula for ).     Computing the sums of geometric series   Determine and (note that the second sum starts only at ).    With the formula from and , (so ): In the second series, the summation index starts only at instead of . We factor out the common factor and reduce the sum to a geometric series that starts at : (Alternatively, we could have computed the complete sum from and then subtracted the missing initial terms : — both ways are equally common for series with a shifted starting index.)     Repeating decimals as geometric series   Write and as fractions.    A repeating decimal is a geometric series: each block is a hundred times smaller than the previous one. Likewise, This surprises many people: is not just below , but exactly  . By definition, is the limit of the partial sums , and this limit is — even though none of the partial sums is itself.    The finite sum formula from is useful on its own as well, for example for installment payments.   Application: The outstanding balance of a loan in explicit form   In , we computed the outstanding balance recursively: , . Use the geometric sum formula to derive an explicit formula for , and check it for .    With and , we unroll the recursion: and in general . The expression in parentheses is a finite geometric sum, so Check for : , so the same value as in the step-by-step computation. With the explicit formula, we can now also ask the reverse question: which installment is needed so that the loan is paid off after exactly years? We set and solve for . This is the annuity formula of financial mathematics — and we will work it out right away.     Application: The annuity formula   With an amortizing loan , you pay the same amount (the annuity payment ) every year, chosen so that the loan is paid off after exactly years. From the explicit formula in , derive a formula for . What is the annuity payment for the loan of € at interest if it is to be paid off in exactly four years? How much interest do you pay in total?    From , it follows that With , , and , we get (in €) In total, you pay back euros, of which € is interest. For comparison: with the installment of € from , the loan was also paid off after four years, but the last payment was not a round number. The annuity payment spreads the burden evenly — this is exactly how banks compute your monthly installment for a car loan or a mortgage, only with months instead of years.     Application: The present value of a perpetuity   In capital budgeting, you often need the present value of a stream of future payments: how much is a series of future payments worth today if you discount at a periodic interest rate ? A perpetuity pays a fixed amount at the end of every period, indefinitely. The present value of a payment that is made only after periods is (this is just the compound interest formula from in reverse). The present value of the entire perpetuity is therefore Show that , and compute concretely for euros per year and .    With , we always have because , and the series is geometric, except that it starts at instead of : Substituting gives so , as claimed. For and , we get A perpetual annual payment of € is worth € today at interest — although an unlimited amount of money flows over the entire (infinite) duration, its present value is finite, because later payments are discounted more and more strongly.     Application: Discounted reward in reinforcement learning   In reinforcement learning , an agent (for example, a warehouse robot or a game-playing program) learns from rewards that it receives in successive time steps. What is evaluated is not the next reward alone, but the discounted return  with a discount factor  that gives later rewards less weight. Suppose the agent receives the same reward in every step. Determine for and for , and interpret the difference.    For a constant reward, is a geometric series with and , so For , this gives ; for , on the other hand, . The value is something like the agent's planning horizon : with , essentially the next ten steps count; with , the next hundred. So the discount factor plays exactly the role of the financial discount factor from — financial mathematics and reinforcement learning compute with the same series here.    The geometric series is thus something like the Swiss Army knife of this section: it turns repeating decimals into fractions, computes loans and annuities, evaluates rewards in machine learning — and in the next subsection, it serves as the benchmark against which we measure other series.     Convergence tests for series   With the geometric series, we were lucky: there is a closed formula for its partial sums. That is the exception. Even for a harmless-looking series such as , there is no simple formula for — and yet we want to know whether it converges. In practice, this is often even the more important question. Does an algorithm, an approximation formula or a financial model yield a finite value at all? You must settle this before you compute the value numerically.  This is what convergence tests are for: tests that read off from the terms alone whether the series converges. We begin with a test that can only prove divergence, then compare series with each other, and then learn two automatic tests and a test for series with alternating signs. At the end, there is a strategy for which test to try when.    The term test and the harmonic series   Term test (divergence test)   If the series is convergent, then is a null sequence: (Reason: with , we have ; if converges to some , then so does , so .) This condition is necessary, but not sufficient — the following example shows a series whose terms form a null sequence but which diverges nonetheless.     The harmonic series diverges   Show that the harmonic series  diverges, although is a null sequence.    We bound the partial sum from below by grouping the terms in blocks of length : The th block (for ) contains terms, each of which is at least as large as the last, smallest term of the block. So each block is at least . Since there are such blocks, it follows that For , this lower bound grows without bound, so , and hence also , is unbounded and therefore divergent. The harmonic series is thus the standard example showing that the necessary condition from the term test is not sufficient — we will use it several more times in the rest of this section as a comparison series.  A few numbers show how treacherous this divergence is: the sum of the first thousand terms is only , and to exceed , you need terms. Anyone who only looks at a computer output of the first partial sums could easily guess that the series converges.    That the harmonic series grows so extremely slowly, but still without bound, has concrete and sometimes surprising consequences. You will now see two of them: one to try out on your desk and one from text analysis.   Application: A stack of books over the edge of a table   You stack identical books of length on top of each other at the edge of a table, each book on the previous one, and push them as far to the right as possible without the stack toppling over. A stack is stable as long as the following holds for every book: the common center of mass of all books above it does not lie to the right of its right edge; likewise, the center of mass of the whole stack must not lie to the right of the table edge. One can show that the overhang is largest when the th book from the top sticks out exactly beyond the book below it (or beyond the table edge). How far does the edge of the top book then stick out beyond the table edge in total? Is more than one whole book length possible?    The total overhang is the sum of the individual overhangs: that is, half the th partial sum of the harmonic series. With just four books, this is already : the top book lies completely beyond the table edge; no part of it is above the table anymore ( ). Because the harmonic series diverges, the overhang can even be made arbitrarily large with enough books. However, you already need books for an overhang of two book lengths, for three and about million for ten — the divergence is real, but painfully slow.  Where the overhangs come from can be explained by viewing the center of mass as an average. Suppose the common center of mass of the top books lies exactly above the right edge of book , and book has its own center of mass further to the left. Then the center of mass of all books lies at the weighted average , that is, exactly to the left of the edge. This is where the edge of the next book must be.   Four books of length , stacked optimally: from top to bottom, the overhangs are , , and ; in total, the top book sticks out beyond the table edge.    A table on the left, whose right edge is marked by a vertical dashed line. On it lie four books of equal length, drawn as flat rectangles on top of each other, each shifted to the right relative to the one below. The bottom book sticks out one eighth beyond the table edge; the top book lies completely to the right of the table edge, and its right edge is book lengths away from the table edge.         Application: Zipf's law in text analysis   If you count how often each word occurs in a large text corpus and sort the words by frequency, you observe Zipf's law surprisingly accurately: the th most frequent word occurs about times as often as the most frequent one. For a vocabulary of words, the share of the most frequent words in the whole text is then What share of a text do the most frequent words cover if the vocabulary comprises words? Use , and the approximation for large (the number is called the Euler–Mascheroni constant).    With , the share is So the most frequent words — the,  of,  and,  in, … — make up almost half of a typical text, although they are only of the vocabulary. This is why, in text analysis, such stop words are often filtered out before searching for words that carry meaning. And here the slow divergence of the harmonic series shows its practical side: because grows only logarithmically with the vocabulary, even a vocabulary twice as large does not change this picture much.      Comparison tests  Everyone knows the idea of the next test from everyday life: if you spend less than someone whose spending is bounded, your own spending is bounded too. For series with nonnegative terms, the partial sums are monotonically increasing; if they stay below a bound, they converge by .   Comparison test   Suppose we want to determine whether the series converges.    If there is a convergent series with such that for all from some index on, then converges (even absolutely). The series is called a convergent majorant .  If there is a divergent series with such that for all from some index on, then diverges. The series is called a divergent minorant . (Here the themselves — not just their absolute values — must lie above : from , it only follows that does not converge absolutely ; the alternating harmonic series further below shows that it can converge nonetheless.)       Applying the comparison test   Determine whether and converge.    For the first series, for all , so The geometric series converges ( ), so it is a convergent majorant: converges.  For the second series, for all , so . The harmonic series diverges ( ), so it is a divergent minorant: diverges as well.     Application: Step sizes in stochastic gradient descent   In stochastic gradient descent (SGD), which is used in data science to train the parameters of many models, you use a step size (learning rate) in every step . To guarantee that the method converges, the classical requirements are the Robbins–Monro conditions  the first condition ensures that the sum of the steps is large enough to reach every point from every starting point; the second, that the steps shrink fast enough for the noise of the stochastic gradients to average out. Show that the classical choice satisfies both conditions.    The first condition is exactly the divergence of the harmonic series , which we showed in .  For the second condition, we use the comparison test to show that converges. For , the partial fraction decomposition holds (a technique that is neither presupposed nor covered in this course — you can check the equation by bringing the right-hand side to a common denominator), and since , it follows that The right-hand side is a telescoping series: its partial sum is for every (all the middle terms cancel). In particular, this telescoping series is convergent (limit ) and therefore a convergent majorant for . With the term added, is therefore convergent as well (with a sum less than ). The step size thus satisfies both Robbins–Monro conditions — one of the reasons why -type decay schedules for the learning rate are so common in optimization.    A majorant often does more than just prove convergence: if it is geometric, you can also use it to estimate how much is still missing when you stop after finitely many terms. This is exactly what you need when a computer is actually supposed to evaluate a series.   Application: How does a computer calculate ?   One can show that holds. Truncated power series of this kind — after a clever reduction of the argument and with slightly optimized coefficients — are behind the function exp in many software libraries.  Use the comparison test to show that the series converges, and conclude that .  Compute the partial sum , and estimate the error with a geometric series.        For , , so . The geometric series is a convergent majorant, and .  . For the remainder, we factor out ; every further factor in the denominator is at least : In fact, , so the error is — the bound is almost exact.    So seven terms already give three correct decimal places, and the error bound tells you in advance when you may stop. Because the factorial in the denominator grows so fast, just under twenty terms suffice for the full precision of a computer (about digits).      Ratio test and root test  For the comparison tests, you need a suitable comparison series, and finding one takes experience. The following two tests, in contrast, work automatically : you compute a limit and read off the result. Both are based on a comparison with the geometric series — if, in the long run, the terms shrink at least as fast as with , the series converges.   Ratio test   Let be a series with for all from some index on, and let the sequence converge.    If , then is absolutely convergent.  If , then is divergent.    In the borderline case , the test gives no conclusion: both the divergent harmonic series and the convergent series have the ratio limit . Then another test must be used, for example a comparison with a known series.     Ratio test: One convergent and one divergent series   Determine whether and converge.    For , the powers of three cancel almost completely: So the first series converges (absolutely). For , we have so the second series diverges. This fits the hierarchy of growth rates from : the exponential function dominates every power of — in the denominator, it ensures convergence; in the numerator, divergence.     Applying the ratio test (optional)   Determine whether converges.    With , we have From , we already know that , so By the ratio test, the series converges (absolutely).     Root test   Let be a series, and let the sequence converge.    If , then is absolutely convergent.  If , then is divergent.       Applying the root test   Determine whether converges.    Here the th root simply undoes the th power. Unlike with the ratio test, nothing has to be canceled first: By the root test, the series converges (absolutely). This example shows why, for series with a power , it is worth trying the root test first: here it avoids the somewhat more unwieldy computation of the ratio altogether.      Alternating series  Whenever the tests so far show convergence, they even show absolute convergence. If the signs of the terms alternate, however, positive and negative terms can balance each other out, and the series can converge although the series of absolute values diverges.   Alternating series test (Leibniz criterion)   Let be a monotonically decreasing real null sequence with . Then the alternating series  converges.     Error bound for the alternating series test  Under the hypotheses of the alternating series test, the partial sums oscillate around the limit with steadily decreasing amplitude: consecutive partial sums lie alternately above and below and so enclose more and more tightly. From this follows the useful error bound — the error when stopping after the th term is at most as large as the absolute value of the first omitted term. This lets you estimate in advance how many terms are needed for a desired accuracy, without knowing the (often unknown) limit itself — a principle that is also used to bound the error of truncated series approximations (for example, of Taylor series).    The alternating harmonic series: Convergent, but not absolutely   Show that converges, but does not converge absolutely.    The sequence is a monotonically decreasing null sequence, so the series converges by the alternating series test. The series of absolute values, however, is that is, exactly the harmonic series, which diverges by . So the series converges, but not absolutely — such a series is called conditionally convergent . (One can show that its sum is , but the proof is beyond the scope of this section.) In particular, this example shows that the converse of the statement absolutely convergent convergent from is indeed false.    Conditionally convergent series are delicate objects. In finite sums, you may rearrange the terms as you like — in a conditionally convergent series, you may not. The next example shows this; at first, it seems unbelievable. It is exactly the warning from , now with numbers.   Rearranging changes the sum   Let be the sum of the alternating harmonic series. We rearrange the same terms: one positive term, then two negative ones, and so on: Convince yourself that every term of occurs exactly once, and show that .    The positive terms appear in their original order, and the negative ones, and , together run through all even denominators — so every term is used exactly once. Now we group the terms in threes and simplify the first two terms of each group, using : For , this gives (Because the terms go to , grouping them in threes does not change the limit.) So the same numbers, in a different order, give half the sum — with , we get . Bernhard Riemann even showed that, by rearranging a conditionally convergent series cleverly, you can make it converge to any number you like. With absolutely convergent series, this never happens; there, rearranging is allowed.     How many terms do you need?   Around 1735, Leonhard Euler proved, to the astonishment of his contemporaries, that — the Basel problem, which Jakob Bernoulli, among others, had tried and failed to solve. From this, it also follows that (we do not give the proof here). How many terms must you add so that the error bound of the alternating series test guarantees an error smaller than ? Compare with the series for from and with the alternating harmonic series.    The absolute values form a monotonically decreasing null sequence, so the error bound holds. We need ; since and , this is the case from on, that is, . So the bound guarantees the desired accuracy after terms ( ) at the latest. In fact, already suffice — the bound is cautious, but it is guaranteed.  For comparison: for the series for , seven terms were enough. For the alternating harmonic series, the error bound gives , and this guarantees an error below only after about a thousand terms. What matters is how fast the terms become small: falls rapidly, reasonably fast, only sluggishly. So the error bound guarantees convergence, but it also tells you honestly how slow it can be.      Rules for series and overview  Finally, we record which rules actually hold for convergent series, and we summarize how best to proceed with an unknown series.   Which test when?  Each test is suited to a typical kind of series. A proven order for examining a series :    Null sequence? If does not go to , you are done: the series diverges.  A power in the term? Root test. Factorials or th powers of fixed numbers ( , )? Ratio test.  Alternating signs with monotonically decreasing absolute values? Alternating series test (and you get the error bound for free).  Otherwise — in particular for terms that are quotients of polynomials, such as — compare with a known series: the geometric series and as convergent majorants, and as divergent minorants.    If the ratio test or the root test gives the limit , then — unless step 1 has already decided — only step 3 or 4 can help.    Choosing the right test   Use the strategy from to decide whether the following series converge:       The power suggests the root test — but , no conclusion. Step 1 helps: . Not a null sequence, so the series diverges.  Factorial: ratio test. . The series converges. Remarkably, the terms even grow at first, up to more than at and . But the test only looks at the long-run behavior; finitely many large initial terms do not change convergence.  Alternating signs, and is a monotonically decreasing null sequence: by the alternating series test, the series converges. It does not converge absolutely, because diverges ( ).  Quotient of polynomials: for large , , so we suspect divergence. Since , we have , and diverges as half the harmonic series. This divergent minorant shows that the series diverges.    Part (a) shows why step 1 always comes first: it would have saved the detour via the root test.     Rules for convergent series   Let and be convergent series and (or ). Then the following hold:    ( Multiplication by a constant ) The series is convergent, and .  ( Sum rule ) The series is convergent, and .  ( Cauchy product ) If and are, moreover, absolutely convergent, then the Cauchy product  of the two series with also converges, and The assumption of absolute convergence is essential here: for series that are only conditionally convergent, the Cauchy product can diverge.       The Cauchy product of a geometric series with itself (optional)   Let . Form the Cauchy product of the geometric series with itself, and check the result numerically for .    With , the th coefficient of the Cauchy product is since each of the terms equals . The geometric series is absolutely convergent for , because is itself a convergent geometric series. So the rule for the Cauchy product from applies, and we obtain the identity For , the right-hand side gives . The left-hand side is , with the partial sums which indeed approach . Incidentally, we have summed a series without needing a formula for its partial sums — just by multiplying two geometric series.    Now you have the tools to answer the question from the beginning of this section: an infinite sum of positive numbers is finite if its terms become small fast enough — as fast as in a geometric series or as with . Merely going to zero is not enough, as the harmonic series with its stack of books shows impressively. And alternating signs can rescue a series, but they make it delicate: with conditional convergence, even the order of the terms matters.     Summary     Series  : convergent if the partial sums converge; the sum is . Absolutely convergent if converges — this is stronger than convergent. Only absolutely convergent series may be rearranged arbitrarily.   Geometric series:  for , divergent for ; finite sum . Shifted starting index: factor out or subtract the missing terms.   Necessary condition:  . Not sufficient — the harmonic series diverges, although extremely slowly (stack of books, Zipf's law).   Comparison test:  with convergent  absolutely convergent; with divergent  divergent. Comparison series: the geometric series, (convergent), (divergent).   Ratio test and root test: limit of or , respectively, less than  absolutely convergent; greater than  divergent; equal to : no conclusion.   Alternating series test:  with a monotonically decreasing null sequence converges; truncation error . The alternating harmonic series is convergent, but not absolutely convergent.   Rules for series: series may be multiplied by constants and added term by term; the Cauchy product of two absolutely convergent series converges to the product of the sums.   Applications: the annuity payment , the present value of a perpetuity and the discounted return come from the geometric series; a geometric majorant also gives error bounds, for example for ; Robbins–Monro: , , satisfied for .      Exercises    Determine .    With , (so ):       A loan of € at interest per year is to be paid off in two equal annual installments (annuity payments) , each due at the end of the year. Determine , and check your result with the recursion .    With , and the annuity formula, we get (in €) Check: and (up to rounding to the cent).      What does the term test tell you about the series ?     Since is not a null sequence, the series diverges by the term test.      Use the root test to determine whether converges.     By the root test, the series converges (absolutely).      Show that the series converges.    The sequence is positive, strictly decreasing (the denominator grows with ) and a null sequence. So, by the alternating series test, converges.     "
},
{
  "id": "sec-reihen-2",
  "level": "2",
  "url": "sec-reihen.html#sec-reihen-2",
  "type": "Objectives",
  "number": "2.2",
  "title": "",
  "body": "  After this section, you can    explain a series as the sequence of its partial sums and say what convergence and absolute convergence of a series mean;  sum geometric series, also with a shifted starting index;  apply the term test, the comparison test (with a majorant or a minorant), the ratio test, the root test and the alternating series test — and choose the right test for a given series;  use the harmonic and the alternating harmonic series to explain why null sequence is not enough and why convergent does not mean absolutely convergent;  read annuity payments, present values, discounted rewards and conditions on learning rates as series, and bound the truncation error of a series with a geometric majorant.   "
},
{
  "id": "sub-begriff-einer-reihe-2-2",
  "level": "2",
  "url": "sec-reihen.html#sub-begriff-einer-reihe-2-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "series "
},
{
  "id": "def-reihe",
  "level": "2",
  "url": "sec-reihen.html#def-reihe",
  "type": "Definition",
  "number": "2.2.1",
  "title": "Series, partial sum, convergence.",
  "body": " Series, partial sum, convergence   Let be a real or complex sequence. The formal expression is called an (infinite) series . The sequence of partial sums  is itself an ordinary sequence. If converges, the series is called convergent , and is called the sum of the series , written . A series that does not converge is called divergent . The series is called absolutely convergent if the series of absolute values converges. In particular, every absolutely convergent series is also convergent — the converse does not hold, as we will see in this section.   "
},
{
  "id": "rem-reihe-symbolische-schreibweise",
  "level": "2",
  "url": "sec-reihen.html#rem-reihe-symbolische-schreibweise",
  "type": "Remark",
  "number": "2.2.2",
  "title": "A series is not really an infinite sum.",
  "body": " A series is not really an infinite sum  In mathematics, there are no actual infinite sums: the notation is a purely symbolic abbreviation. For a convergent series, the expression stands exactly for the well-defined fact — nothing else. This precision is more than a technicality: rules that are obvious for finite sums (such as rearranging the terms in any order) do not automatically hold for infinite series in general. We will state the valid rules for convergent series explicitly further below.  "
},
{
  "id": "ex-partialsummen-leitbeispiel",
  "level": "2",
  "url": "sec-reihen.html#ex-partialsummen-leitbeispiel",
  "type": "Example",
  "number": "2.2.3",
  "title": "The partial sums of the running example.",
  "body": " The partial sums of the running example   For , compute the partial sums , find a formula for , and determine the sum of the series.    We add step by step: The distance to is halved with every step: , , , …; in general, Since , converges to , so ( ). Note: no partial sum reaches the sum; the sum is the limit.   The partial sums of on the number line: each term covers half of the remaining distance to .    A number line from to . The partial sums , , , and are marked. Arcs above the line show the terms , , , , which get shorter and shorter and approach .       "
},
{
  "id": "ex-kleiner-gauss",
  "level": "2",
  "url": "sec-reihen.html#ex-kleiner-gauss",
  "type": "Example",
  "number": "2.2.5",
  "title": "Young Gauss and a divergent series (optional).",
  "body": " Young Gauss and a divergent series (optional)   When Carl Friedrich Gauss was in elementary school, his teacher is said to have given him the task of adding the numbers from to — hoping for a quiet hour. Gauss was done after a few moments. Determine the partial sums of the series as cleverly as he did. Does the series converge?    The trick: write the sum twice, one above the other, once forward and once backward, and add column by column. So ; for young Gauss, . The sequence of partial sums grows without bound, so the series diverges to — which is not very surprising, since the terms keep getting larger. Things only get interesting when the terms go to . Then anything can happen, as you will see shortly.   "
},
{
  "id": "ex-geometrische-reihe-herleitung",
  "level": "2",
  "url": "sec-reihen.html#ex-geometrische-reihe-herleitung",
  "type": "Example",
  "number": "2.2.6",
  "title": "The geometric series.",
  "body": " The geometric series   For (or ) and (or ), is called a geometric series — exactly the kind of series that our opening example is (there, , ). Derive a closed formula for the partial sum , and determine for which the series converges.    For , we have , which does not converge for . So let . The trick is to multiply by — the sum then telescopes. We write out and , one below the other, so that equal terms are lined up vertically: If we subtract the second line from the first, all terms from to cancel, and what remains is Written briefly in summation notation, the same computation is since all the middle terms cancel each other. Dividing by gives the closed formula For , we have ( ), so converges to For and , is not a null sequence, so the series diverges (the term test, , shows this immediately; for , you can also see it directly from the formula for ).   "
},
{
  "id": "ex-geometrische-reihe-berechnung",
  "level": "2",
  "url": "sec-reihen.html#ex-geometrische-reihe-berechnung",
  "type": "Example",
  "number": "2.2.7",
  "title": "Computing the sums of geometric series.",
  "body": " Computing the sums of geometric series   Determine and (note that the second sum starts only at ).    With the formula from and , (so ): In the second series, the summation index starts only at instead of . We factor out the common factor and reduce the sum to a geometric series that starts at : (Alternatively, we could have computed the complete sum from and then subtracted the missing initial terms : — both ways are equally common for series with a shifted starting index.)   "
},
{
  "id": "ex-periodische-dezimalzahl",
  "level": "2",
  "url": "sec-reihen.html#ex-periodische-dezimalzahl",
  "type": "Example",
  "number": "2.2.8",
  "title": "Repeating decimals as geometric series.",
  "body": " Repeating decimals as geometric series   Write and as fractions.    A repeating decimal is a geometric series: each block is a hundred times smaller than the previous one. Likewise, This surprises many people: is not just below , but exactly  . By definition, is the limit of the partial sums , and this limit is — even though none of the partial sums is itself.   "
},
{
  "id": "ex-anwendung-restschuld-explizit",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-restschuld-explizit",
  "type": "Example",
  "number": "2.2.9",
  "title": "Application: The outstanding balance of a loan in explicit form.",
  "body": " Application: The outstanding balance of a loan in explicit form   In , we computed the outstanding balance recursively: , . Use the geometric sum formula to derive an explicit formula for , and check it for .    With and , we unroll the recursion: and in general . The expression in parentheses is a finite geometric sum, so Check for : , so the same value as in the step-by-step computation. With the explicit formula, we can now also ask the reverse question: which installment is needed so that the loan is paid off after exactly years? We set and solve for . This is the annuity formula of financial mathematics — and we will work it out right away.   "
},
{
  "id": "ex-anwendung-annuitaet",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-annuitaet",
  "type": "Example",
  "number": "2.2.10",
  "title": "Application: The annuity formula.",
  "body": " Application: The annuity formula   With an amortizing loan , you pay the same amount (the annuity payment ) every year, chosen so that the loan is paid off after exactly years. From the explicit formula in , derive a formula for . What is the annuity payment for the loan of € at interest if it is to be paid off in exactly four years? How much interest do you pay in total?    From , it follows that With , , and , we get (in €) In total, you pay back euros, of which € is interest. For comparison: with the installment of € from , the loan was also paid off after four years, but the last payment was not a round number. The annuity payment spreads the burden evenly — this is exactly how banks compute your monthly installment for a car loan or a mortgage, only with months instead of years.   "
},
{
  "id": "ex-anwendung-rentenbarwert",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-rentenbarwert",
  "type": "Example",
  "number": "2.2.11",
  "title": "Application: The present value of a perpetuity.",
  "body": " Application: The present value of a perpetuity   In capital budgeting, you often need the present value of a stream of future payments: how much is a series of future payments worth today if you discount at a periodic interest rate ? A perpetuity pays a fixed amount at the end of every period, indefinitely. The present value of a payment that is made only after periods is (this is just the compound interest formula from in reverse). The present value of the entire perpetuity is therefore Show that , and compute concretely for euros per year and .    With , we always have because , and the series is geometric, except that it starts at instead of : Substituting gives so , as claimed. For and , we get A perpetual annual payment of € is worth € today at interest — although an unlimited amount of money flows over the entire (infinite) duration, its present value is finite, because later payments are discounted more and more strongly.   "
},
{
  "id": "ex-anwendung-diskontierte-belohnung",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-diskontierte-belohnung",
  "type": "Example",
  "number": "2.2.12",
  "title": "Application: Discounted reward in reinforcement learning.",
  "body": " Application: Discounted reward in reinforcement learning   In reinforcement learning , an agent (for example, a warehouse robot or a game-playing program) learns from rewards that it receives in successive time steps. What is evaluated is not the next reward alone, but the discounted return  with a discount factor  that gives later rewards less weight. Suppose the agent receives the same reward in every step. Determine for and for , and interpret the difference.    For a constant reward, is a geometric series with and , so For , this gives ; for , on the other hand, . The value is something like the agent's planning horizon : with , essentially the next ten steps count; with , the next hundred. So the discount factor plays exactly the role of the financial discount factor from — financial mathematics and reinforcement learning compute with the same series here.   "
},
{
  "id": "sub-konvergenzkriterien-reihen-2-2",
  "level": "2",
  "url": "sec-reihen.html#sub-konvergenzkriterien-reihen-2-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "convergence tests "
},
{
  "id": "thm-notwendiges-kriterium",
  "level": "2",
  "url": "sec-reihen.html#thm-notwendiges-kriterium",
  "type": "Theorem",
  "number": "2.2.13",
  "title": "Term test (divergence test).",
  "body": " Term test (divergence test)   If the series is convergent, then is a null sequence: (Reason: with , we have ; if converges to some , then so does , so .) This condition is necessary, but not sufficient — the following example shows a series whose terms form a null sequence but which diverges nonetheless.   "
},
{
  "id": "ex-harmonische-reihe-divergent",
  "level": "2",
  "url": "sec-reihen.html#ex-harmonische-reihe-divergent",
  "type": "Example",
  "number": "2.2.14",
  "title": "The harmonic series diverges.",
  "body": " The harmonic series diverges   Show that the harmonic series  diverges, although is a null sequence.    We bound the partial sum from below by grouping the terms in blocks of length : The th block (for ) contains terms, each of which is at least as large as the last, smallest term of the block. So each block is at least . Since there are such blocks, it follows that For , this lower bound grows without bound, so , and hence also , is unbounded and therefore divergent. The harmonic series is thus the standard example showing that the necessary condition from the term test is not sufficient — we will use it several more times in the rest of this section as a comparison series.  A few numbers show how treacherous this divergence is: the sum of the first thousand terms is only , and to exceed , you need terms. Anyone who only looks at a computer output of the first partial sums could easily guess that the series converges.   "
},
{
  "id": "ex-anwendung-buecherstapel",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-buecherstapel",
  "type": "Example",
  "number": "2.2.15",
  "title": "Application: A stack of books over the edge of a table.",
  "body": " Application: A stack of books over the edge of a table   You stack identical books of length on top of each other at the edge of a table, each book on the previous one, and push them as far to the right as possible without the stack toppling over. A stack is stable as long as the following holds for every book: the common center of mass of all books above it does not lie to the right of its right edge; likewise, the center of mass of the whole stack must not lie to the right of the table edge. One can show that the overhang is largest when the th book from the top sticks out exactly beyond the book below it (or beyond the table edge). How far does the edge of the top book then stick out beyond the table edge in total? Is more than one whole book length possible?    The total overhang is the sum of the individual overhangs: that is, half the th partial sum of the harmonic series. With just four books, this is already : the top book lies completely beyond the table edge; no part of it is above the table anymore ( ). Because the harmonic series diverges, the overhang can even be made arbitrarily large with enough books. However, you already need books for an overhang of two book lengths, for three and about million for ten — the divergence is real, but painfully slow.  Where the overhangs come from can be explained by viewing the center of mass as an average. Suppose the common center of mass of the top books lies exactly above the right edge of book , and book has its own center of mass further to the left. Then the center of mass of all books lies at the weighted average , that is, exactly to the left of the edge. This is where the edge of the next book must be.   Four books of length , stacked optimally: from top to bottom, the overhangs are , , and ; in total, the top book sticks out beyond the table edge.    A table on the left, whose right edge is marked by a vertical dashed line. On it lie four books of equal length, drawn as flat rectangles on top of each other, each shifted to the right relative to the one below. The bottom book sticks out one eighth beyond the table edge; the top book lies completely to the right of the table edge, and its right edge is book lengths away from the table edge.       "
},
{
  "id": "ex-anwendung-zipf",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-zipf",
  "type": "Example",
  "number": "2.2.17",
  "title": "Application: Zipf’s law in text analysis.",
  "body": " Application: Zipf's law in text analysis   If you count how often each word occurs in a large text corpus and sort the words by frequency, you observe Zipf's law surprisingly accurately: the th most frequent word occurs about times as often as the most frequent one. For a vocabulary of words, the share of the most frequent words in the whole text is then What share of a text do the most frequent words cover if the vocabulary comprises words? Use , and the approximation for large (the number is called the Euler–Mascheroni constant).    With , the share is So the most frequent words — the,  of,  and,  in, … — make up almost half of a typical text, although they are only of the vocabulary. This is why, in text analysis, such stop words are often filtered out before searching for words that carry meaning. And here the slow divergence of the harmonic series shows its practical side: because grows only logarithmically with the vocabulary, even a vocabulary twice as large does not change this picture much.   "
},
{
  "id": "thm-majorantenkriterium",
  "level": "2",
  "url": "sec-reihen.html#thm-majorantenkriterium",
  "type": "Theorem",
  "number": "2.2.18",
  "title": "Comparison test.",
  "body": " Comparison test   Suppose we want to determine whether the series converges.    If there is a convergent series with such that for all from some index on, then converges (even absolutely). The series is called a convergent majorant .  If there is a divergent series with such that for all from some index on, then diverges. The series is called a divergent minorant . (Here the themselves — not just their absolute values — must lie above : from , it only follows that does not converge absolutely ; the alternating harmonic series further below shows that it can converge nonetheless.)     "
},
{
  "id": "ex-majorantenkriterium-anwendung",
  "level": "2",
  "url": "sec-reihen.html#ex-majorantenkriterium-anwendung",
  "type": "Example",
  "number": "2.2.19",
  "title": "Applying the comparison test.",
  "body": " Applying the comparison test   Determine whether and converge.    For the first series, for all , so The geometric series converges ( ), so it is a convergent majorant: converges.  For the second series, for all , so . The harmonic series diverges ( ), so it is a divergent minorant: diverges as well.   "
},
{
  "id": "ex-anwendung-sgd-schrittweiten",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-sgd-schrittweiten",
  "type": "Example",
  "number": "2.2.20",
  "title": "Application: Step sizes in stochastic gradient descent.",
  "body": " Application: Step sizes in stochastic gradient descent   In stochastic gradient descent (SGD), which is used in data science to train the parameters of many models, you use a step size (learning rate) in every step . To guarantee that the method converges, the classical requirements are the Robbins–Monro conditions  the first condition ensures that the sum of the steps is large enough to reach every point from every starting point; the second, that the steps shrink fast enough for the noise of the stochastic gradients to average out. Show that the classical choice satisfies both conditions.    The first condition is exactly the divergence of the harmonic series , which we showed in .  For the second condition, we use the comparison test to show that converges. For , the partial fraction decomposition holds (a technique that is neither presupposed nor covered in this course — you can check the equation by bringing the right-hand side to a common denominator), and since , it follows that The right-hand side is a telescoping series: its partial sum is for every (all the middle terms cancel). In particular, this telescoping series is convergent (limit ) and therefore a convergent majorant for . With the term added, is therefore convergent as well (with a sum less than ). The step size thus satisfies both Robbins–Monro conditions — one of the reasons why -type decay schedules for the learning rate are so common in optimization.   "
},
{
  "id": "ex-anwendung-e-berechnen",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-e-berechnen",
  "type": "Example",
  "number": "2.2.21",
  "title": "Application: How does a computer calculate <span class=\"process-math\">\\(\\euler\\text{?}\\)<\/span>",
  "body": " Application: How does a computer calculate ?   One can show that holds. Truncated power series of this kind — after a clever reduction of the argument and with slightly optimized coefficients — are behind the function exp in many software libraries.  Use the comparison test to show that the series converges, and conclude that .  Compute the partial sum , and estimate the error with a geometric series.        For , , so . The geometric series is a convergent majorant, and .  . For the remainder, we factor out ; every further factor in the denominator is at least : In fact, , so the error is — the bound is almost exact.    So seven terms already give three correct decimal places, and the error bound tells you in advance when you may stop. Because the factorial in the denominator grows so fast, just under twenty terms suffice for the full precision of a computer (about digits).   "
},
{
  "id": "thm-quotientenkriterium",
  "level": "2",
  "url": "sec-reihen.html#thm-quotientenkriterium",
  "type": "Theorem",
  "number": "2.2.22",
  "title": "Ratio test.",
  "body": " Ratio test   Let be a series with for all from some index on, and let the sequence converge.    If , then is absolutely convergent.  If , then is divergent.    In the borderline case , the test gives no conclusion: both the divergent harmonic series and the convergent series have the ratio limit . Then another test must be used, for example a comparison with a known series.   "
},
{
  "id": "ex-quotientenkriterium-zwei-faelle",
  "level": "2",
  "url": "sec-reihen.html#ex-quotientenkriterium-zwei-faelle",
  "type": "Example",
  "number": "2.2.23",
  "title": "Ratio test: One convergent and one divergent series.",
  "body": " Ratio test: One convergent and one divergent series   Determine whether and converge.    For , the powers of three cancel almost completely: So the first series converges (absolutely). For , we have so the second series diverges. This fits the hierarchy of growth rates from : the exponential function dominates every power of — in the denominator, it ensures convergence; in the numerator, divergence.   "
},
{
  "id": "ex-quotientenkriterium-anwendung",
  "level": "2",
  "url": "sec-reihen.html#ex-quotientenkriterium-anwendung",
  "type": "Example",
  "number": "2.2.24",
  "title": "Applying the ratio test (optional).",
  "body": " Applying the ratio test (optional)   Determine whether converges.    With , we have From , we already know that , so By the ratio test, the series converges (absolutely).   "
},
{
  "id": "thm-wurzelkriterium",
  "level": "2",
  "url": "sec-reihen.html#thm-wurzelkriterium",
  "type": "Theorem",
  "number": "2.2.25",
  "title": "Root test.",
  "body": " Root test   Let be a series, and let the sequence converge.    If , then is absolutely convergent.  If , then is divergent.     "
},
{
  "id": "ex-wurzelkriterium-anwendung",
  "level": "2",
  "url": "sec-reihen.html#ex-wurzelkriterium-anwendung",
  "type": "Example",
  "number": "2.2.26",
  "title": "Applying the root test.",
  "body": " Applying the root test   Determine whether converges.    Here the th root simply undoes the th power. Unlike with the ratio test, nothing has to be canceled first: By the root test, the series converges (absolutely). This example shows why, for series with a power , it is worth trying the root test first: here it avoids the somewhat more unwieldy computation of the ratio altogether.   "
},
{
  "id": "thm-leibniz-kriterium",
  "level": "2",
  "url": "sec-reihen.html#thm-leibniz-kriterium",
  "type": "Theorem",
  "number": "2.2.27",
  "title": "Alternating series test (Leibniz criterion).",
  "body": " Alternating series test (Leibniz criterion)   Let be a monotonically decreasing real null sequence with . Then the alternating series  converges.   "
},
{
  "id": "rem-leibniz-fehlerabschaetzung",
  "level": "2",
  "url": "sec-reihen.html#rem-leibniz-fehlerabschaetzung",
  "type": "Remark",
  "number": "2.2.28",
  "title": "Error bound for the alternating series test.",
  "body": " Error bound for the alternating series test  Under the hypotheses of the alternating series test, the partial sums oscillate around the limit with steadily decreasing amplitude: consecutive partial sums lie alternately above and below and so enclose more and more tightly. From this follows the useful error bound — the error when stopping after the th term is at most as large as the absolute value of the first omitted term. This lets you estimate in advance how many terms are needed for a desired accuracy, without knowing the (often unknown) limit itself — a principle that is also used to bound the error of truncated series approximations (for example, of Taylor series).  "
},
{
  "id": "ex-leibniz-alternierende-harmonische-reihe",
  "level": "2",
  "url": "sec-reihen.html#ex-leibniz-alternierende-harmonische-reihe",
  "type": "Example",
  "number": "2.2.29",
  "title": "The alternating harmonic series: Convergent, but not absolutely.",
  "body": " The alternating harmonic series: Convergent, but not absolutely   Show that converges, but does not converge absolutely.    The sequence is a monotonically decreasing null sequence, so the series converges by the alternating series test. The series of absolute values, however, is that is, exactly the harmonic series, which diverges by . So the series converges, but not absolutely — such a series is called conditionally convergent . (One can show that its sum is , but the proof is beyond the scope of this section.) In particular, this example shows that the converse of the statement absolutely convergent convergent from is indeed false.   "
},
{
  "id": "ex-umordnung-alternierende-harmonische-reihe",
  "level": "2",
  "url": "sec-reihen.html#ex-umordnung-alternierende-harmonische-reihe",
  "type": "Example",
  "number": "2.2.30",
  "title": "Rearranging changes the sum.",
  "body": " Rearranging changes the sum   Let be the sum of the alternating harmonic series. We rearrange the same terms: one positive term, then two negative ones, and so on: Convince yourself that every term of occurs exactly once, and show that .    The positive terms appear in their original order, and the negative ones, and , together run through all even denominators — so every term is used exactly once. Now we group the terms in threes and simplify the first two terms of each group, using : For , this gives (Because the terms go to , grouping them in threes does not change the limit.) So the same numbers, in a different order, give half the sum — with , we get . Bernhard Riemann even showed that, by rearranging a conditionally convergent series cleverly, you can make it converge to any number you like. With absolutely convergent series, this never happens; there, rearranging is allowed.   "
},
{
  "id": "ex-leibniz-fehlerabschaetzung-anwendung",
  "level": "2",
  "url": "sec-reihen.html#ex-leibniz-fehlerabschaetzung-anwendung",
  "type": "Example",
  "number": "2.2.31",
  "title": "How many terms do you need?",
  "body": " How many terms do you need?   Around 1735, Leonhard Euler proved, to the astonishment of his contemporaries, that — the Basel problem, which Jakob Bernoulli, among others, had tried and failed to solve. From this, it also follows that (we do not give the proof here). How many terms must you add so that the error bound of the alternating series test guarantees an error smaller than ? Compare with the series for from and with the alternating harmonic series.    The absolute values form a monotonically decreasing null sequence, so the error bound holds. We need ; since and , this is the case from on, that is, . So the bound guarantees the desired accuracy after terms ( ) at the latest. In fact, already suffice — the bound is cautious, but it is guaranteed.  For comparison: for the series for , seven terms were enough. For the alternating harmonic series, the error bound gives , and this guarantees an error below only after about a thousand terms. What matters is how fast the terms become small: falls rapidly, reasonably fast, only sluggishly. So the error bound guarantees convergence, but it also tells you honestly how slow it can be.   "
},
{
  "id": "rem-welches-kriterium",
  "level": "2",
  "url": "sec-reihen.html#rem-welches-kriterium",
  "type": "Remark",
  "number": "2.2.32",
  "title": "Which test when?",
  "body": " Which test when?  Each test is suited to a typical kind of series. A proven order for examining a series :    Null sequence? If does not go to , you are done: the series diverges.  A power in the term? Root test. Factorials or th powers of fixed numbers ( , )? Ratio test.  Alternating signs with monotonically decreasing absolute values? Alternating series test (and you get the error bound for free).  Otherwise — in particular for terms that are quotients of polynomials, such as — compare with a known series: the geometric series and as convergent majorants, and as divergent minorants.    If the ratio test or the root test gives the limit , then — unless step 1 has already decided — only step 3 or 4 can help.  "
},
{
  "id": "ex-kriterium-auswaehlen",
  "level": "2",
  "url": "sec-reihen.html#ex-kriterium-auswaehlen",
  "type": "Example",
  "number": "2.2.33",
  "title": "Choosing the right test.",
  "body": " Choosing the right test   Use the strategy from to decide whether the following series converge:       The power suggests the root test — but , no conclusion. Step 1 helps: . Not a null sequence, so the series diverges.  Factorial: ratio test. . The series converges. Remarkably, the terms even grow at first, up to more than at and . But the test only looks at the long-run behavior; finitely many large initial terms do not change convergence.  Alternating signs, and is a monotonically decreasing null sequence: by the alternating series test, the series converges. It does not converge absolutely, because diverges ( ).  Quotient of polynomials: for large , , so we suspect divergence. Since , we have , and diverges as half the harmonic series. This divergent minorant shows that the series diverges.    Part (a) shows why step 1 always comes first: it would have saved the detour via the root test.   "
},
{
  "id": "thm-rechenregeln-reihen",
  "level": "2",
  "url": "sec-reihen.html#thm-rechenregeln-reihen",
  "type": "Theorem",
  "number": "2.2.34",
  "title": "Rules for convergent series.",
  "body": " Rules for convergent series   Let and be convergent series and (or ). Then the following hold:    ( Multiplication by a constant ) The series is convergent, and .  ( Sum rule ) The series is convergent, and .  ( Cauchy product ) If and are, moreover, absolutely convergent, then the Cauchy product  of the two series with also converges, and The assumption of absolute convergence is essential here: for series that are only conditionally convergent, the Cauchy product can diverge.     "
},
{
  "id": "ex-cauchy-produkt-geometrische-reihe",
  "level": "2",
  "url": "sec-reihen.html#ex-cauchy-produkt-geometrische-reihe",
  "type": "Example",
  "number": "2.2.35",
  "title": "The Cauchy product of a geometric series with itself (optional).",
  "body": " The Cauchy product of a geometric series with itself (optional)   Let . Form the Cauchy product of the geometric series with itself, and check the result numerically for .    With , the th coefficient of the Cauchy product is since each of the terms equals . The geometric series is absolutely convergent for , because is itself a convergent geometric series. So the rule for the Cauchy product from applies, and we obtain the identity For , the right-hand side gives . The left-hand side is , with the partial sums which indeed approach . Incidentally, we have summed a series without needing a formula for its partial sums — just by multiplying two geometric series.   "
},
{
  "id": "sub-zusammenfassung-2-2-2",
  "level": "2",
  "url": "sec-reihen.html#sub-zusammenfassung-2-2-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Series Absolutely convergent Geometric series: Necessary condition: Comparison test: Ratio test and root test: Alternating series test: Rules for series: Applications: "
},
{
  "id": "exercise-buch-geometrische-reihe",
  "level": "2",
  "url": "sec-reihen.html#exercise-buch-geometrische-reihe",
  "type": "Exercise",
  "number": "2.2.4.1",
  "title": "",
  "body": "  Determine .    With , (so ):    "
},
{
  "id": "exercise-buch-annuitaet",
  "level": "2",
  "url": "sec-reihen.html#exercise-buch-annuitaet",
  "type": "Exercise",
  "number": "2.2.4.2",
  "title": "",
  "body": "  A loan of € at interest per year is to be paid off in two equal annual installments (annuity payments) , each due at the end of the year. Determine , and check your result with the recursion .    With , and the annuity formula, we get (in €) Check: and (up to rounding to the cent).   "
},
{
  "id": "exercise-buch-notwendiges-kriterium",
  "level": "2",
  "url": "sec-reihen.html#exercise-buch-notwendiges-kriterium",
  "type": "Exercise",
  "number": "2.2.4.3",
  "title": "",
  "body": "  What does the term test tell you about the series ?     Since is not a null sequence, the series diverges by the term test.   "
},
{
  "id": "exercise-buch-wurzelkriterium",
  "level": "2",
  "url": "sec-reihen.html#exercise-buch-wurzelkriterium",
  "type": "Exercise",
  "number": "2.2.4.4",
  "title": "",
  "body": "  Use the root test to determine whether converges.     By the root test, the series converges (absolutely).   "
},
{
  "id": "exercise-buch-leibniz",
  "level": "2",
  "url": "sec-reihen.html#exercise-buch-leibniz",
  "type": "Exercise",
  "number": "2.2.4.5",
  "title": "",
  "body": "  Show that the series converges.    The sequence is positive, strictly decreasing (the denominator grows with ) and a null sequence. So, by the alternating series test, converges.   "
},
{
  "id": "sec-funktionen-stetigkeit",
  "level": "1",
  "url": "sec-funktionen-stetigkeit.html",
  "type": "Section",
  "number": "3.1",
  "title": "Functions: Basic concepts, elementary functions and continuity",
  "body": " Functions: Basic concepts, elementary functions and continuity    After this section, you can    describe maps by their domain, codomain and image, check them for injectivity, surjectivity and bijectivity, and form compositions and inverse maps;  determine the maximal domain of real functions, check them for symmetry, periodicity and monotonicity, and find inverse functions;  compute with exponential, logarithmic, trigonometric and hyperbolic functions and solve the related equations;  compute limits of functions by factoring, rationalizing, looking at one-sided limits and using the squeeze theorem;  prove continuity, choose the parameters of piecewise-defined functions so that the functions become continuous, apply the intermediate value theorem and extend functions continuously at gaps in the domain;  describe ReLU and sigmoid — the standard functions of neural networks — in terms of these concepts.     This section is the longest of the course, because it provides the vocabulary for everything that follows. You know part of it from school — powers, logarithms, sine and cosine. Read these parts quickly, as a refresher. Concentrate on the concepts that are really new: the precise language of maps (when can an assignment be reversed?), limits of functions (what happens near a point where the function is not even defined?) and continuity . Throughout the section, we follow two functions from machine learning: the ReLU function with its kink and the sigmoid function with its saturation. We will meet both again in the next section, when we differentiate.  Along the way, you will learn why every checksum function must have collisions, why data scientists are so fond of taking logarithms, why calculus uses radians, how a table of values can lie, and why a hiker must be at the same place at the same time of day on two different days.    Maps   So far, we have computed with individual numbers (complex, real) and with sequences. From now on, the focus is on the concept that describes dependencies between quantities: a model predicts the price of a house from its living area, an activation function converts the weighted sum of a neuron's inputs into an output value, an interest rate determines the final amount after a given term. In all these cases, each element of one set is assigned exactly one element of another set — this is the concept of a map .  The language of this subsection seems formal at first. But it answers a very practical question: when can an assignment be reversed , that is, when can you work back uniquely from the result to the input? From a temperature in Fahrenheit, you can compute the temperature in Celsius; from a rounded measurement, you can no longer recover the exact value.    Maps and their composition   Map, function   A map (also called a function ) from a set to a set is an assignment that assigns to every   exactly one  . We write or, for short, .    The two key words are every and exactly one : no element of may be left without an image, and no element may have two images. On the other hand, several elements of may have the same image, and not every element of has to be hit.   A map or not? (optional)   A university database contains a table of all students. Which of the following assignments are maps?  student ID number date of birth of the person with this number;  date of birth person with this date of birth;  real number  the numbers with .        Yes: every student ID number belongs to exactly one person, and this person has exactly one date of birth. Many numbers may be mapped to the same date; this is allowed.  No, and for two reasons: on some dates, several students were born ( exactly one is violated), and on some dates, nobody was born ( every is violated).  No: both and belong to . Only the rule take the nonnegative solution turns this into the square root function .    By the way: the student ID number determines a person uniquely , and this makes it a key in the database. So the assignment person student ID number must never give the same number to two people — exactly this property is what we will soon call injective.     The individual parts of a map have fixed names.   Domain, image, preimage   Let be a map. Then    is called the domain of ,  an argument of ,  the codomain of ,   the image (or range ) of ,  for and , the element the image of , and a preimage of ,  for , the set the preimage of .    The name of the argument does not matter: and describe the same map. Likewise, you must distinguish between the map itself and the single value that you get when you substitute .     Finding images and preimages   Let , . Determine and .    Substituting gives , , , , , so (each value counts only once). For the preimage, we look for all with . Since is not a perfect square and , , we get .    Be careful with the notation : the preimage is defined for every map, even for one that cannot be reversed — in the example, the image has the two preimages and . For bijective maps, the preimage agrees with the image under the inverse map, which we introduce below; in general, however, is only a set of preimages.  Maps are often applied one after the other: a model computes a number from features, and a second function converts this number into a probability. The result is again a map.   Composition of maps   Let and be two maps such that the codomain of is contained in the domain of . Then the composition of and is the map You read as after : first is applied, then .     Computing a composition   Let , , and , . Determine and , and decide whether .    We have and . The coefficients of already differ ( versus ), so : in general, the composition of maps is not commutative.      Injective, surjective, bijective — and the inverse map  A map can be reversed if and only if every element of the codomain has exactly one preimage. We split this into two conditions: at most one preimage (injective) and at least one preimage (surjective).   Injective, surjective, bijective   Let be a map.     is called injective if for all with , it follows that (different elements are mapped to different elements).   is called surjective if for every , there exists an with (every element of has at least one preimage).   is called bijective if is injective and surjective.       Proving injectivity and surjectivity   Determine whether , , and , , are injective and whether they are surjective.     is not injective, because with . is not surjective either, because has no preimage in (no integer squares to ).   , on the other hand, is injective: if satisfy , then , because (this is the contrapositive of the condition for injectivity). But is not surjective, since, for example, has no preimage ( , , and nothing lies in between). The example shows: injectivity and surjectivity depend not only on the formula, but also on the domain and the codomain.    Sometimes you know without any computation that a map cannot be injective: namely, when the domain has more elements than the codomain. If you put socks into drawers, two socks end up in the same drawer somewhere. This pigeonhole principle sounds trivial, but it has real consequences. Among people, two certainly have their birthday on the same day. And a hash function , which maps files of arbitrary length to checksums of fixed length (say bits), can never be injective — there are infinitely many possible files, but only checksums. So collisions necessarily exist ; the art of cryptography is to make sure that nobody can find one. Rounding measured values to a fixed step size, called quantization , is not injective either: if you round to one decimal place, and both become , and the stored value no longer determines the measured value uniquely.   Inverse map   Let be a map. If is bijective, then , with , defines a map, the inverse map of . It is denoted by . We have and , where denotes the identity map on .     Application: Converting temperatures   A sensor delivers temperatures in degrees Celsius; a US dashboard expects degrees Fahrenheit. The conversion is , . Show that is bijective, and determine the inverse map. Which Celsius temperature corresponds to  °F?    We solve for : So every has exactly one preimage : is surjective (there is one) and injective (there is only one), hence bijective, and For , we get — the normal body temperature. Check: . Solving for the input is the standard method for finding the inverse map: if it succeeds uniquely, the map is bijective.       Real functions: Basic concepts   From now on, we restrict ourselves to real functions , that is, maps between subsets of . We carry over the concepts from to these functions and add properties that make sense specifically for real-valued functions: symmetry, periodicity, monotonicity. You know much of this from school under the heading curve sketching ; what is new is mainly that we now prove these properties by computation instead of just reading them off the graph.    Domain, graph and piecewise-defined functions   Real function, range, zero   We consider functions with (the domain ) and (the codomain ). If and are not given explicitly, the following tacit convention applies: is the maximal domain — the set of all real numbers that may be substituted into the formula of the function — and .  The range of is the set . A zero of is an with .     Finding the maximal domain   Determine the maximal domain of .    The expression under the square root must be nonnegative: . Moreover, the denominator must not be : . Altogether,     The graph of a real function is the subset . It makes properties such as zeros, monotonicity or symmetry visible.  Many functions in practice are defined piece by piece: a tax schedule with brackets, a shipping fee that is waived above a certain order value, or an activation function that cuts off negative inputs.   Piecewise-defined function   A function whose domain consists of finitely many intervals, each with its own formula, is called piecewise defined .     Application: The ReLU activation function   Artificial neural networks often use the ReLU function ( rectified linear unit ) as their activation function: Give , and , and determine the range of .    Substituting gives , , . Negative inputs are always mapped to , and nonnegative inputs stay unchanged, so the range is . We return to the ReLU function in and examine whether the kink at affects its continuity.     The ReLU function: constant zero to the left of , the identity to the right — with a kink at .    A coordinate system with the graph of the ReLU function: for negative , the graph runs along the -axis; for positive , it is a straight line with slope through the origin. At the origin, the graph has a kink.        Symmetry, periodicity and monotonicity  Symmetries save work: if you know the graph of an even or odd function for , you know it everywhere.   Even and odd functions   Let be a function defined on an interval that is symmetric about the origin.     is called even if for all . Its graph is then symmetric about the -axis.   is called odd if for all . Its graph is then symmetric about the origin.      For polynomials, there is a quick test: a polynomial with only even exponents, such as , is even, because ; one with only odd exponents, such as , is odd. A polynomial such as is neither — most functions have neither of these symmetries.   Periodic function   Let be a function defined on an interval. is called periodic with period  if holds for all with . If is periodic with period , then it is also periodic with every period , ; the smallest positive period is called the fundamental period .     Application: Periods in time series   The power consumption of an office building (in kW) over the day is modeled by , with in hours after midnight. Determine the fundamental period. When is the consumption highest?    The cosine has the fundamental period . The argument runs through one full period when increases by with , that is, : the consumption repeats in a daily cycle, . It is highest when , that is, at , i.e., at (noon), with  kW; at midnight (hour ), it is  kW. Detecting such daily, weekly and yearly periods is a standard step in the analysis of time series.    You already know monotonicity from sequences ( ). For functions, we do not compare consecutive terms, but any two points .   Monotonic function   Let be a function defined on an interval. is called     monotonically increasing if for all in ; strictly increasing if even the strict inequality holds;   monotonically decreasing if for all in ; strictly decreasing if even the strict inequality holds.       Proving monotonicity via the difference (optional)   Show that is strictly increasing on .    For in , we look at the difference: Since , we have and , so the denominator is positive; the numerator is also positive, because . Hence , that is, : is strictly increasing.      Inverse functions  An important observation on invertibility: if is injective, then , as a map between its domain and its range, is bijective, and the inverse function exists ( ). To find its formula, you solve the equation for ; the graph of is obtained by reflecting the graph of in the line . Every strictly monotonic function is injective and therefore invertible — but the converse does not hold: on is injective, but not monotonic (it is strictly decreasing to the left and to the right of , but jumps from to in between).   An inverse function by restricting the domain   The function , , is not injective on all of . Find an interval with , as large as possible, on which the restriction of is injective, and determine the inverse function of this restriction.    The graph of is the standard parabola, shifted to the right and up; the function is strictly monotonic on each of the intervals and separately (and precisely there), so it is injective on each of them. Since , we choose .  We solve for (for , the range of the restriction): , and since , it follows that , so . The inverse function is therefore Check: and . If we had chosen , the negative sign would have been correct when taking the square root: . So the choice of the interval also determines the formula of the inverse function.       Elementary functions   A function is called elementary if it can be built from a few basic types by the basic arithmetic operations and composition: power and root functions, polynomials and rational functions, trigonometric functions and their inverse functions, exponential functions and logarithms, and hyperbolic functions. Almost every formula you meet in engineering and business is put together from these building blocks.  You know powers, polynomials and fractions from school and from the review of the basics. Here, we concentrate on three families: the exponential function and the logarithm, which describe processes of growth and decay; the trigonometric functions for everything periodic; and the less familiar hyperbolic functions. Much of this is review — read these parts quickly, but still work through the examples yourself.    Exponential function and logarithm   Exponential function   A function with the formula for a fixed real base is called an exponential function . For , is strictly increasing; for , it is strictly decreasing; in both cases, is bijective.     Rules for exponential functions   For and , we have:              Euler's number    Euler's number  is the unique real number for which the exponential function has slope at . It is irrational, . The function is called the exponential function and is also written as .     Application: The balance as an exponential function   An amount of earns interest at a fixed annual rate of . Give the balance as a function of the time (in years), and compute .    With and the growth factor per year, we have , an exponential function in . It follows that . Unlike with simple interest, grows at a fixed relative rate here — for integer , this is exactly the compound interest sequence from , now read as a function of a continuous time.    With compound interest, you know the initial amount, the interest rate and the time, and you compute the final amount. But often the question is the other way around: how long does it take until a certain value is reached? Then the unknown is in the exponent, and you need the inverse function of the exponential function.   Logarithm to base   Let , . The inverse function of the bijective exponential function , , is the logarithmic function  Since they are inverse functions of each other, we have for all and for all .     Laws of logarithms   For , and , we have:           The logarithm to base is called the natural logarithm and is written . For (with in the second case), we have the change-of-base formulas  which reduce every exponential or logarithmic function to the base . The logarithm is strictly increasing, but it grows much more slowly than any root function.   The exponential function and the natural logarithm are inverse functions of each other: reflecting one graph in the line (dashed) gives the other.    A coordinate system with the steeply rising graph of , which crosses the -axis at , and the graph of , which crosses the -axis at and approaches the negative -axis to the left. The two graphs are mirror images of each other in the dashed diagonal .       A warm-up with school material (optional)   (a) Write as a single power of . (b) Compute without a calculator. (c) Solve for .    (a) With and , the expression is . (b) Quotient law: . (c) Taking logarithms: , so .     Application: Doubling time   After how many years has the amount from (interest rate ) doubled?    We need with , that is, . Taking logarithms and using the third law of logarithms brings down from the exponent: After just under years, the amount has doubled — regardless of the initial amount , which has canceled out. Practitioners compute this in their heads with a rule of thumb, which we justify in .    The logarithm has a second, very practical side: it turns multiplication into addition, and thus exponential growth into a straight line. Data analysis uses this all the time.   Application: Exponential growth on a log scale   A new app has , , and users after months. Show that the data fit and that is a linear function of . If the growth continues at the same rate, when will the app have users? (Use and .)    The ratios of consecutive values are all equal, , so . Taking logarithms and using the laws of logarithms gives a straight line in with slope . For , we need , so After a little more than eleven months, that is, just under a year, the app would reach this mark. This is exactly why growth data are often plotted with a logarithmic -axis: there, exponential growth appears as a straight line, and every deviation from the line — for example, a flattening because the market is saturated — is immediately visible. For a related reason — taking logarithms turns multiplicative effects into additive ones — statisticians often log-transform incomes, prices or case counts before they fit a straight line to the data.     Application: The sigmoid function   In logistic regression and as an activation function in neural networks, the sigmoid function  is used to map any real value (e.g., a weighted sum of features) to a probability in the interval . Compute and show that for all .     — so an input of corresponds to maximum uncertainty. Since for all , the denominator is , so . Moreover, is strictly increasing: if increases, then decreases, so decreases, so the denominator decreases, and the fraction increases. Hence is injective and therefore invertible — its inverse function is the logit function  used in logistic regression. We examine the limiting behavior of as in .     The sigmoid function : strictly increasing, values in , symmetric about the point , and nearly constant for large ( saturation ).    A coordinate system with the S-shaped graph of the sigmoid function. The graph comes in from the left close to , has the value at and approaches the dashed asymptote to the right.        Trigonometric functions  We review the trigonometric functions and , which are defined by means of the unit circle: for an angle (in radians), is the point on the unit circle that you get by rotating by the angle . Both functions are -periodic with range .  Why radians and not degrees? An angle in radians is exactly the length of the corresponding arc on the unit circle — a length, not an arbitrary division into parts that goes back to the Babylonians. This naturalness pays off: only in radians does the convenient approximation hold for small angles ( ), and only in radians do sine and cosine have the simple derivatives that you will see in . So when you use a calculator or a programming language, make sure that angles are entered in radians ( rad ) — numpy.sin always expects radians.   Arcsine and arccosine   The arcsine is the inverse function of the restriction of the sine to : The arccosine is the inverse function of the restriction of the cosine to :      Solving a trigonometric equation   Determine all solutions of the equation .    Rearranging gives . Since , the equation has the solution in the principal interval . Because of the symmetry of the sine ( ) and its -periodicity, we get the two solutions in the interval :     In the same way, we restrict the tangent  (defined for ) to ; the inverse function of this restriction is the arctangent  . Correspondingly, the cotangent  gives the arccotangent . Sine and cosine satisfy the addition formulas     General cosine function   The general cosine function has the form with amplitude  , angular frequency  and phase shift  . Its fundamental period is .    An example from the power outlet: the grid voltage (in volts, in seconds) has the amplitude  V and the angular frequency per second, so its period is  s  ms. The is the grid frequency in hertz: fifty full oscillations per second.    Hyperbolic functions  If you add or subtract and , you get functions that behave in many ways like cosine and sine — only without oscillating. They appear in statics, in overhead power lines and as the activation function in neural networks.   Hyperbolic functions   The hyperbolic functions are defined as       Proving a hyperbolic identity   Show that for all .    Substituting the definitions: Multiplying out both squares gives and . So the difference of the two squared expressions is , and therefore . Compare this with : the points lie on a circle, the points on a hyperbola — hence the name.     Application: The catenary (optional)   A chain (or an overhead power line) hanging freely between two suspension points follows the curve for a constant that depends on the length and the weight of the chain. For : how much higher is the chain at a horizontal distance of from the lowest point than at the lowest point itself?    The lowest point is at , with . At , we have So the difference in height is . A parabola looks similar, but it is not the same: anyone who plans an overhead power line computes with . By the way, if you turn the catenary upside down, you get the ideal shape of an arch, in which there is only compression and no bending. This is why the architect Antoni Gaudí designed his vaults with hanging models made of strings and weights, and the Gateway Arch in St. Louis follows a (slightly modified) inverted catenary.       Limits of functions  What happens to a function near a point where you are not even allowed to evaluate it? An example: is not defined at , because there we get . But if you substitute values nearby, a clear picture emerges: From both sides, the function values approach . A table of values, however, is not a proof — it could miss something special between the sample points, and we will soon see an example in which it is completely misleading.  The limit of sequences from provides the precise concept. The idea: you approach the point in every conceivable way with a sequence and check whether the function values then always tend to the same value. With the following definition and the limit laws, we can determine the limit in the example above exactly ( ).   Limit of a function, left-hand and right-hand limit   Let be an interval, , and let be a function.     has the limit  at if for every sequence in the domain of with . We write .   has the left-hand (or right-hand ) limit  at if this holds for every sequence with and (or , respectively). We write or , respectively.    The two-sided limit exists if and only if both one-sided limits exist and agree.    The small word every in the definition is important. It is not enough to approach the point in one convenient way — the following example shows how deceptive that can be.   When the table of values lies   Evaluate at . What do you conjecture about ? Then examine the sequence .    We have , and . In general, for every — the table suggests the limit . But for , we have for all . Two sequences that both tend to give different limits of the function values. So does not exist: near , the function oscillates faster and faster between and , and the sample points happened to hit the zeros every time. A computer that tries a few values would have fallen into exactly this trap.    Limits for (or ) are defined in exactly the same way: means that for every sequence . Such limits describe the long-run behavior, for example the cost per unit for very large production quantities.   Limit laws   Suppose that and . Then:       , if   (Squeeze theorem) If and for all in a neighborhood of , then .       A limit by factoring   Determine .    Substituting gives the indeterminate form ; we factor the numerator. The roots of are and , so . For , we can cancel: Hence .     A limit by rationalizing   Determine .    We use the difference of two squares, that is, we multiply the numerator and denominator by : As , this tends to .     One-sided limits that do not agree   Show that has no limit as .    For , we have , so , and therefore . For , we have , so , and therefore . Since the two one-sided limits do not agree, does not exist.     The squeeze theorem for an oscillating function   Determine .    The factor oscillates as and has no limit, but it always stays between and . Hence, for all : Since , the squeeze theorem gives .    The squeeze theorem also gives one of the most important limits in all of analysis. You cannot get it by canceling or by multiplying the numerator and denominator by some factor.   The limit   Determine ( in radians). First compare with a few values, then justify the result using the unit circle ( ).   On the unit circle, for : small triangle circular sector large triangle, so .    A quarter of the unit circle in the first quadrant. A ray leaves the origin at the angle . It meets the circle at the point and the vertical tangent line at at the height . Three nested regions are shaded with different intensity: the dark small triangle with vertices at the origin, and the point on the circle; the medium circular sector; and the light large triangle with vertices at the origin, and .        Substituting gives . Values: , — the limit is probably .  To justify this, let . In , three regions are nested: the small triangle with height , the circular sector with angle and the large triangle with height . Their areas are , (the sector is the fraction of the area of the circle) and , so Dividing by and taking reciprocals gives Since (the cosine is continuous, see ), the squeeze theorem gives as . The same holds for negative , because . Hence   In practice, this means: for small angles, . Engineers use this small-angle approximation all the time, for example for the simple pendulum or in optics.     Application: Unit cost for large production volumes (optional)   A company has fixed costs of € and variable costs of € per unit. Because of volume discounts on purchased materials, the variable cost of each additional unit decreases as the number of units grows, so that the total cost is . What value does the unit cost approach as ?    We divide each term by : As , we have and , so The fixed costs are spread over more and more units and vanish per unit ( spreading of fixed costs ); what remains are the variable costs, reduced by the discount to € per unit. The technique is the same as for sequences ( ): divide by the highest power.     Application: Saturation of the sigmoid function   Determine and for the sigmoid function from .    As , we have , so , and hence . As , we have , so , and hence . So for large , the sigmoid function approaches the horizontal asymptotes and , respectively — it saturates . This saturation matters when neural networks are trained: for very large , the function value becomes nearly constant, which leads to very small gradients (as shown in ).      Continuous functions  Intuitively, a function is continuous if you can draw its graph without lifting your pencil. The concept of a limit from makes this intuition precise.  Continuity sounds like something obvious, but it is the prerequisite for two very practical things: you may compute limits simply by substituting, and you can narrow down zeros without being able to solve the equation. We will see both in this subsection. Conversely, in applications, discontinuities are often exactly the points where something interesting happens: a jump in a tariff, a switching operation.   Continuity   A real function is continuous at  if If is continuous at every point of , then is called continuous .    The definition contains three conditions: must be defined, the limit must exist, and the two must agree.   Application: A shipping fee with a jump   An online retailer charges a shipping fee of € for orders worth euros; from € on, shipping is free. So the invoice total is Is continuous at ?    From the left, ; from the right, . The one-sided limits do not agree, the limit does not exist, and is discontinuous at — the graph jumps down by € . This jump is intended: if you order goods worth € , you pay € ; if you buy € more, you pay only € . Discontinuous tariffs deliberately create incentives.    Not every jump is wanted. Often you want to set up a piecewise-defined tariff so that it makes no jump at the junction point. Then you choose a free parameter so that the left-hand and right-hand limits agree.   Application: Making an electricity tariff continuous   An energy supplier charges € per kWh for an annual consumption of up to  kWh. Customers who use more pay a base fee plus € per kWh for their entire consumption: How must be chosen so that is continuous? What happens with euros?    Both pieces are continuous, since they are linear functions; only the junction point is critical. There, we have  is continuous if and only if , that is, euros. With euros, in contrast, the bill jumps down by € at the threshold: a household with  kWh pays € , one with  kWh only € . So a household just below the threshold would save money by using more electricity — a classic threshold effect , which a continuous tariff avoids.    Fortunately, you rarely have to prove continuity with the definition. Most functions are built from continuous building blocks, and continuity is preserved in the process.   Combinations and compositions of continuous functions   If and are continuous at , then , and (if ) are also continuous at . If is continuous at and is continuous at , then the composition is also continuous at . All elementary functions ( ) are continuous on their entire domain.     Continuity of a composite function (optional)   Explain why is continuous on all of .     is continuous as a polynomial and always positive, and the square root function is continuous on , so the composition is continuous on all of . Likewise, and are continuous as elementary functions, and so is their composition . As the product of two functions that are continuous on , is therefore also continuous on all of .     Application: The ReLU function is continuous   Show that the ReLU function from , is continuous at .    The left-hand limit is , the right-hand limit is . The two agree with each other and with the function value , so : is continuous at — despite the kink in its graph. Continuity only requires matching limits, not smoothness ; we examine in whether the function is also differentiable at this point.     Intermediate value theorem, Bolzano's theorem   Let be a function that is continuous on .    ( Intermediate value theorem ) takes on every value between and at least once.  ( Bolzano's theorem ) If and have opposite signs, then has at least one zero in .      Bolzano's theorem is intuitively clear — if you do not lift your pencil, you must cross the -axis to get from below to above. But it is also the basis of a simple, robust algorithm for finding zeros.   Computational example: Locating zeros by interval bisection   Show that has a zero in , and narrow it down by halving the interval four times.     is continuous as a polynomial, and , . By Bolzano's theorem, there is a zero in . Now we evaluate at the midpoint of the interval and keep the half whose endpoints give values of opposite sign: So the zero lies between and (in fact, at ). Each step halves the uncertainty; after steps, the interval has length , so after steps it is shorter than one millionth. The bisection method is slower than Heron's method or Newton's method, which we treat later ( ), but it works for every continuous function with a sign change.     The mountain hike puzzle   A hiker sets off from the valley at 6:00 in the morning and reaches the mountain hut at 18:00. The next morning, she starts her descent on the same trail at 6:00 and is back in the valley at 18:00. On the way, she walks at very different speeds on the two days and takes breaks wherever she likes. Is there a point on the trail where she is at the same time of day on both days?    The answer is yes — no matter how she walks. Let be the length of the trail, her position (the distance along the trail from the valley) on the first day and her position on the second day, each at the time . Both functions are continuous, because nobody jumps. The difference is also continuous, and By Bolzano's theorem, there is a with , that is, : at the time , she is at the same point on both days.  If you do not believe this, imagine two hikers who set off on the same day, one from below and one from above — they must meet on the way. What is remarkable is what the proof does not give: it does not say when and where they meet. Bolzano's theorem is a pure existence theorem, just like the fundamental theorem of algebra in .     Continuous extension   Let be an interval, , and a function defined on . If the limit exists, then can be extended continuously by     We already know an example: the function from is not defined at , but it has the limit there. With the value at the point , it is extended continuously — the extension is simply . It is different for : there, the function values grow beyond all bounds as we approach (a pole), no limit exists, and no choice of makes the function continuous.    Summary     Map  : exactly one for every . Injective: different arguments, different values. Surjective: every is hit. Bijective: both — then the inverse map exists. Composition , in general not commutative. Pigeonhole principle: if has more elements than , then cannot be injective.   Real functions: maximal domain (expressions under roots , denominators , arguments of logarithms ); even ( ) or odd ( ); periodic with period ; (strictly) monotonic. Strictly monotonic injective invertible; inverse function by solving for , graph reflected in ; restrict the domain if necessary.   Elementary functions:  and are inverse functions of each other; laws of exponents and logarithms; change of base , ; on a log scale, exponential growth becomes a straight line, . , are -periodic; , , invert restricted branches; has period . Hyperbolic functions: .   Limit  : for every sequence . Left-hand and right-hand limits must agree. Techniques for : factoring and canceling, multiplying the numerator and denominator so that a difference of two squares appears, the squeeze theorem for bounded factors. Important: (in radians), so for small . Tables of values can deceive ( at the points ).   Continuous at : . Elementary functions are continuous; sums, products, quotients and compositions of continuous functions remain continuous. Kinks are allowed (ReLU), jumps are not (shipping fee). For piecewise-defined functions, you check the junction points: the left-hand and right-hand limits must agree with the function value — this is also how you determine free parameters (continuous tariff).   Intermediate value theorem: a function that is continuous on takes on every value between and ; if the sign changes, there is a zero. Continuous extension at a gap in the domain by the limit, if it exists.   Running examples: ReLU is piecewise defined, has range and is continuous; sigmoid has values in , and saturates: as , as .      Exercises    Determine whether , , and , , are injective and whether they are surjective.     is injective: implies . But it is not surjective, since, for example, has no preimage (no satisfies ).   is also injective: implies . It is not surjective, since has no preimage ( for all ).      Check and for symmetry (even, odd or neither).    We have , so is even. For : , so is odd.      Determine .    The roots of are and , so . For , we have Hence .      Determine whether can be extended continuously at .    With the factorization (the formula for the difference of two cubes, ), we have for : Hence . The limit exists, so can be extended continuously, with the function value at .      Solve the equation for .    Applying to both sides gives , so (Check of the domain condition: holds.)     "
},
{
  "id": "sec-funktionen-stetigkeit-2",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#sec-funktionen-stetigkeit-2",
  "type": "Objectives",
  "number": "3.1",
  "title": "",
  "body": "  After this section, you can    describe maps by their domain, codomain and image, check them for injectivity, surjectivity and bijectivity, and form compositions and inverse maps;  determine the maximal domain of real functions, check them for symmetry, periodicity and monotonicity, and find inverse functions;  compute with exponential, logarithmic, trigonometric and hyperbolic functions and solve the related equations;  compute limits of functions by factoring, rationalizing, looking at one-sided limits and using the squeeze theorem;  prove continuity, choose the parameters of piecewise-defined functions so that the functions become continuous, apply the intermediate value theorem and extend functions continuously at gaps in the domain;  describe ReLU and sigmoid — the standard functions of neural networks — in terms of these concepts.   "
},
{
  "id": "sub-abbildungen-2-1",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#sub-abbildungen-2-1",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "map "
},
{
  "id": "def-abbildung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-abbildung",
  "type": "Definition",
  "number": "3.1.1",
  "title": "Map, function.",
  "body": " Map, function   A map (also called a function ) from a set to a set is an assignment that assigns to every   exactly one  . We write or, for short, .   "
},
{
  "id": "ex-abbildung-oder-nicht",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-abbildung-oder-nicht",
  "type": "Example",
  "number": "3.1.2",
  "title": "A map or not? (optional).",
  "body": " A map or not? (optional)   A university database contains a table of all students. Which of the following assignments are maps?  student ID number date of birth of the person with this number;  date of birth person with this date of birth;  real number  the numbers with .        Yes: every student ID number belongs to exactly one person, and this person has exactly one date of birth. Many numbers may be mapped to the same date; this is allowed.  No, and for two reasons: on some dates, several students were born ( exactly one is violated), and on some dates, nobody was born ( every is violated).  No: both and belong to . Only the rule take the nonnegative solution turns this into the square root function .    By the way: the student ID number determines a person uniquely , and this makes it a key in the database. So the assignment person student ID number must never give the same number to two people — exactly this property is what we will soon call injective.    "
},
{
  "id": "def-grundbegriffe-abbildung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-grundbegriffe-abbildung",
  "type": "Definition",
  "number": "3.1.3",
  "title": "Domain, image, preimage.",
  "body": " Domain, image, preimage   Let be a map. Then    is called the domain of ,  an argument of ,  the codomain of ,   the image (or range ) of ,  for and , the element the image of , and a preimage of ,  for , the set the preimage of .    The name of the argument does not matter: and describe the same map. Likewise, you must distinguish between the map itself and the single value that you get when you substitute .   "
},
{
  "id": "ex-bild-urbild-quadrieren",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-bild-urbild-quadrieren",
  "type": "Example",
  "number": "3.1.4",
  "title": "Finding images and preimages.",
  "body": " Finding images and preimages   Let , . Determine and .    Substituting gives , , , , , so (each value counts only once). For the preimage, we look for all with . Since is not a perfect square and , , we get .   "
},
{
  "id": "def-verkettung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-verkettung",
  "type": "Definition",
  "number": "3.1.5",
  "title": "Composition of maps.",
  "body": " Composition of maps   Let and be two maps such that the codomain of is contained in the domain of . Then the composition of and is the map You read as after : first is applied, then .   "
},
{
  "id": "ex-verkettung-berechnen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-verkettung-berechnen",
  "type": "Example",
  "number": "3.1.6",
  "title": "Computing a composition.",
  "body": " Computing a composition   Let , , and , . Determine and , and decide whether .    We have and . The coefficients of already differ ( versus ), so : in general, the composition of maps is not commutative.   "
},
{
  "id": "def-injektiv-surjektiv-bijektiv",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-injektiv-surjektiv-bijektiv",
  "type": "Definition",
  "number": "3.1.7",
  "title": "Injective, surjective, bijective.",
  "body": " Injective, surjective, bijective   Let be a map.     is called injective if for all with , it follows that (different elements are mapped to different elements).   is called surjective if for every , there exists an with (every element of has at least one preimage).   is called bijective if is injective and surjective.     "
},
{
  "id": "ex-injektiv-surjektiv-pruefen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-injektiv-surjektiv-pruefen",
  "type": "Example",
  "number": "3.1.8",
  "title": "Proving injectivity and surjectivity.",
  "body": " Proving injectivity and surjectivity   Determine whether , , and , , are injective and whether they are surjective.     is not injective, because with . is not surjective either, because has no preimage in (no integer squares to ).   , on the other hand, is injective: if satisfy , then , because (this is the contrapositive of the condition for injectivity). But is not surjective, since, for example, has no preimage ( , , and nothing lies in between). The example shows: injectivity and surjectivity depend not only on the formula, but also on the domain and the codomain.   "
},
{
  "id": "ssub-injektiv-surjektiv-umkehrabbildung-5",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ssub-injektiv-surjektiv-umkehrabbildung-5",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "pigeonhole principle hash function quantization "
},
{
  "id": "def-umkehrabbildung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-umkehrabbildung",
  "type": "Definition",
  "number": "3.1.9",
  "title": "Inverse map.",
  "body": " Inverse map   Let be a map. If is bijective, then , with , defines a map, the inverse map of . It is denoted by . We have and , where denotes the identity map on .   "
},
{
  "id": "ex-anwendung-temperatur-umrechnen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-temperatur-umrechnen",
  "type": "Example",
  "number": "3.1.10",
  "title": "Application: Converting temperatures.",
  "body": " Application: Converting temperatures   A sensor delivers temperatures in degrees Celsius; a US dashboard expects degrees Fahrenheit. The conversion is , . Show that is bijective, and determine the inverse map. Which Celsius temperature corresponds to  °F?    We solve for : So every has exactly one preimage : is surjective (there is one) and injective (there is only one), hence bijective, and For , we get — the normal body temperature. Check: . Solving for the input is the standard method for finding the inverse map: if it succeeds uniquely, the map is bijective.   "
},
{
  "id": "sub-grundbegriffe-funktionen-2-1",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#sub-grundbegriffe-funktionen-2-1",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "real functions "
},
{
  "id": "def-reelle-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-reelle-funktion",
  "type": "Definition",
  "number": "3.1.11",
  "title": "Real function, range, zero.",
  "body": " Real function, range, zero   We consider functions with (the domain ) and (the codomain ). If and are not given explicitly, the following tacit convention applies: is the maximal domain — the set of all real numbers that may be substituted into the formula of the function — and .  The range of is the set . A zero of is an with .   "
},
{
  "id": "ex-maximale-definitionsmenge",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-maximale-definitionsmenge",
  "type": "Example",
  "number": "3.1.12",
  "title": "Finding the maximal domain.",
  "body": " Finding the maximal domain   Determine the maximal domain of .    The expression under the square root must be nonnegative: . Moreover, the denominator must not be : . Altogether,    "
},
{
  "id": "ssub-definitionsmenge-graph-4",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ssub-definitionsmenge-graph-4",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "graph "
},
{
  "id": "def-abschnittsweise-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-abschnittsweise-funktion",
  "type": "Definition",
  "number": "3.1.13",
  "title": "Piecewise-defined function.",
  "body": " Piecewise-defined function   A function whose domain consists of finitely many intervals, each with its own formula, is called piecewise defined .   "
},
{
  "id": "ex-anwendung-relu",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-relu",
  "type": "Example",
  "number": "3.1.14",
  "title": "Application: The ReLU activation function.",
  "body": " Application: The ReLU activation function   Artificial neural networks often use the ReLU function ( rectified linear unit ) as their activation function: Give , and , and determine the range of .    Substituting gives , , . Negative inputs are always mapped to , and nonnegative inputs stay unchanged, so the range is . We return to the ReLU function in and examine whether the kink at affects its continuity.   "
},
{
  "id": "fig-relu",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#fig-relu",
  "type": "Figure",
  "number": "3.1.15",
  "title": "",
  "body": " The ReLU function: constant zero to the left of , the identity to the right — with a kink at .    A coordinate system with the graph of the ReLU function: for negative , the graph runs along the -axis; for positive , it is a straight line with slope through the origin. At the origin, the graph has a kink.     "
},
{
  "id": "def-gerade-ungerade-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-gerade-ungerade-funktion",
  "type": "Definition",
  "number": "3.1.16",
  "title": "Even and odd functions.",
  "body": " Even and odd functions   Let be a function defined on an interval that is symmetric about the origin.     is called even if for all . Its graph is then symmetric about the -axis.   is called odd if for all . Its graph is then symmetric about the origin.     "
},
{
  "id": "def-periodische-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-periodische-funktion",
  "type": "Definition",
  "number": "3.1.17",
  "title": "Periodic function.",
  "body": " Periodic function   Let be a function defined on an interval. is called periodic with period  if holds for all with . If is periodic with period , then it is also periodic with every period , ; the smallest positive period is called the fundamental period .   "
},
{
  "id": "ex-periode-bestimmen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-periode-bestimmen",
  "type": "Example",
  "number": "3.1.18",
  "title": "Application: Periods in time series.",
  "body": " Application: Periods in time series   The power consumption of an office building (in kW) over the day is modeled by , with in hours after midnight. Determine the fundamental period. When is the consumption highest?    The cosine has the fundamental period . The argument runs through one full period when increases by with , that is, : the consumption repeats in a daily cycle, . It is highest when , that is, at , i.e., at (noon), with  kW; at midnight (hour ), it is  kW. Detecting such daily, weekly and yearly periods is a standard step in the analysis of time series.   "
},
{
  "id": "def-monotone-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-monotone-funktion",
  "type": "Definition",
  "number": "3.1.19",
  "title": "Monotonic function.",
  "body": " Monotonic function   Let be a function defined on an interval. is called     monotonically increasing if for all in ; strictly increasing if even the strict inequality holds;   monotonically decreasing if for all in ; strictly decreasing if even the strict inequality holds.     "
},
{
  "id": "ex-monotonie-differenz-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-monotonie-differenz-funktion",
  "type": "Example",
  "number": "3.1.20",
  "title": "Proving monotonicity via the difference (optional).",
  "body": " Proving monotonicity via the difference (optional)   Show that is strictly increasing on .    For in , we look at the difference: Since , we have and , so the denominator is positive; the numerator is also positive, because . Hence , that is, : is strictly increasing.   "
},
{
  "id": "ex-umkehrfunktion-einschraenkung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-umkehrfunktion-einschraenkung",
  "type": "Example",
  "number": "3.1.21",
  "title": "An inverse function by restricting the domain.",
  "body": " An inverse function by restricting the domain   The function , , is not injective on all of . Find an interval with , as large as possible, on which the restriction of is injective, and determine the inverse function of this restriction.    The graph of is the standard parabola, shifted to the right and up; the function is strictly monotonic on each of the intervals and separately (and precisely there), so it is injective on each of them. Since , we choose .  We solve for (for , the range of the restriction): , and since , it follows that , so . The inverse function is therefore Check: and . If we had chosen , the negative sign would have been correct when taking the square root: . So the choice of the interval also determines the formula of the inverse function.   "
},
{
  "id": "sub-elementare-funktionen-2-1",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#sub-elementare-funktionen-2-1",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "elementary "
},
{
  "id": "def-exponentialfunktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-exponentialfunktion",
  "type": "Definition",
  "number": "3.1.22",
  "title": "Exponential function.",
  "body": " Exponential function   A function with the formula for a fixed real base is called an exponential function . For , is strictly increasing; for , it is strictly decreasing; in both cases, is bijective.   "
},
{
  "id": "thm-rechenregeln-exponential",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#thm-rechenregeln-exponential",
  "type": "Theorem",
  "number": "3.1.23",
  "title": "Rules for exponential functions.",
  "body": " Rules for exponential functions   For and , we have:            "
},
{
  "id": "def-eulersche-zahl-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-eulersche-zahl-funktion",
  "type": "Definition",
  "number": "3.1.24",
  "title": "Euler’s number.",
  "body": " Euler's number    Euler's number  is the unique real number for which the exponential function has slope at . It is irrational, . The function is called the exponential function and is also written as .   "
},
{
  "id": "ex-anwendung-verzinsung-exponentialfunktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-verzinsung-exponentialfunktion",
  "type": "Example",
  "number": "3.1.25",
  "title": "Application: The balance as an exponential function.",
  "body": " Application: The balance as an exponential function   An amount of earns interest at a fixed annual rate of . Give the balance as a function of the time (in years), and compute .    With and the growth factor per year, we have , an exponential function in . It follows that . Unlike with simple interest, grows at a fixed relative rate here — for integer , this is exactly the compound interest sequence from , now read as a function of a continuous time.   "
},
{
  "id": "def-logarithmus",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-logarithmus",
  "type": "Definition",
  "number": "3.1.26",
  "title": "Logarithm to base <span class=\"process-math\">\\(b\\)<\/span>.",
  "body": " Logarithm to base   Let , . The inverse function of the bijective exponential function , , is the logarithmic function  Since they are inverse functions of each other, we have for all and for all .   "
},
{
  "id": "thm-logarithmengesetze",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#thm-logarithmengesetze",
  "type": "Theorem",
  "number": "3.1.27",
  "title": "Laws of logarithms.",
  "body": " Laws of logarithms   For , and , we have:          "
},
{
  "id": "ssub-exponential-logarithmus-9",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ssub-exponential-logarithmus-9",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "natural logarithm change-of-base formulas "
},
{
  "id": "fig-exp-ln",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#fig-exp-ln",
  "type": "Figure",
  "number": "3.1.28",
  "title": "",
  "body": " The exponential function and the natural logarithm are inverse functions of each other: reflecting one graph in the line (dashed) gives the other.    A coordinate system with the steeply rising graph of , which crosses the -axis at , and the graph of , which crosses the -axis at and approaches the negative -axis to the left. The two graphs are mirror images of each other in the dashed diagonal .     "
},
{
  "id": "ex-exp-log-auffrischung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-exp-log-auffrischung",
  "type": "Example",
  "number": "3.1.29",
  "title": "A warm-up with school material (optional).",
  "body": " A warm-up with school material (optional)   (a) Write as a single power of . (b) Compute without a calculator. (c) Solve for .    (a) With and , the expression is . (b) Quotient law: . (c) Taking logarithms: , so .   "
},
{
  "id": "ex-anwendung-verdopplungszeit",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-verdopplungszeit",
  "type": "Example",
  "number": "3.1.30",
  "title": "Application: Doubling time.",
  "body": " Application: Doubling time   After how many years has the amount from (interest rate ) doubled?    We need with , that is, . Taking logarithms and using the third law of logarithms brings down from the exponent: After just under years, the amount has doubled — regardless of the initial amount , which has canceled out. Practitioners compute this in their heads with a rule of thumb, which we justify in .   "
},
{
  "id": "ex-anwendung-log-skala",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-log-skala",
  "type": "Example",
  "number": "3.1.31",
  "title": "Application: Exponential growth on a log scale.",
  "body": " Application: Exponential growth on a log scale   A new app has , , and users after months. Show that the data fit and that is a linear function of . If the growth continues at the same rate, when will the app have users? (Use and .)    The ratios of consecutive values are all equal, , so . Taking logarithms and using the laws of logarithms gives a straight line in with slope . For , we need , so After a little more than eleven months, that is, just under a year, the app would reach this mark. This is exactly why growth data are often plotted with a logarithmic -axis: there, exponential growth appears as a straight line, and every deviation from the line — for example, a flattening because the market is saturated — is immediately visible. For a related reason — taking logarithms turns multiplicative effects into additive ones — statisticians often log-transform incomes, prices or case counts before they fit a straight line to the data.   "
},
{
  "id": "ex-anwendung-sigmoid-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-sigmoid-funktion",
  "type": "Example",
  "number": "3.1.32",
  "title": "Application: The sigmoid function.",
  "body": " Application: The sigmoid function   In logistic regression and as an activation function in neural networks, the sigmoid function  is used to map any real value (e.g., a weighted sum of features) to a probability in the interval . Compute and show that for all .     — so an input of corresponds to maximum uncertainty. Since for all , the denominator is , so . Moreover, is strictly increasing: if increases, then decreases, so decreases, so the denominator decreases, and the fraction increases. Hence is injective and therefore invertible — its inverse function is the logit function  used in logistic regression. We examine the limiting behavior of as in .   "
},
{
  "id": "fig-sigmoid",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#fig-sigmoid",
  "type": "Figure",
  "number": "3.1.33",
  "title": "",
  "body": " The sigmoid function : strictly increasing, values in , symmetric about the point , and nearly constant for large ( saturation ).    A coordinate system with the S-shaped graph of the sigmoid function. The graph comes in from the left close to , has the value at and approaches the dashed asymptote to the right.     "
},
{
  "id": "def-arkussinus-arkuskosinus",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-arkussinus-arkuskosinus",
  "type": "Definition",
  "number": "3.1.34",
  "title": "Arcsine and arccosine.",
  "body": " Arcsine and arccosine   The arcsine is the inverse function of the restriction of the sine to : The arccosine is the inverse function of the restriction of the cosine to :    "
},
{
  "id": "ex-trigonometrische-gleichung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-trigonometrische-gleichung",
  "type": "Example",
  "number": "3.1.35",
  "title": "Solving a trigonometric equation.",
  "body": " Solving a trigonometric equation   Determine all solutions of the equation .    Rearranging gives . Since , the equation has the solution in the principal interval . Because of the symmetry of the sine ( ) and its -periodicity, we get the two solutions in the interval :    "
},
{
  "id": "ssub-trigonometrische-funktionen-6",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ssub-trigonometrische-funktionen-6",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "tangent arctangent cotangent arccotangent addition formulas "
},
{
  "id": "def-allgemeine-kosinusfunktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-allgemeine-kosinusfunktion",
  "type": "Definition",
  "number": "3.1.36",
  "title": "General cosine function.",
  "body": " General cosine function   The general cosine function has the form with amplitude  , angular frequency  and phase shift  . Its fundamental period is .   "
},
{
  "id": "def-hyperbelfunktionen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-hyperbelfunktionen",
  "type": "Definition",
  "number": "3.1.37",
  "title": "Hyperbolic functions.",
  "body": " Hyperbolic functions   The hyperbolic functions are defined as     "
},
{
  "id": "ex-hyperbel-identitaet",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-hyperbel-identitaet",
  "type": "Example",
  "number": "3.1.38",
  "title": "Proving a hyperbolic identity.",
  "body": " Proving a hyperbolic identity   Show that for all .    Substituting the definitions: Multiplying out both squares gives and . So the difference of the two squared expressions is , and therefore . Compare this with : the points lie on a circle, the points on a hyperbola — hence the name.   "
},
{
  "id": "ex-anwendung-kettenlinie",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-kettenlinie",
  "type": "Example",
  "number": "3.1.39",
  "title": "Application: The catenary (optional).",
  "body": " Application: The catenary (optional)   A chain (or an overhead power line) hanging freely between two suspension points follows the curve for a constant that depends on the length and the weight of the chain. For : how much higher is the chain at a horizontal distance of from the lowest point than at the lowest point itself?    The lowest point is at , with . At , we have So the difference in height is . A parabola looks similar, but it is not the same: anyone who plans an overhead power line computes with . By the way, if you turn the catenary upside down, you get the ideal shape of an arch, in which there is only compression and no bending. This is why the architect Antoni Gaudí designed his vaults with hanging models made of strings and weights, and the Gateway Arch in St. Louis follows a (slightly modified) inverted catenary.   "
},
{
  "id": "def-grenzwert-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-grenzwert-funktion",
  "type": "Definition",
  "number": "3.1.40",
  "title": "Limit of a function, left-hand and right-hand limit.",
  "body": " Limit of a function, left-hand and right-hand limit   Let be an interval, , and let be a function.     has the limit  at if for every sequence in the domain of with . We write .   has the left-hand (or right-hand ) limit  at if this holds for every sequence with and (or , respectively). We write or , respectively.    The two-sided limit exists if and only if both one-sided limits exist and agree.   "
},
{
  "id": "ex-wertetabelle-luegt",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-wertetabelle-luegt",
  "type": "Example",
  "number": "3.1.41",
  "title": "When the table of values lies.",
  "body": " When the table of values lies   Evaluate at . What do you conjecture about ? Then examine the sequence .    We have , and . In general, for every — the table suggests the limit . But for , we have for all . Two sequences that both tend to give different limits of the function values. So does not exist: near , the function oscillates faster and faster between and , and the sample points happened to hit the zeros every time. A computer that tries a few values would have fallen into exactly this trap.   "
},
{
  "id": "thm-rechenregeln-grenzwerte-funktionen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#thm-rechenregeln-grenzwerte-funktionen",
  "type": "Theorem",
  "number": "3.1.42",
  "title": "Limit laws.",
  "body": " Limit laws   Suppose that and . Then:       , if   (Squeeze theorem) If and for all in a neighborhood of , then .     "
},
{
  "id": "ex-grenzwert-faktorisieren",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-grenzwert-faktorisieren",
  "type": "Example",
  "number": "3.1.43",
  "title": "A limit by factoring.",
  "body": " A limit by factoring   Determine .    Substituting gives the indeterminate form ; we factor the numerator. The roots of are and , so . For , we can cancel: Hence .   "
},
{
  "id": "ex-grenzwert-rationalisieren",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-grenzwert-rationalisieren",
  "type": "Example",
  "number": "3.1.44",
  "title": "A limit by rationalizing.",
  "body": " A limit by rationalizing   Determine .    We use the difference of two squares, that is, we multiply the numerator and denominator by : As , this tends to .   "
},
{
  "id": "ex-einseitige-grenzwerte-vorzeichen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-einseitige-grenzwerte-vorzeichen",
  "type": "Example",
  "number": "3.1.45",
  "title": "One-sided limits that do not agree.",
  "body": " One-sided limits that do not agree   Show that has no limit as .    For , we have , so , and therefore . For , we have , so , and therefore . Since the two one-sided limits do not agree, does not exist.   "
},
{
  "id": "ex-sandwich-oszillation",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-sandwich-oszillation",
  "type": "Example",
  "number": "3.1.46",
  "title": "The squeeze theorem for an oscillating function.",
  "body": " The squeeze theorem for an oscillating function   Determine .    The factor oscillates as and has no limit, but it always stays between and . Hence, for all : Since , the squeeze theorem gives .   "
},
{
  "id": "ex-grenzwert-sinx-durch-x",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-grenzwert-sinx-durch-x",
  "type": "Example",
  "number": "3.1.47",
  "title": "The limit <span class=\"process-math\">\\(\\frac{\\sin(x)}{x}\\to1\\)<\/span>.",
  "body": " The limit   Determine ( in radians). First compare with a few values, then justify the result using the unit circle ( ).   On the unit circle, for : small triangle circular sector large triangle, so .    A quarter of the unit circle in the first quadrant. A ray leaves the origin at the angle . It meets the circle at the point and the vertical tangent line at at the height . Three nested regions are shaded with different intensity: the dark small triangle with vertices at the origin, and the point on the circle; the medium circular sector; and the light large triangle with vertices at the origin, and .        Substituting gives . Values: , — the limit is probably .  To justify this, let . In , three regions are nested: the small triangle with height , the circular sector with angle and the large triangle with height . Their areas are , (the sector is the fraction of the area of the circle) and , so Dividing by and taking reciprocals gives Since (the cosine is continuous, see ), the squeeze theorem gives as . The same holds for negative , because . Hence   In practice, this means: for small angles, . Engineers use this small-angle approximation all the time, for example for the simple pendulum or in optics.   "
},
{
  "id": "ex-anwendung-stueckkosten-grenzwert",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-stueckkosten-grenzwert",
  "type": "Example",
  "number": "3.1.49",
  "title": "Application: Unit cost for large production volumes (optional).",
  "body": " Application: Unit cost for large production volumes (optional)   A company has fixed costs of € and variable costs of € per unit. Because of volume discounts on purchased materials, the variable cost of each additional unit decreases as the number of units grows, so that the total cost is . What value does the unit cost approach as ?    We divide each term by : As , we have and , so The fixed costs are spread over more and more units and vanish per unit ( spreading of fixed costs ); what remains are the variable costs, reduced by the discount to € per unit. The technique is the same as for sequences ( ): divide by the highest power.   "
},
{
  "id": "ex-anwendung-sigmoid-grenzwert",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-sigmoid-grenzwert",
  "type": "Example",
  "number": "3.1.50",
  "title": "Application: Saturation of the sigmoid function.",
  "body": " Application: Saturation of the sigmoid function   Determine and for the sigmoid function from .    As , we have , so , and hence . As , we have , so , and hence . So for large , the sigmoid function approaches the horizontal asymptotes and , respectively — it saturates . This saturation matters when neural networks are trained: for very large , the function value becomes nearly constant, which leads to very small gradients (as shown in ).   "
},
{
  "id": "def-stetigkeit",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-stetigkeit",
  "type": "Definition",
  "number": "3.1.51",
  "title": "Continuity.",
  "body": " Continuity   A real function is continuous at  if If is continuous at every point of , then is called continuous .   "
},
{
  "id": "ex-anwendung-versandkosten-unstetig",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-versandkosten-unstetig",
  "type": "Example",
  "number": "3.1.52",
  "title": "Application: A shipping fee with a jump.",
  "body": " Application: A shipping fee with a jump   An online retailer charges a shipping fee of € for orders worth euros; from € on, shipping is free. So the invoice total is Is continuous at ?    From the left, ; from the right, . The one-sided limits do not agree, the limit does not exist, and is discontinuous at — the graph jumps down by € . This jump is intended: if you order goods worth € , you pay € ; if you buy € more, you pay only € . Discontinuous tariffs deliberately create incentives.   "
},
{
  "id": "ex-anwendung-stromtarif-stetig",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-stromtarif-stetig",
  "type": "Example",
  "number": "3.1.53",
  "title": "Application: Making an electricity tariff continuous.",
  "body": " Application: Making an electricity tariff continuous   An energy supplier charges € per kWh for an annual consumption of up to  kWh. Customers who use more pay a base fee plus € per kWh for their entire consumption: How must be chosen so that is continuous? What happens with euros?    Both pieces are continuous, since they are linear functions; only the junction point is critical. There, we have  is continuous if and only if , that is, euros. With euros, in contrast, the bill jumps down by € at the threshold: a household with  kWh pays € , one with  kWh only € . So a household just below the threshold would save money by using more electricity — a classic threshold effect , which a continuous tariff avoids.   "
},
{
  "id": "thm-kombination-stetiger-funktionen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#thm-kombination-stetiger-funktionen",
  "type": "Theorem",
  "number": "3.1.54",
  "title": "Combinations and compositions of continuous functions.",
  "body": " Combinations and compositions of continuous functions   If and are continuous at , then , and (if ) are also continuous at . If is continuous at and is continuous at , then the composition is also continuous at . All elementary functions ( ) are continuous on their entire domain.   "
},
{
  "id": "ex-stetigkeit-verkettung-nachweisen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-stetigkeit-verkettung-nachweisen",
  "type": "Example",
  "number": "3.1.55",
  "title": "Continuity of a composite function (optional).",
  "body": " Continuity of a composite function (optional)   Explain why is continuous on all of .     is continuous as a polynomial and always positive, and the square root function is continuous on , so the composition is continuous on all of . Likewise, and are continuous as elementary functions, and so is their composition . As the product of two functions that are continuous on , is therefore also continuous on all of .   "
},
{
  "id": "ex-anwendung-relu-stetigkeit",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-relu-stetigkeit",
  "type": "Example",
  "number": "3.1.56",
  "title": "Application: The ReLU function is continuous.",
  "body": " Application: The ReLU function is continuous   Show that the ReLU function from , is continuous at .    The left-hand limit is , the right-hand limit is . The two agree with each other and with the function value , so : is continuous at — despite the kink in its graph. Continuity only requires matching limits, not smoothness ; we examine in whether the function is also differentiable at this point.   "
},
{
  "id": "thm-zwischenwertsatz-nullstellensatz",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#thm-zwischenwertsatz-nullstellensatz",
  "type": "Theorem",
  "number": "3.1.57",
  "title": "Intermediate value theorem, Bolzano’s theorem.",
  "body": " Intermediate value theorem, Bolzano's theorem   Let be a function that is continuous on .    ( Intermediate value theorem ) takes on every value between and at least once.  ( Bolzano's theorem ) If and have opposite signs, then has at least one zero in .     "
},
{
  "id": "ex-intervallhalbierung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-intervallhalbierung",
  "type": "Example",
  "number": "3.1.58",
  "title": "Computational example: Locating zeros by interval bisection.",
  "body": " Computational example: Locating zeros by interval bisection   Show that has a zero in , and narrow it down by halving the interval four times.     is continuous as a polynomial, and , . By Bolzano's theorem, there is a zero in . Now we evaluate at the midpoint of the interval and keep the half whose endpoints give values of opposite sign: So the zero lies between and (in fact, at ). Each step halves the uncertainty; after steps, the interval has length , so after steps it is shorter than one millionth. The bisection method is slower than Heron's method or Newton's method, which we treat later ( ), but it works for every continuous function with a sign change.   "
},
{
  "id": "ex-bergwanderung-zwischenwertsatz",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-bergwanderung-zwischenwertsatz",
  "type": "Example",
  "number": "3.1.59",
  "title": "The mountain hike puzzle.",
  "body": " The mountain hike puzzle   A hiker sets off from the valley at 6:00 in the morning and reaches the mountain hut at 18:00. The next morning, she starts her descent on the same trail at 6:00 and is back in the valley at 18:00. On the way, she walks at very different speeds on the two days and takes breaks wherever she likes. Is there a point on the trail where she is at the same time of day on both days?    The answer is yes — no matter how she walks. Let be the length of the trail, her position (the distance along the trail from the valley) on the first day and her position on the second day, each at the time . Both functions are continuous, because nobody jumps. The difference is also continuous, and By Bolzano's theorem, there is a with , that is, : at the time , she is at the same point on both days.  If you do not believe this, imagine two hikers who set off on the same day, one from below and one from above — they must meet on the way. What is remarkable is what the proof does not give: it does not say when and where they meet. Bolzano's theorem is a pure existence theorem, just like the fundamental theorem of algebra in .   "
},
{
  "id": "def-stetige-fortsetzung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-stetige-fortsetzung",
  "type": "Definition",
  "number": "3.1.60",
  "title": "Continuous extension.",
  "body": " Continuous extension   Let be an interval, , and a function defined on . If the limit exists, then can be extended continuously by    "
},
{
  "id": "sub-zusammenfassung-3-1-2",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#sub-zusammenfassung-3-1-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Map Injective: Surjective: Bijective: Real functions: Elementary functions: Limit Continuous Intermediate value theorem: Continuous extension Running examples: "
},
{
  "id": "exercise-buch-injektiv-surjektiv",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#exercise-buch-injektiv-surjektiv",
  "type": "Exercise",
  "number": "3.1.7.1",
  "title": "",
  "body": "  Determine whether , , and , , are injective and whether they are surjective.     is injective: implies . But it is not surjective, since, for example, has no preimage (no satisfies ).   is also injective: implies . It is not surjective, since has no preimage ( for all ).   "
},
{
  "id": "exercise-buch-gerade-ungerade-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#exercise-buch-gerade-ungerade-funktion",
  "type": "Exercise",
  "number": "3.1.7.2",
  "title": "",
  "body": "  Check and for symmetry (even, odd or neither).    We have , so is even. For : , so is odd.   "
},
{
  "id": "exercise-buch-grenzwert-faktorisieren",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#exercise-buch-grenzwert-faktorisieren",
  "type": "Exercise",
  "number": "3.1.7.3",
  "title": "",
  "body": "  Determine .    The roots of are and , so . For , we have Hence .   "
},
{
  "id": "exercise-buch-stetige-fortsetzung-kubisch",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#exercise-buch-stetige-fortsetzung-kubisch",
  "type": "Exercise",
  "number": "3.1.7.4",
  "title": "",
  "body": "  Determine whether can be extended continuously at .    With the factorization (the formula for the difference of two cubes, ), we have for : Hence . The limit exists, so can be extended continuously, with the function value at .   "
},
{
  "id": "exercise-buch-logarithmusgleichung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#exercise-buch-logarithmusgleichung",
  "type": "Exercise",
  "number": "3.1.7.5",
  "title": "",
  "body": "  Solve the equation for .    Applying to both sides gives , so (Check of the domain condition: holds.)   "
},
{
  "id": "sec-differenzialrechnung",
  "level": "1",
  "url": "sec-differenzialrechnung.html",
  "type": "Section",
  "number": "3.2",
  "title": "Differential calculus",
  "body": " Differential calculus    After this section, you can    explain the derivative as the limit of the difference quotient and compute it directly from the definition for simple functions;  distinguish differentiability from continuity — and use the kink of the ReLU function to show why;  set up tangent lines and use them to approximate function values linearly;  compute derivatives with the product, quotient, chain and inverse function rules;  read off monotonicity, extrema, curvature and inflection points from and , and solve optimization problems with a constraint;  carry out a few steps of Newton's method and of gradient descent by hand;  compute limits with L'Hôpital's rule and use the mean value theorem for estimates.     How much do the costs rise when one more unit is produced? How fast is a capacitor discharging right now ? In which direction must a learning algorithm shift its parameters so that the error decreases? All three questions ask for an instantaneous rate of change — and this is called the derivative. This section introduces it via the slopes of secants and tangents. It provides the rules that let you compute derivatives without taking limits, and then shows what you can do with derivatives: sketch curves, solve optimization problems, track down zeros and minima iteratively, and evaluate tricky limits with L'Hôpital's rule.  Along the way, you will learn why there are three notations for the derivative, why beverage cans do not look the way the school exercise demands, why the ancient square root algorithm from is in fact Newton's method — and who really invented L'Hôpital's rule. You know some of the rules from school; take your time with the examples anyway, because in the exercises you will have to combine them much more often.    Definition and meaning of the derivative   A car covers  km on the highway in one hour. So its average speed is  km\/h — but the speedometer has shown many different values during this hour. What does the speedometer actually measure? It measures an instantaneous rate of change: the distance covered in a very short time span, divided by this time span. Exactly this idea — an average over a shorter and shorter interval — leads to the derivative .  In , we saw that continuity only requires that the graph of the function can be drawn without lifting the pencil — kinks are expressly allowed. The derivative is a sharper notion: it measures the local slope of a function, and where a graph has a kink, there is no unique slope.    From the secant to the tangent  A tangent to a function at the point is a line that touches the graph of at without crossing it in the immediate vicinity of . To determine its slope, we approach it via secants : lines through two points of the graph.   Secant through and (left); in the limit , it becomes the tangent at (right).    Two coordinate systems with the same parabola. In the left one, two points of the parabola are marked and connected by a secant. In the right one, only one point is marked, and the tangent to the parabola passes through it.       Difference quotient   The slope of the secant through the points and is This expression is called the difference quotient of between and .     Computational example: Secant slopes that stabilize (optional)   For and , compute the slopes of the secants to , , and . What slope of the tangent do you conjecture?     The closer moves to , the closer the secant slopes are to . So the tangent at should have slope . This is still a conjecture — the following definition turns closer and closer into a limit, and in , we confirm the value exactly.     Derivative, differentiability   Let and . If the following limit exists, then is called differentiable at the point , and is called the derivative of at the point . It is the slope of the tangent to at the point . Common notations are , and . If is differentiable at every point of , then is called (for short) differentiable .    The two forms of the limit in are equivalent: with , that is, , we have if and only if . The second form is often more convenient for concrete computations.  There are several notations for the derivative for historical reasons — and this has to do with what is probably the most bitter priority dispute in the history of science. The Englishman Isaac Newton and the German Gottfried Wilhelm Leibniz developed differential calculus independently of each other between the 1660s and the 1680s. Newton wrote and thought of velocities; Leibniz wrote and thought of quotients of tiny differences. The two of them and their followers argued for decades about who had been first; a commission of the Royal Society — whose president was Newton himself — decided in his favor in 1712, which is hardly surprising. Nevertheless, it was mainly Leibniz's notation that prevailed, because it is so convenient to compute with; in physics, Newton's dot lives on for derivatives with respect to time. Finally, the prime comes from Joseph-Louis Lagrange (1797), so it was added only long after the dispute. It is the shortest variant — we use it most of the time.   Derivative of from the definition   Determine the derivative of at an arbitrary point directly from the difference quotient — without using any differentiation rules.    We substitute into the definition: Multiplying out the numerator gives , so At the point , this is , as conjectured in . The factor cancels before the limit is taken — this is exactly what makes the limit computable at all, since the difference quotient itself is not defined for (denominator ).    Even without any limit computation, you can see the derivative of a line : the difference quotient is for every , so — the tangent to a line is the line itself.    Differentiability and continuity   Differentiability implies continuity   If is differentiable at the point , then is also continuous at the point .    The converse does not hold: continuity at a point does not guarantee differentiability there.   The ReLU function is continuous but not differentiable everywhere   In , we showed that the ReLU function is continuous at the point . Determine whether it is also differentiable there.    We look at the difference quotient for separately from the left and from the right. For , we have , so For , we have , so So the right-hand limit of the difference quotient is , and the left-hand limit is — they do not agree, and the limit does not exist. So is not differentiable at the point , although it is continuous there: the kink in the graph is continuous but not smooth. (In machine learning practice, this point is usually simply assigned a value when differentiating, often or — a so-called subgradient .)      The derivative function and linear approximation  If is differentiable on its whole domain, we can consider the derivative function  , whose value at the point is the derivative . By , for example, the derivative function of is given by .  If you know , you can write down the tangent to at the point explicitly — and this tangent gives a good linear approximation of near .   The tangent as a linear approximation   Let be differentiable at the point . The tangent to at the point is the line with the equation In a precise sense, it approximates better than any other line through : that is, the difference goes to faster than .     Computational example: Approximating a root by hand   The derivative of is . Use the approximation formula to compute approximately — using only and the value , which you can compute in your head.    We choose , since we know (because ), and is close to . With , the approximation formula gives The exact value is — the linear approximation already gets it right to three decimal places.     Application: Instantaneous rate of change when a capacitor discharges   A camera flash stores charge in a capacitor, and this charge is released when the flash fires. The charge (in microcoulombs) remaining on the capacitor at time (in seconds) after firing approximately follows . Determine the instantaneous rate of change of at time by approximating it with the difference quotient for , and interpret the sign.    We have and , so The instantaneous rate of change is negative — at time , the charge decreases by about microcoulombs per second. In general, is the discharge current (up to the sign): the derivative of a stock variable with respect to time is its instantaneous rate of change, here a physical current. With the differentiation rules from the next subsection, you can determine the exact value ( ).       Rules for computing derivatives   Determining the derivative of every function directly from the limit of the difference quotient ( ) would be tedious: even for , you would have to compute an unwieldy limit. Fortunately, this is necessary only once — for the building blocks. The following rules say how derivatives behave when functions are added, multiplied, divided, composed and inverted. With them and a small table of basic derivatives, you can differentiate every elementary function, without any limits at all.    The differentiation rules   Differentiation rules   Let be differentiable at the point , and let . Then , , and (if ) are also differentiable at the point , with    ( linearity ) and ,  ( product rule ) ,  ( reciprocal rule ) (if ),  ( quotient rule ) .    If, in addition, is differentiable at the point and at the point , then is also differentiable at the point , with    ( chain rule ) .    If is strictly monotonic and differentiable on an interval with , then the inverse function is also differentiable at the point , with    ( inverse function rule ) .       Deriving the product rule (optional)   Derive the product rule using the difference quotient.    For the difference quotient of at the point , we cleverly insert a zero, namely , and rearrange: As , the first fraction tends to , the factor to (continuity of , ), and the second fraction to . Altogether,      Derivative of with the product rule   Use the product rule to determine the derivative of for , .    We write . If the formula is already known for the exponent , that is, , then the product rule gives So the formula carries over from each exponent to the next. Since it holds for ( ), it holds step by step for , that is, for all (and, as one can show separately, more generally for with any real exponent ).    With the product rule, we know the derivative of every power , . But where do the derivatives of the other basic building blocks come from? For and , two preparations from now pay off.   Where the derivatives of and come from   Derive and from the definition of the derivative. Use the fact that has slope at the point ( ), the addition formula for the sine, and the limit ( ).     Exponential function: With the law of exponents , we have because is exactly the difference quotient at the point , and the slope there is equal to by the definition of . So the exponential function is its own derivative — the property that makes the natural base.   Sine: With the addition formula , we get The second fraction goes to . For the first one, we multiply the numerator and denominator by and use : Altogether, the difference quotient goes to . In a very similar way, follows. If we had computed in degrees, would go to instead of , and this factor would appear in every derivative — one more reason to use radians.     Derivative of the tangent function with the quotient rule   Use the quotient rule to determine the derivative of .    With and : where we used . Since , we obtain, equivalently, .    The chain rule is the most important of the rules, and you can picture it as a gear train. If the middle gear turns twice as fast as the first one, and the last gear turns three times as fast as the middle one, then the last one turns six times as fast as the first: the gear ratios multiply. In Leibniz's notation, this looks like computing with fractions, — a convenient memory aid. ( is not a real fraction; the chain rule has to be proved, and the canceling only looks that way. )   A derivative with the chain rule   Use the chain rule to determine the derivative of .    We write with the outer function and the inner function . We have and , so     The most common mistake with the chain rule is to forget the derivative of the inner function , : is not but . In practice, several rules usually occur at the same time.   Several rules in one computation   Differentiate and .     is a product whose second factor is a composition. We use the product rule, and inside it the chain rule, where the derivative of the inner function is : Factoring out pays off: in this form, you can read off the zeros and of the derivative directly — exactly what you need in when you look for extrema.   is a composition with the outer function and the inner function :      Application: The exact discharge current   For the capacitor charge from , determine the derivative and the exact value .    Chain rule, where the derivative of the inner function is : The difference quotient with had given — a usable approximation, but off by almost . In addition, you can now see: . The rate at which the charge decreases is, at every moment, proportional to the charge still present. This observation is the starting point of the differential equations in .      Derivatives of elementary functions  With the inverse function rule, you can also obtain the derivatives of inverse functions, for example of the logarithm.   Derivative of the natural logarithm with the inverse function rule   Use the inverse function rule to determine the derivative of , the inverse function of .    With and , the inverse function rule gives     This gives the following overview of the derivatives of the most important elementary functions.   Derivatives of elementary functions    Function  Derivative   (constant)  ,   ,            With the table and the tangent formula from , we can now also solve old puzzles.   Application: Why the rule of 70 works   In , we computed the doubling time of a balance. Practitioners use the rule of thumb doubling time divided by the interest rate in percent. Set up the tangent to at the point , and use it to justify the rule of thumb via the approximation . How accurate is it for and for ?    With and , the tangent is Setting , you get for small — exactly the approximation we are looking for. So the doubling time is approximately , and with in percent approximately . The is not only easier to divide by, it is even more accurate: since ( ), the exact doubling time is somewhat longer than (with in percent: ) — at , it is years instead of , and the rule of 70 gives . For , we have , so the approximation is accurate to within . For , we have compared with — already off. The tangent is a good approximation only near .      Derivatives in data science and business  To conclude, here are three applications in which the derivative has a concrete meaning: as a gradient in the training of neural networks, as marginal cost and as a building block of price elasticity.   Application: The derivative of the sigmoid function   For the sigmoid function from , the derivative is needed again and again when neural networks are trained. Show that .    We write and apply the chain rule and the reciprocal rule (or directly the reciprocal rule with , ): To express this in terms of itself, we write the numerator as : This form is valuable in practice: if has already been computed (for example, in the forward pass of a neural network), you can determine without evaluating the exponential function again.  The formula also reveals how small this derivative is: the product is at most for (at , that is, ), and for large , goes to or , and hence . So the saturation from means vanishing gradients : in deep networks, where many such factors are multiplied, hardly any signal arrives during learning — one of the reasons why the ReLU function is usually preferred today; its derivative is equal to everywhere to the right of .     Application: Marginal cost   A company has the cost function (total cost in euros when units are produced). The marginal cost  indicates approximately by how much the total cost rises when one additional unit is produced. Determine the marginal cost at a production quantity of units.    With the power rule, term by term: Substituting : So the st unit costs approximately € extra — much less than the average cost per unit at this point ( euros), a typical picture of economies of scale at a medium production quantity.     Application: Price elasticity of demand   The price elasticity of demand measures how strongly the quantity demanded reacts, in relative terms, to a relative change in price: For the demand function (quantity demanded as a function of the price in euros), determine and interpret the result.    We have (constant) and , so The absolute value means elastic demand at : a price increase of makes the quantity demanded fall by about — the quantity reacts more than proportionally to price changes. For the revenue , this means that a price increase lowers it and a slight price cut raises it. Check: , but .       Applications of differentiation   The derivative is not just a computational tool — its sign and its zeros reveal a lot about the behavior of a function: where it increases or decreases, where it attains a local maximum or minimum, and how its graph is curved. These relationships are the basis of curve sketching and of many optimization problems.  Optimization is a core task in business and data science: maximize the profit, minimize the consumption of material, minimize the error of a model. Differential calculus provides a clear recipe for this — find candidates via , then check them — and, where the equations can no longer be solved by hand, iterative methods such as Newton's method and gradient descent.    Monotonicity and extrema   First derivative and monotonicity   Let be a function that is differentiable on an interval . Then:    for all   is strictly increasing on ,  for all   is monotonically increasing on ,  for all   is constant on ,  for all   is monotonically decreasing on ,  for all   is strictly decreasing on .      This fact is a direct consequence of the mean value theorem , which we provide later in — together with the justification ( ).  Where a differentiable function changes from rising to falling, its graph has a hilltop, and there the tangent is horizontal. We now make this observation precise.   Local extremum   Let , . has a local maximum (or local minimum ) at if there is an such that (or , respectively) for all with . In this case, the point is called an extremum of .     Necessary condition for an extremum   Let have an extremum at the point . If lies in an open interval and is differentiable at the point , then A point with is called a critical point of .    The condition is necessary but not sufficient: for , we have , but is strictly increasing at and has no local extremum there. The following two tests close this gap.   First derivative test for extrema   Let be a critical point of , that is, .    If changes sign from to at , then has a local maximum at .  If changes sign from to at , then has a local minimum at .       Second derivative test for extrema   Let be twice differentiable, and let be a critical point of .    If , then has a local maximum at .  If , then has a local minimum at .  If , this test gives no conclusion — you have to fall back on the first test (or on higher derivatives).       Application: Monotonicity and extrema of a profit function   A company models its profit (in thousands of euros) as a function of the production quantity (in thousands of units) by Determine the critical points of , determine where the function is increasing and where it is decreasing, and classify the critical points with the second derivative test.    Derivative: . Critical points: and .  Sign of : for , and are both negative, so their product is positive; with the factor , — decreases. For , we have and , so the product is negative and — increases. For , both factors are positive, so — decreases again.  Second derivative: . We have , so there is a local minimum at with ; and , so there is a local maximum at with .  Economically: at a small production quantity, the fixed costs dominate, and the profit first falls, down to a loss of € at units produced; after that, additional production pays off, up to a maximum profit of € at units, beyond which the costs again grow faster than the revenue.    Caution: finds only extrema in the interior of the domain. If a function is given on a closed interval , then for the global maximum or minimum, you must also compare the boundary values and . If the company in the example can produce at most units, then , , and : the global maximum on is the local maximum at , but the global minimum lies at the boundary, at — not at the local minimum .    Convexity, concavity and inflection points  The second derivative describes how the slope changes, and hence in which direction the graph is curved.   Convex and concave functions   Let be a function defined on an interval . is called convex (concave up) if its graph lies below every line segment connecting two of its points, that is, for all , :  is called concave (concave down) if is convex.     Convexity and the second derivative   Let be twice differentiable. Then:    for all   is convex on ,  for all   is concave on .    If is convex on , then a local minimum of in is also the global minimum of on — a property that makes optimization methods such as gradient descent ( ) particularly reliable for convex functions.     Inflection point   Let be twice differentiable. A point is called an inflection point if the curvature of changes from convex to concave (or vice versa) at . For to be an inflection point, is a necessary condition — a sign change of at is sufficient.     Application: Curvature and inflection point of the profit function   Check the profit function from for convexity, concavity and inflection points.    From , it follows that . So is convex on and concave on ; at , changes sign (from to ), so there is an inflection point there, with .  The inflection point lies exactly between the two critical points and from . This is not a coincidence: between a local minimum and a local maximum of a twice differentiable function, there is always at least one inflection point (there the slope changes from increasing to decreasing, so changes sign). That it even lies exactly in the middle here is a special feature of polynomials of degree three: is a parabola with the zeros and , and its vertex, the zero of , lies symmetrically between them.     Application: An optimization problem with a constraint — the optimal can   A cylindrical can with radius and height is to hold a volume of liter ( ). Determine and such that the amount of material — the surface area of the can — is minimal.    The surface consists of the lid, the bottom and the side wall: . The constraint gives . Substituting turns into a function of one variable:   Necessary condition: , so Since for all , is convex on , so the critical point is a (global) minimum.  The corresponding height is With , that is, , this simplifies to . So the can that uses the least material for a given volume always has a height equal to its diameter, — regardless of the specific volume.    A reality check is worthwhile: pick up a beverage can. A standard -liter can has a diameter of about  cm and a height of  cm — so it is much slimmer than the model demands. Is the beverage industry too dumb to take derivatives? No, the model is too simple. The lid and the bottom of a can must withstand the internal pressure and are therefore made of much thicker sheet metal than the side wall. If a square centimeter of lid costs times as much material as a square centimeter of side wall, the objective function for the material cost is , and the same computation as above gives So the ratio of a real can fits lids that use about times as much material as the wall. The moral: a mathematical optimum is only ever as good as the model that you optimize.    Approximating zeros: Newton's method  Many equations cannot be solved exactly. Newton's method uses the derivative to approximate zeros iteratively: it replaces at the current approximation by its tangent and uses the zero of this tangent as the next approximation.   Newton's method   Let be twice continuously differentiable on with on . Beginning with a starting value  , one computes the approximations  iteratively. Under suitable assumptions, the sequence converges to a zero of in .     Computational example: Two steps of Newton's method by hand   Approximate with two steps of Newton's method, applied to with starting value .    We have . First step:   Second step, with : and , so The exact value is — after only two steps, five decimal places already agree. This very fast (quadratic) convergence is typical of Newton's method as soon as the starting value is close enough to the zero we are looking for.  In , we claimed that Heron's method is a special case of Newton's method. Now we can verify this: for , Newton's iteration reads — exactly Heron's iteration. So about two thousand years ago, without knowing anything about derivatives, Heron of Alexandria already used Newton's method for square roots.    As fast as the method is when it works, there is no guarantee. The tangent is a good approximation only near the point of tangency, and a poor starting value can send the method in the wrong direction.   When Newton's method goes in circles (optional)   Apply Newton's method to with starting value . What do you observe?    We have . Hence The method jumps back and forth between and forever and never finds the zero. Yet does have one: since and , there is a zero in by Bolzano's theorem (it is approximately ). With a starting value near it, for example , the method converges without any problems. (Between and , on the other hand, there is no zero at all, and vanishes there at — the assumptions of are not satisfied on this interval.) In practice, one therefore often combines the two: first get close to the zero with the slow but safe bisection method ( ), then use Newton's method for the last digits.     Application: Gradient descent by hand    Gradient descent is the workhorse of machine learning. To find the minimum of a loss function — that is, a critical point with — you start at and repeatedly take a step against the slope: For with starting value and learning rate , carry out two steps. What happens instead for and for ?    We have , and the minimum is at (because and ). With : The sequence approaches , and the distance is halved in each step: , so for , the factor is — exactly the geometric sequence from .  For , the factor is : already hits the minimum exactly. For , the factor is : , , … — the iteration jumps around the minimum with a growing amplitude and diverges. So the learning rate must match the curvature : Newton's method, applied to , automatically chooses (here ) and therefore lands on the minimum in one step. It is a second-order method , but it needs to know the second derivative, which is too expensive with millions of parameters. That is why, in practice, one settles for gradient descent and a carefully chosen learning rate.       The mean value theorem and L'Hôpital's rule   To conclude this section, we present two closely related tools: the mean value theorem , which derives abstract statements about a function from pointwise knowledge about its derivative, and L'Hôpital's rule , with which you can compute many limits of the type or that cannot be computed with the limit laws from alone.    The mean value theorem   Mean value theorem   Let be continuous on and differentiable on . Then there exists a with     Geometrically, the mean value theorem says that between and , there is at least one point at which the tangent to is parallel to the secant through and .   Mean value theorem: the tangent to at the point is parallel to the secant through and .    A coordinate system with a curved graph between the points a and b. A dashed secant connects the points of the curve above a and b. At an interior point c, the tangent to the curve is drawn, parallel to the secant.       Application: Average speed check (optional)   In an average speed check , a vehicle is recorded at two checkpoints  km apart; the speed limit is  km\/h. A vehicle takes minutes to cover this distance. The driver insists that the speedometer never showed more than  km\/h. What does the mean value theorem say about this?    Let be the distance covered (in km) after hours. With minutes  h, the average speed is The distance–time function of a car is differentiable (the car has a speed at every moment, and its position does not jump), and its derivative is the instantaneous speed. So by the mean value theorem, there is a time with  km\/h. The driver's statement cannot be true — even though no instantaneous speed was measured anywhere.     Justification of the monotonicity test  The mean value theorem justifies the monotonicity test from : if on all of , and are arbitrary points of , then the mean value theorem on gives a with Since and , it follows that , that is, : is strictly increasing. The other cases of the test follow in the same way.    An inequality for the logarithm   Use the mean value theorem to show that for all .    Let be fixed, and let on ; is continuous there and differentiable on with . The mean value theorem gives a with Since , we have , so (because ). Hence for all .      L'Hôpital's rule   L'Hôpital's rule   Let be differentiable on an interval around (possibly except at itself), let near , and suppose that one of the following two cases holds: If the limit exists, then     The name of the rule is a small historical injustice. It was discovered by the Swiss mathematician Johann Bernoulli. In the 1690s, the French Marquis de l'Hôpital paid Bernoulli to teach him the new differential calculus and to hand his results over to him, and in 1696 he included the rule in his textbook — the very first textbook on differential calculus. Since then, the rule has borne his name.  The rule also holds, in the corresponding form, for and for one-sided limits. If again leads to an indeterminate form or , the rule may be applied again .  The rule explicitly requires an indeterminate form. If you apply it blindly, you get nonsense: for , substituting immediately gives ; differentiating the numerator and the denominator separately, on the other hand, would wrongly give . Note also: the numerator and the denominator are differentiated separately — the fraction is not differentiated with the quotient rule.   Computational example: Applying L'Hôpital's rule twice   Determine .    As , both the numerator ( ) and the denominator ( ) go to : indeterminate form . Differentiating the numerator and the denominator: Here, too, the numerator and the denominator both go to again as — so we apply the rule again: So .     Application: Comparing growth — logarithm versus square root function   Determine .    As , the numerator and the denominator both go to : indeterminate form . With and :   This result is a special case of a general hierarchy of growth rates that is used all the time in the analysis of algorithms (big O notation): as , grows more slowly than any positive power ( ), and every power function in turn grows more slowly than — in short, . L'Hôpital's rule is the standard tool for proving such growth comparisons exactly.       Summary     Derivative:  — the slope of the tangent, the instantaneous rate of change. Differentiable continuous, but not conversely (ReLU at ).   Tangent and linear approximation:  , and for near — for example, (rule of 70).   Differentiation rules:  , , , , , ; in addition, the table of elementary derivatives ( , , , , , , , …); here and (in radians). The chain rule in Leibniz notation: .   Curve sketching:  increasing, decreasing. Extremum  (necessary); sufficient: a sign change of , or ( maximum, minimum). convex, concave; an inflection point where changes sign. If is convex, a local minimum is global.   Optimization problem: solve the constraint for one variable, substitute, and analyze the function of one variable. On , also compare the boundary values , to find global extrema.   Iterative methods: Newton's method for zeros (very fast near the solution, but no guarantee with a poor starting value; for , it is Heron's method); gradient descent for minima (the learning rate decides whether it converges).   Mean value theorem:  for some — the basis of the monotonicity test and of many estimates. L'Hôpital: for or , if the limit on the right exists; apply the rule several times if necessary.   Applications: marginal cost , elasticity , discharge current , the derivative of the sigmoid (vanishing gradients), the hierarchy of growth rates .      Exercises    Determine the derivative of (for ) directly from the difference quotient — without using any differentiation rules.           Use the chain rule to determine the derivative of .    With the outer function and the inner function :       Determine the equation of the tangent to at the point .    We have and , so . With the tangent formula :       Determine all local extrema of and classify them with the second derivative test.     ; the critical points are and . With : , so there is a local minimum at with ; and , so there is a local maximum at with .      Use L'Hôpital's rule to determine .    As , the numerator and the denominator both go to (indeterminate form ). Differentiating the numerator and the denominator:      "
},
{
  "id": "sec-differenzialrechnung-2",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sec-differenzialrechnung-2",
  "type": "Objectives",
  "number": "3.2",
  "title": "",
  "body": "  After this section, you can    explain the derivative as the limit of the difference quotient and compute it directly from the definition for simple functions;  distinguish differentiability from continuity — and use the kink of the ReLU function to show why;  set up tangent lines and use them to approximate function values linearly;  compute derivatives with the product, quotient, chain and inverse function rules;  read off monotonicity, extrema, curvature and inflection points from and , and solve optimization problems with a constraint;  carry out a few steps of Newton's method and of gradient descent by hand;  compute limits with L'Hôpital's rule and use the mean value theorem for estimates.   "
},
{
  "id": "sub-ableitung-definition-2-1",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-ableitung-definition-2-1",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "derivative "
},
{
  "id": "sub-tangente-sekante-2",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-tangente-sekante-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "tangent secants "
},
{
  "id": "fig-sekante-tangente",
  "level": "2",
  "url": "sec-differenzialrechnung.html#fig-sekante-tangente",
  "type": "Figure",
  "number": "3.2.1",
  "title": "",
  "body": " Secant through and (left); in the limit , it becomes the tangent at (right).    Two coordinate systems with the same parabola. In the left one, two points of the parabola are marked and connected by a secant. In the right one, only one point is marked, and the tangent to the parabola passes through it.     "
},
{
  "id": "def-differenzenquotient",
  "level": "2",
  "url": "sec-differenzialrechnung.html#def-differenzenquotient",
  "type": "Definition",
  "number": "3.2.2",
  "title": "Difference quotient.",
  "body": " Difference quotient   The slope of the secant through the points and is This expression is called the difference quotient of between and .   "
},
{
  "id": "ex-sekantensteigungen-numerisch",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-sekantensteigungen-numerisch",
  "type": "Example",
  "number": "3.2.3",
  "title": "Computational example: Secant slopes that stabilize (optional).",
  "body": " Computational example: Secant slopes that stabilize (optional)   For and , compute the slopes of the secants to , , and . What slope of the tangent do you conjecture?     The closer moves to , the closer the secant slopes are to . So the tangent at should have slope . This is still a conjecture — the following definition turns closer and closer into a limit, and in , we confirm the value exactly.   "
},
{
  "id": "def-ableitung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#def-ableitung",
  "type": "Definition",
  "number": "3.2.4",
  "title": "Derivative, differentiability.",
  "body": " Derivative, differentiability   Let and . If the following limit exists, then is called differentiable at the point , and is called the derivative of at the point . It is the slope of the tangent to at the point . Common notations are , and . If is differentiable at every point of , then is called (for short) differentiable .   "
},
{
  "id": "ex-ableitung-x-quadrat-differenzenquotient",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-x-quadrat-differenzenquotient",
  "type": "Example",
  "number": "3.2.5",
  "title": "Derivative of <span class=\"process-math\">\\(f(x)=x^2\\)<\/span> from the definition.",
  "body": " Derivative of from the definition   Determine the derivative of at an arbitrary point directly from the difference quotient — without using any differentiation rules.    We substitute into the definition: Multiplying out the numerator gives , so At the point , this is , as conjectured in . The factor cancels before the limit is taken — this is exactly what makes the limit computable at all, since the difference quotient itself is not defined for (denominator ).   "
},
{
  "id": "thm-differenzierbar-impliziert-stetig",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-differenzierbar-impliziert-stetig",
  "type": "Theorem",
  "number": "3.2.6",
  "title": "Differentiability implies continuity.",
  "body": " Differentiability implies continuity   If is differentiable at the point , then is also continuous at the point .   "
},
{
  "id": "ex-relu-nicht-differenzierbar",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-relu-nicht-differenzierbar",
  "type": "Example",
  "number": "3.2.7",
  "title": "The ReLU function is continuous but not differentiable everywhere.",
  "body": " The ReLU function is continuous but not differentiable everywhere   In , we showed that the ReLU function is continuous at the point . Determine whether it is also differentiable there.    We look at the difference quotient for separately from the left and from the right. For , we have , so For , we have , so So the right-hand limit of the difference quotient is , and the left-hand limit is — they do not agree, and the limit does not exist. So is not differentiable at the point , although it is continuous there: the kink in the graph is continuous but not smooth. (In machine learning practice, this point is usually simply assigned a value when differentiating, often or — a so-called subgradient .)   "
},
{
  "id": "sub-tangente-lineare-approximation-2",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-tangente-lineare-approximation-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "derivative function "
},
{
  "id": "sub-tangente-lineare-approximation-3",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-tangente-lineare-approximation-3",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "linear approximation "
},
{
  "id": "thm-tangente-lineare-approximation",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-tangente-lineare-approximation",
  "type": "Theorem",
  "number": "3.2.8",
  "title": "The tangent as a linear approximation.",
  "body": " The tangent as a linear approximation   Let be differentiable at the point . The tangent to at the point is the line with the equation In a precise sense, it approximates better than any other line through : that is, the difference goes to faster than .   "
},
{
  "id": "ex-wurzel-naeherung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-wurzel-naeherung",
  "type": "Example",
  "number": "3.2.9",
  "title": "Computational example: Approximating a root by hand.",
  "body": " Computational example: Approximating a root by hand   The derivative of is . Use the approximation formula to compute approximately — using only and the value , which you can compute in your head.    We choose , since we know (because ), and is close to . With , the approximation formula gives The exact value is — the linear approximation already gets it right to three decimal places.   "
},
{
  "id": "ex-anwendung-kondensator-entladung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-kondensator-entladung",
  "type": "Example",
  "number": "3.2.10",
  "title": "Application: Instantaneous rate of change when a capacitor discharges.",
  "body": " Application: Instantaneous rate of change when a capacitor discharges   A camera flash stores charge in a capacitor, and this charge is released when the flash fires. The charge (in microcoulombs) remaining on the capacitor at time (in seconds) after firing approximately follows . Determine the instantaneous rate of change of at time by approximating it with the difference quotient for , and interpret the sign.    We have and , so The instantaneous rate of change is negative — at time , the charge decreases by about microcoulombs per second. In general, is the discharge current (up to the sign): the derivative of a stock variable with respect to time is its instantaneous rate of change, here a physical current. With the differentiation rules from the next subsection, you can determine the exact value ( ).   "
},
{
  "id": "thm-ableitungsregeln",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-ableitungsregeln",
  "type": "Theorem",
  "number": "3.2.11",
  "title": "Differentiation rules.",
  "body": " Differentiation rules   Let be differentiable at the point , and let . Then , , and (if ) are also differentiable at the point , with    ( linearity ) and ,  ( product rule ) ,  ( reciprocal rule ) (if ),  ( quotient rule ) .    If, in addition, is differentiable at the point and at the point , then is also differentiable at the point , with    ( chain rule ) .    If is strictly monotonic and differentiable on an interval with , then the inverse function is also differentiable at the point , with    ( inverse function rule ) .     "
},
{
  "id": "ex-herleitung-produktregel",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-herleitung-produktregel",
  "type": "Example",
  "number": "3.2.12",
  "title": "Deriving the product rule (optional).",
  "body": " Deriving the product rule (optional)   Derive the product rule using the difference quotient.    For the difference quotient of at the point , we cleverly insert a zero, namely , and rearrange: As , the first fraction tends to , the factor to (continuity of , ), and the second fraction to . Altogether,    "
},
{
  "id": "ex-ableitung-xn-produktregel",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-xn-produktregel",
  "type": "Example",
  "number": "3.2.13",
  "title": "Derivative of <span class=\"process-math\">\\(x^n\\)<\/span> with the product rule.",
  "body": " Derivative of with the product rule   Use the product rule to determine the derivative of for , .    We write . If the formula is already known for the exponent , that is, , then the product rule gives So the formula carries over from each exponent to the next. Since it holds for ( ), it holds step by step for , that is, for all (and, as one can show separately, more generally for with any real exponent ).   "
},
{
  "id": "ex-ableitung-exp-sin-herleitung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-exp-sin-herleitung",
  "type": "Example",
  "number": "3.2.14",
  "title": "Where the derivatives of <span class=\"process-math\">\\(\\euler^x\\)<\/span> and <span class=\"process-math\">\\(\\sin(x)\\)<\/span> come from.",
  "body": " Where the derivatives of and come from   Derive and from the definition of the derivative. Use the fact that has slope at the point ( ), the addition formula for the sine, and the limit ( ).     Exponential function: With the law of exponents , we have because is exactly the difference quotient at the point , and the slope there is equal to by the definition of . So the exponential function is its own derivative — the property that makes the natural base.   Sine: With the addition formula , we get The second fraction goes to . For the first one, we multiply the numerator and denominator by and use : Altogether, the difference quotient goes to . In a very similar way, follows. If we had computed in degrees, would go to instead of , and this factor would appear in every derivative — one more reason to use radians.   "
},
{
  "id": "ex-ableitung-tangens-quotientenregel",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-tangens-quotientenregel",
  "type": "Example",
  "number": "3.2.15",
  "title": "Derivative of the tangent function with the quotient rule.",
  "body": " Derivative of the tangent function with the quotient rule   Use the quotient rule to determine the derivative of .    With and : where we used . Since , we obtain, equivalently, .   "
},
{
  "id": "ex-ableitung-kettenregel-exp-sin",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-kettenregel-exp-sin",
  "type": "Example",
  "number": "3.2.16",
  "title": "A derivative with the chain rule.",
  "body": " A derivative with the chain rule   Use the chain rule to determine the derivative of .    We write with the outer function and the inner function . We have and , so    "
},
{
  "id": "ex-ableitung-regeln-kombiniert",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-regeln-kombiniert",
  "type": "Example",
  "number": "3.2.17",
  "title": "Several rules in one computation.",
  "body": " Several rules in one computation   Differentiate and .     is a product whose second factor is a composition. We use the product rule, and inside it the chain rule, where the derivative of the inner function is : Factoring out pays off: in this form, you can read off the zeros and of the derivative directly — exactly what you need in when you look for extrema.   is a composition with the outer function and the inner function :    "
},
{
  "id": "ex-anwendung-entladestrom-exakt",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-entladestrom-exakt",
  "type": "Example",
  "number": "3.2.18",
  "title": "Application: The exact discharge current.",
  "body": " Application: The exact discharge current   For the capacitor charge from , determine the derivative and the exact value .    Chain rule, where the derivative of the inner function is : The difference quotient with had given — a usable approximation, but off by almost . In addition, you can now see: . The rate at which the charge decreases is, at every moment, proportional to the charge still present. This observation is the starting point of the differential equations in .   "
},
{
  "id": "ex-ableitung-ln-umkehrregel",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-ln-umkehrregel",
  "type": "Example",
  "number": "3.2.19",
  "title": "Derivative of the natural logarithm with the inverse function rule.",
  "body": " Derivative of the natural logarithm with the inverse function rule   Use the inverse function rule to determine the derivative of , the inverse function of .    With and , the inverse function rule gives    "
},
{
  "id": "tab-ableitungen-elementarer-funktionen",
  "level": "2",
  "url": "sec-differenzialrechnung.html#tab-ableitungen-elementarer-funktionen",
  "type": "Table",
  "number": "3.2.20",
  "title": "Derivatives of elementary functions",
  "body": " Derivatives of elementary functions    Function  Derivative   (constant)  ,   ,           "
},
{
  "id": "ex-anwendung-70er-regel-tangente",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-70er-regel-tangente",
  "type": "Example",
  "number": "3.2.21",
  "title": "Application: Why the rule of 70 works.",
  "body": " Application: Why the rule of 70 works   In , we computed the doubling time of a balance. Practitioners use the rule of thumb doubling time divided by the interest rate in percent. Set up the tangent to at the point , and use it to justify the rule of thumb via the approximation . How accurate is it for and for ?    With and , the tangent is Setting , you get for small — exactly the approximation we are looking for. So the doubling time is approximately , and with in percent approximately . The is not only easier to divide by, it is even more accurate: since ( ), the exact doubling time is somewhat longer than (with in percent: ) — at , it is years instead of , and the rule of 70 gives . For , we have , so the approximation is accurate to within . For , we have compared with — already off. The tangent is a good approximation only near .   "
},
{
  "id": "ex-anwendung-sigmoid-ableitung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-sigmoid-ableitung",
  "type": "Example",
  "number": "3.2.22",
  "title": "Application: The derivative of the sigmoid function.",
  "body": " Application: The derivative of the sigmoid function   For the sigmoid function from , the derivative is needed again and again when neural networks are trained. Show that .    We write and apply the chain rule and the reciprocal rule (or directly the reciprocal rule with , ): To express this in terms of itself, we write the numerator as : This form is valuable in practice: if has already been computed (for example, in the forward pass of a neural network), you can determine without evaluating the exponential function again.  The formula also reveals how small this derivative is: the product is at most for (at , that is, ), and for large , goes to or , and hence . So the saturation from means vanishing gradients : in deep networks, where many such factors are multiplied, hardly any signal arrives during learning — one of the reasons why the ReLU function is usually preferred today; its derivative is equal to everywhere to the right of .   "
},
{
  "id": "ex-anwendung-grenzkosten",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-grenzkosten",
  "type": "Example",
  "number": "3.2.23",
  "title": "Application: Marginal cost.",
  "body": " Application: Marginal cost   A company has the cost function (total cost in euros when units are produced). The marginal cost  indicates approximately by how much the total cost rises when one additional unit is produced. Determine the marginal cost at a production quantity of units.    With the power rule, term by term: Substituting : So the st unit costs approximately € extra — much less than the average cost per unit at this point ( euros), a typical picture of economies of scale at a medium production quantity.   "
},
{
  "id": "ex-anwendung-elastizitaet",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-elastizitaet",
  "type": "Example",
  "number": "3.2.24",
  "title": "Application: Price elasticity of demand.",
  "body": " Application: Price elasticity of demand   The price elasticity of demand measures how strongly the quantity demanded reacts, in relative terms, to a relative change in price: For the demand function (quantity demanded as a function of the price in euros), determine and interpret the result.    We have (constant) and , so The absolute value means elastic demand at : a price increase of makes the quantity demanded fall by about — the quantity reacts more than proportionally to price changes. For the revenue , this means that a price increase lowers it and a slight price cut raises it. Check: , but .   "
},
{
  "id": "sub-anwendungen-differenzialrechnung-2-1",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-anwendungen-differenzialrechnung-2-1",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "curve sketching "
},
{
  "id": "thm-monotonie-ableitung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-monotonie-ableitung",
  "type": "Theorem",
  "number": "3.2.25",
  "title": "First derivative and monotonicity.",
  "body": " First derivative and monotonicity   Let be a function that is differentiable on an interval . Then:    for all   is strictly increasing on ,  for all   is monotonically increasing on ,  for all   is constant on ,  for all   is monotonically decreasing on ,  for all   is strictly decreasing on .     "
},
{
  "id": "sub-monotonie-extremstellen-3",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-monotonie-extremstellen-3",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "mean value theorem "
},
{
  "id": "def-lokales-extremum",
  "level": "2",
  "url": "sec-differenzialrechnung.html#def-lokales-extremum",
  "type": "Definition",
  "number": "3.2.26",
  "title": "Local extremum.",
  "body": " Local extremum   Let , . has a local maximum (or local minimum ) at if there is an such that (or , respectively) for all with . In this case, the point is called an extremum of .   "
},
{
  "id": "thm-notwendiges-extremalkriterium",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-notwendiges-extremalkriterium",
  "type": "Theorem",
  "number": "3.2.27",
  "title": "Necessary condition for an extremum.",
  "body": " Necessary condition for an extremum   Let have an extremum at the point . If lies in an open interval and is differentiable at the point , then A point with is called a critical point of .   "
},
{
  "id": "thm-erstes-hinreichendes-kriterium",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-erstes-hinreichendes-kriterium",
  "type": "Theorem",
  "number": "3.2.28",
  "title": "First derivative test for extrema.",
  "body": " First derivative test for extrema   Let be a critical point of , that is, .    If changes sign from to at , then has a local maximum at .  If changes sign from to at , then has a local minimum at .     "
},
{
  "id": "thm-zweites-hinreichendes-kriterium",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-zweites-hinreichendes-kriterium",
  "type": "Theorem",
  "number": "3.2.29",
  "title": "Second derivative test for extrema.",
  "body": " Second derivative test for extrema   Let be twice differentiable, and let be a critical point of .    If , then has a local maximum at .  If , then has a local minimum at .  If , this test gives no conclusion — you have to fall back on the first test (or on higher derivatives).     "
},
{
  "id": "ex-anwendung-gewinnfunktion-kurvendiskussion",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-gewinnfunktion-kurvendiskussion",
  "type": "Example",
  "number": "3.2.30",
  "title": "Application: Monotonicity and extrema of a profit function.",
  "body": " Application: Monotonicity and extrema of a profit function   A company models its profit (in thousands of euros) as a function of the production quantity (in thousands of units) by Determine the critical points of , determine where the function is increasing and where it is decreasing, and classify the critical points with the second derivative test.    Derivative: . Critical points: and .  Sign of : for , and are both negative, so their product is positive; with the factor , — decreases. For , we have and , so the product is negative and — increases. For , both factors are positive, so — decreases again.  Second derivative: . We have , so there is a local minimum at with ; and , so there is a local maximum at with .  Economically: at a small production quantity, the fixed costs dominate, and the profit first falls, down to a loss of € at units produced; after that, additional production pays off, up to a maximum profit of € at units, beyond which the costs again grow faster than the revenue.   "
},
{
  "id": "def-konvex-konkav",
  "level": "2",
  "url": "sec-differenzialrechnung.html#def-konvex-konkav",
  "type": "Definition",
  "number": "3.2.31",
  "title": "Convex and concave functions.",
  "body": " Convex and concave functions   Let be a function defined on an interval . is called convex (concave up) if its graph lies below every line segment connecting two of its points, that is, for all , :  is called concave (concave down) if is convex.   "
},
{
  "id": "thm-konvexitaet-zweite-ableitung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-konvexitaet-zweite-ableitung",
  "type": "Theorem",
  "number": "3.2.32",
  "title": "Convexity and the second derivative.",
  "body": " Convexity and the second derivative   Let be twice differentiable. Then:    for all   is convex on ,  for all   is concave on .    If is convex on , then a local minimum of in is also the global minimum of on — a property that makes optimization methods such as gradient descent ( ) particularly reliable for convex functions.   "
},
{
  "id": "def-wendepunkt",
  "level": "2",
  "url": "sec-differenzialrechnung.html#def-wendepunkt",
  "type": "Definition",
  "number": "3.2.33",
  "title": "Inflection point.",
  "body": " Inflection point   Let be twice differentiable. A point is called an inflection point if the curvature of changes from convex to concave (or vice versa) at . For to be an inflection point, is a necessary condition — a sign change of at is sufficient.   "
},
{
  "id": "ex-anwendung-gewinnfunktion-konvexitaet",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-gewinnfunktion-konvexitaet",
  "type": "Example",
  "number": "3.2.34",
  "title": "Application: Curvature and inflection point of the profit function.",
  "body": " Application: Curvature and inflection point of the profit function   Check the profit function from for convexity, concavity and inflection points.    From , it follows that . So is convex on and concave on ; at , changes sign (from to ), so there is an inflection point there, with .  The inflection point lies exactly between the two critical points and from . This is not a coincidence: between a local minimum and a local maximum of a twice differentiable function, there is always at least one inflection point (there the slope changes from increasing to decreasing, so changes sign). That it even lies exactly in the middle here is a special feature of polynomials of degree three: is a parabola with the zeros and , and its vertex, the zero of , lies symmetrically between them.   "
},
{
  "id": "ex-anwendung-optimale-dose",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-optimale-dose",
  "type": "Example",
  "number": "3.2.35",
  "title": "Application: An optimization problem with a constraint — the optimal can.",
  "body": " Application: An optimization problem with a constraint — the optimal can   A cylindrical can with radius and height is to hold a volume of liter ( ). Determine and such that the amount of material — the surface area of the can — is minimal.    The surface consists of the lid, the bottom and the side wall: . The constraint gives . Substituting turns into a function of one variable:   Necessary condition: , so Since for all , is convex on , so the critical point is a (global) minimum.  The corresponding height is With , that is, , this simplifies to . So the can that uses the least material for a given volume always has a height equal to its diameter, — regardless of the specific volume.   "
},
{
  "id": "sub-newton-verfahren-2",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-newton-verfahren-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Newton's method "
},
{
  "id": "def-newton-verfahren",
  "level": "2",
  "url": "sec-differenzialrechnung.html#def-newton-verfahren",
  "type": "Definition",
  "number": "3.2.36",
  "title": "Newton’s method.",
  "body": " Newton's method   Let be twice continuously differentiable on with on . Beginning with a starting value  , one computes the approximations  iteratively. Under suitable assumptions, the sequence converges to a zero of in .   "
},
{
  "id": "ex-newton-wurzel-2",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-newton-wurzel-2",
  "type": "Example",
  "number": "3.2.37",
  "title": "Computational example: Two steps of Newton’s method by hand.",
  "body": " Computational example: Two steps of Newton's method by hand   Approximate with two steps of Newton's method, applied to with starting value .    We have . First step:   Second step, with : and , so The exact value is — after only two steps, five decimal places already agree. This very fast (quadratic) convergence is typical of Newton's method as soon as the starting value is close enough to the zero we are looking for.  In , we claimed that Heron's method is a special case of Newton's method. Now we can verify this: for , Newton's iteration reads — exactly Heron's iteration. So about two thousand years ago, without knowing anything about derivatives, Heron of Alexandria already used Newton's method for square roots.   "
},
{
  "id": "ex-newton-zyklus",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-newton-zyklus",
  "type": "Example",
  "number": "3.2.38",
  "title": "When Newton’s method goes in circles (optional).",
  "body": " When Newton's method goes in circles (optional)   Apply Newton's method to with starting value . What do you observe?    We have . Hence The method jumps back and forth between and forever and never finds the zero. Yet does have one: since and , there is a zero in by Bolzano's theorem (it is approximately ). With a starting value near it, for example , the method converges without any problems. (Between and , on the other hand, there is no zero at all, and vanishes there at — the assumptions of are not satisfied on this interval.) In practice, one therefore often combines the two: first get close to the zero with the slow but safe bisection method ( ), then use Newton's method for the last digits.   "
},
{
  "id": "ex-anwendung-gradientenabstieg",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-gradientenabstieg",
  "type": "Example",
  "number": "3.2.39",
  "title": "Application: Gradient descent by hand.",
  "body": " Application: Gradient descent by hand    Gradient descent is the workhorse of machine learning. To find the minimum of a loss function — that is, a critical point with — you start at and repeatedly take a step against the slope: For with starting value and learning rate , carry out two steps. What happens instead for and for ?    We have , and the minimum is at (because and ). With : The sequence approaches , and the distance is halved in each step: , so for , the factor is — exactly the geometric sequence from .  For , the factor is : already hits the minimum exactly. For , the factor is : , , … — the iteration jumps around the minimum with a growing amplitude and diverges. So the learning rate must match the curvature : Newton's method, applied to , automatically chooses (here ) and therefore lands on the minimum in one step. It is a second-order method , but it needs to know the second derivative, which is too expensive with millions of parameters. That is why, in practice, one settles for gradient descent and a carefully chosen learning rate.   "
},
{
  "id": "sub-mittelwertsatz-2-1",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-mittelwertsatz-2-1",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "mean value theorem L'Hôpital's rule "
},
{
  "id": "thm-mittelwertsatz",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-mittelwertsatz",
  "type": "Theorem",
  "number": "3.2.40",
  "title": "Mean value theorem.",
  "body": " Mean value theorem   Let be continuous on and differentiable on . Then there exists a with    "
},
{
  "id": "fig-mittelwertsatz",
  "level": "2",
  "url": "sec-differenzialrechnung.html#fig-mittelwertsatz",
  "type": "Figure",
  "number": "3.2.41",
  "title": "",
  "body": " Mean value theorem: the tangent to at the point is parallel to the secant through and .    A coordinate system with a curved graph between the points a and b. A dashed secant connects the points of the curve above a and b. At an interior point c, the tangent to the curve is drawn, parallel to the secant.     "
},
{
  "id": "ex-anwendung-abschnittskontrolle",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-abschnittskontrolle",
  "type": "Example",
  "number": "3.2.42",
  "title": "Application: Average speed check (optional).",
  "body": " Application: Average speed check (optional)   In an average speed check , a vehicle is recorded at two checkpoints  km apart; the speed limit is  km\/h. A vehicle takes minutes to cover this distance. The driver insists that the speedometer never showed more than  km\/h. What does the mean value theorem say about this?    Let be the distance covered (in km) after hours. With minutes  h, the average speed is The distance–time function of a car is differentiable (the car has a speed at every moment, and its position does not jump), and its derivative is the instantaneous speed. So by the mean value theorem, there is a time with  km\/h. The driver's statement cannot be true — even though no instantaneous speed was measured anywhere.   "
},
{
  "id": "rem-monotoniekriterium-beweis",
  "level": "2",
  "url": "sec-differenzialrechnung.html#rem-monotoniekriterium-beweis",
  "type": "Remark",
  "number": "3.2.43",
  "title": "Justification of the monotonicity test.",
  "body": " Justification of the monotonicity test  The mean value theorem justifies the monotonicity test from : if on all of , and are arbitrary points of , then the mean value theorem on gives a with Since and , it follows that , that is, : is strictly increasing. The other cases of the test follow in the same way.  "
},
{
  "id": "ex-mittelwertsatz-logarithmus-ungleichung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-mittelwertsatz-logarithmus-ungleichung",
  "type": "Example",
  "number": "3.2.44",
  "title": "An inequality for the logarithm.",
  "body": " An inequality for the logarithm   Use the mean value theorem to show that for all .    Let be fixed, and let on ; is continuous there and differentiable on with . The mean value theorem gives a with Since , we have , so (because ). Hence for all .   "
},
{
  "id": "thm-regel-hospital",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-regel-hospital",
  "type": "Theorem",
  "number": "3.2.45",
  "title": "L’Hôpital’s rule.",
  "body": " L'Hôpital's rule   Let be differentiable on an interval around (possibly except at itself), let near , and suppose that one of the following two cases holds: If the limit exists, then    "
},
{
  "id": "ex-hospital-e-hoch-x",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-hospital-e-hoch-x",
  "type": "Example",
  "number": "3.2.46",
  "title": "Computational example: Applying L’Hôpital’s rule twice.",
  "body": " Computational example: Applying L'Hôpital's rule twice   Determine .    As , both the numerator ( ) and the denominator ( ) go to : indeterminate form . Differentiating the numerator and the denominator: Here, too, the numerator and the denominator both go to again as — so we apply the rule again: So .   "
},
{
  "id": "ex-hospital-log-wurzel",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-hospital-log-wurzel",
  "type": "Example",
  "number": "3.2.47",
  "title": "Application: Comparing growth — logarithm versus square root function.",
  "body": " Application: Comparing growth — logarithm versus square root function   Determine .    As , the numerator and the denominator both go to : indeterminate form . With and :   This result is a special case of a general hierarchy of growth rates that is used all the time in the analysis of algorithms (big O notation): as , grows more slowly than any positive power ( ), and every power function in turn grows more slowly than — in short, . L'Hôpital's rule is the standard tool for proving such growth comparisons exactly.   "
},
{
  "id": "sub-zusammenfassung-3-2-2",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-zusammenfassung-3-2-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Derivative: Tangent and linear approximation: Differentiation rules: Curve sketching: Optimization problem: Iterative methods: Mean value theorem: L'Hôpital: Applications: "
},
{
  "id": "exercise-buch-ableitung-kehrwert-differenzenquotient",
  "level": "2",
  "url": "sec-differenzialrechnung.html#exercise-buch-ableitung-kehrwert-differenzenquotient",
  "type": "Exercise",
  "number": "3.2.6.1",
  "title": "",
  "body": "  Determine the derivative of (for ) directly from the difference quotient — without using any differentiation rules.        "
},
{
  "id": "exercise-buch-kettenregel-logarithmus",
  "level": "2",
  "url": "sec-differenzialrechnung.html#exercise-buch-kettenregel-logarithmus",
  "type": "Exercise",
  "number": "3.2.6.2",
  "title": "",
  "body": "  Use the chain rule to determine the derivative of .    With the outer function and the inner function :    "
},
{
  "id": "exercise-buch-tangente-kubisch",
  "level": "2",
  "url": "sec-differenzialrechnung.html#exercise-buch-tangente-kubisch",
  "type": "Exercise",
  "number": "3.2.6.3",
  "title": "",
  "body": "  Determine the equation of the tangent to at the point .    We have and , so . With the tangent formula :    "
},
{
  "id": "exercise-buch-extremstellen-kubisch",
  "level": "2",
  "url": "sec-differenzialrechnung.html#exercise-buch-extremstellen-kubisch",
  "type": "Exercise",
  "number": "3.2.6.4",
  "title": "",
  "body": "  Determine all local extrema of and classify them with the second derivative test.     ; the critical points are and . With : , so there is a local minimum at with ; and , so there is a local maximum at with .   "
},
{
  "id": "exercise-buch-hospital-quadrat-logarithmus",
  "level": "2",
  "url": "sec-differenzialrechnung.html#exercise-buch-hospital-quadrat-logarithmus",
  "type": "Exercise",
  "number": "3.2.6.5",
  "title": "",
  "body": "  Use L'Hôpital's rule to determine .    As , the numerator and the denominator both go to (indeterminate form ). Differentiating the numerator and the denominator:    "
},
{
  "id": "sec-riemannsches-integral",
  "level": "1",
  "url": "sec-riemannsches-integral.html",
  "type": "Section",
  "number": "4.1",
  "title": "The Riemann integral: Foundations",
  "body": " The Riemann integral: Foundations    After this section, you can    explain the definite integral as a limit of Riemann sums and interpret it as a signed area;  compute definite integrals with the fundamental theorem of calculus via an antiderivative;  differentiate accumulation functions, including when the upper limit is a function of ;  find antiderivatives with the table of basic integrals and the rule for linear arguments, and determine the constant of integration from a known function value;  compute improper integrals over unbounded regions or with an unbounded integrand as limits;  express consumer surplus, average values, probability densities and present values as integrals and compute them.     What is the probability that a component lasts longer than a thousand hours? How much is a stream of payments worth today if it continues to flow without end? How much do buyers gain from a market price that is below their willingness to pay? All three questions are questions about areas : we are looking for the area between the graph of a function and the -axis. This section defines this area as an integral — first honestly but laboriously, as a limit of sums of rectangles, then conveniently via the fundamental theorem. The fundamental theorem connects the integral with the derivative from the previous chapter and reduces the computation to finding an antiderivative . Finally, we extend the notion of the integral to unbounded regions, such as those that occur with probability densities and present values.  Along the way, you will learn what Archimedes already knew about areas more than two thousand years ago, why the integral sign looks like an elongated S, that the bell curve of statistics, of all functions, has no antiderivative that you can write down, and how to prove with an innocent-looking computation that a positive function has a negative integral.    From the area problem to the Riemann sum   In , we asked how to get the instantaneous speed from the distance traveled. Now we ask the opposite question: a tachograph has recorded the speed over time — how far has the vehicle traveled? At constant speed, this is simply speed times time, that is, the area of a rectangle in the speed–time diagram. If the speed changes, the distance is the area under the curve.  This brings us to the second basic problem of calculus, the area problem : how large is the area between the graph of a function and the -axis? The idea for the answer is as simple as the tachograph computation: cut the region into narrow strips, treat each strip as a rectangle, add them up. The result — the Riemann integral — is closely related to the derivative, as the fundamental theorem in will show.    The area problem  Let be continuous (see ). We are looking for the area between the graph of and the -axis on , called the integral  where are called the limits of integration and the integrand .   The area we are looking for, between the graph of and the -axis on .    A coordinate system with an upward-opening parabola . The region between the piece of the curve from to and the -axis is shaded.      One of the oldest motivations for the area problem comes from economics: consider a market with a supply function and a demand function , each of which gives the price as a function of the quantity traded.   Supply and demand curves with the market equilibrium .    A coordinate system with the quantity on the horizontal axis and the price on the vertical axis. An increasing line (supply) and a decreasing line (demand) intersect at a point whose coordinates and are marked by dashed auxiliary lines.      If the market settles at the equilibrium price with the quantity , then buyers who would also have bought at a higher price gain, and so do sellers who would also have sold at a lower price. These gains are called consumer surplus and producer surplus . Both are areas between the supply or demand curve and the line — so they are exactly of the type of the area problem. As soon as we can compute integrals, we will come back to this example in .    Riemann sums and the definition of the integral  The idea of filling a region with a curved boundary using finer and finer pieces that have straight edges is more than two thousand years old. Around 250 BC, Archimedes of Syracuse determined the area of a parabolic segment in this way — it is exactly of the area of the inscribed triangle. He filled the region with more and more, smaller and smaller triangles. At its core lies the geometric series from . The method was made precise only in the 19th century — by Bernhard Riemann in 1854, building on earlier work by Augustin-Louis Cauchy; hence the name.  The basic idea for computing the area: we divide into subintervals of equal length , choose a point in each subinterval (for example, the midpoint or the right endpoint), and approximate the area we are looking for by the sum of the areas of the rectangles .   Approximating the area under by five rectangles (Riemann sum with midpoints).    The same upward-opening parabola as in , this time covered by five rectangles of equal width. The height of each rectangle is the function value at the midpoint of its subinterval.       Riemann sum   Let be continuous, let be divided into subintervals of equal length , and let be a point in the th subinterval ( ). Then is called a Riemann sum of for the given partition.     Application: Energy consumption from measured data (optional)   The electrical power of a server room is measured over four hours, once in the middle of each hour: , , and  kW. Estimate the energy consumed in these four hours.    Energy is power times time — so if the power varies, it is the area under the power curve . With the partition into four hours (  h) and the measured values at the midpoints, we get the Riemann sum Monitoring tools, for example, work this way: measured values taken at fixed time intervals are multiplied by the step size and added up. The shorter the interval between measurements, the more accurate the estimate — the following definition makes this passage to the limit precise.     Riemann integral   Let be continuous. For finer and finer partitions ( ), the sequence of Riemann sums converges to a limit that does not depend on the specific choice of the partition and of the points . This limit is called the definite integral of on :     This formula shows where the notation comes from. Leibniz, who introduced it around 1675, thought of a sum of infinitely many, infinitely narrow rectangles and wrote an elongated S for it (for the Latin summa ): the integral sign , a kind of continuous relative of the summation sign . The finite width becomes the infinitely small  . So feel free to read as the sum of height times width, from to . This reading helps with every application, whether energy, distance or probability.   The integral of a constant function (optional)   Determine .    For the constant function , every Riemann sum, whatever the partition, is already exactly the area we are looking for: a rectangle of width and height . So, even without passing to the limit, we have      The integral of a linear function (optional)   Determine .    The region between the line and the -axis on is a right triangle with base and height , so Here, too, you can read off the result directly from the geometry, without computing the limit of the Riemann sums explicitly.     Computational example: Convergence of the Riemann sums of   Consider and the Riemann sums (with midpoints) for with finer and finer subdivisions. The following table shows the values for subintervals. Verify the value for by hand.    For , we have ; the subintervals are and with the midpoints and : The other values in the table arise in the same way, only with more terms — a job for the computer.   Riemann sums of on    Subintervals  Step size  Riemann sum            The Riemann sums clearly approach the value . In the next section, we will confirm with the fundamental theorem of calculus that indeed — without ever having to add up a Riemann sum by hand again.      Properties and sign convention  Some basic properties of the integral follow directly from the definition via Riemann sums. Let be continuous:    Pieces of area above the -axis make a positive contribution to the integral, pieces below the -axis a negative contribution — because there , so every term of the Riemann sum is negative.  Integrals over a single point are zero: (the interval has length ).  Swapping the limits of integration changes the sign: .     The sign of the integral of a negative function (optional)   Compare (see ) with .    The function is negative everywhere on ; its graph runs below the -axis. Every term of every Riemann sum of is times the corresponding term for . So already holds for every single Riemann sum, and hence also in the limit The integral is negative — this is not a mistake but exactly the sign convention: the integral measures the signed area, in which areas below the axis count as negative.     The integral of the sine function over a full period   Determine without computing an antiderivative.    The graph of is symmetric about its point at : on , it is positive; on , it is negative as an exact mirror image, with an area of the same size. So the positive and negative contributions to the Riemann sum cancel completely, and Note: this does not mean that there is no area between the graph of and the -axis on — the actual (unsigned) area is positive. The integral simply measures the signed area.       The fundamental theorem of calculus   Adding up Riemann sums by hand, as in , is tedious and only gives an approximation anyway. The following theorem — the most important tool of this chapter — connects the integral with the derivative, which you know from , and makes the exact computation of integrals practical.  That areas and slopes are related is by no means obvious. Isaac Newton and Gottfried Wilhelm Leibniz discovered it independently of each other in the 17th century, and this was the beginning of modern calculus. But the idea can be explained intuitively, and we do so right after the theorem.    Statement and intuition   Fundamental theorem of calculus   Let be continuous.    The function with is an antiderivative of , that is, .  If is any antiderivative of , that is, , then     Since the expression occurs so often, it is written for short as .    Why is the derivative of the area function exactly ? If you move the upper limit from to , a narrow strip is added. For small , it is almost a rectangle of width and height , so On the left is the difference quotient of ; for , the approximation becomes an equation: . So at every point, the area grows exactly at the rate .  In this way, the fundamental theorem solves both basic problems of calculus with one tool: if you know an antiderivative of , you can compute every definite integral of without taking the limit of a Riemann sum.  You can also read the second part of the theorem as a net change principle . If is any quantity and is its rate of change, the second part reads if you add up all the small changes between and , you get the total change. You know this from your bank account: the sum of all deposits and withdrawals in a month is the balance at the end of the month minus the balance at the beginning. In the same way, the accumulated speed gives the distance traveled, the accumulated inflow rate gives the amount of water in the reservoir, and the accumulated marginal cost gives the additional cost.   Computational example: Checking the limit of the Riemann sums   Determine with the fundamental theorem, and compare with .    An antiderivative of is (because ). Hence This is exactly the value that the Riemann sums in approached more and more closely — the fundamental theorem gives it exactly and without taking a limit.     The integral of a sum of an exponential function and a quadratic function (optional)   Determine .    An antiderivative is . Hence      Application: From the speedometer to the distance (optional)   A vehicle accelerates from rest; its speed is (in m\/s, in seconds, ). What distance does it travel in the first seconds?    The distance is the area under the speed curve. An antiderivative of is , so Here, the antiderivative has an intuitive meaning: is the distance traveled up to time , and its derivative is — as on the speedometer — the speed.      Accumulation functions and the chain rule  The first part of the fundamental theorem is a statement about the accumulation function  , whose upper limit of integration is itself the variable. If the upper limit is not itself but a function of , you also have to apply the chain rule when you differentiate.   The derivative of an accumulation function (without the chain rule) (optional)   Let . Determine .    By the fundamental theorem, is an antiderivative of the integrand, so immediately without having to compute itself explicitly at all.     Computational example: The derivative of an accumulation function with the chain rule   Let . Determine .    The upper limit is , so it is not just the variable. We write with . By the fundamental theorem, , and with the chain rule        The indefinite integral and basic integrals   The fundamental theorem makes antiderivatives the central tool of integral calculus: if you want to compute a definite integral, you have to find a function whose derivative is the integrand. So integration is differentiation in reverse. That sounds simple, but it is harder than differentiation: for differentiation, there is a rule for every way of combining functions; for integration, there is not. We begin with the basic integrals, which you read off directly from the table of derivatives; further techniques follow in .    Antiderivatives and basic integrals   Indefinite integral   An antiderivative of a function is also called an indefinite integral of . We write      Caution: antiderivatives are not unique. If is an antiderivative of , then is also an antiderivative of for every constant — after all, an additive constant does not change the derivative. Therefore, we usually write and call the constant of integration . For a definite integral, the choice of does not matter, because cancels anyway in .   Basic integrals    Function  Antiderivative              Why does the second row say and not simply ? Because is also defined for negative , but is not. For , we have (chain rule), and combines both cases. If you leave out the absolute value, integrals such as give you logarithms of negative numbers — and hence nonsense.  The fastest way to read this table is backward : since , is an antiderivative of . So every row is a row of the table of derivatives from , read from right to left. (Only the last entry, the antiderivative of , cannot be read off in this way; we derive it in .) Together with the sum rule (the antiderivative of a sum is the sum of the antiderivatives) and the rule for constants , the table already lets you find many indefinite integrals.  A useful extension of the table concerns a linear argument : if is one of the functions from the table with antiderivative , and if , then is an antiderivative of . This follows directly from the chain rule, because . In particular, for : These two cases come up again and again in the rest of this chapter, for example with processes that decay over time or that are periodic.   Computational example: The antiderivative of a sum of power functions   Determine .    First, we write all terms as powers of : and . Integrating term by term with the power rule gives Altogether,      Computational example: An antiderivative with a logarithmic and an exponential term (optional)   Determine .    The constant term (Euler's number, a fixed real value) integrates like any constant to . Together with the other two basic integrals:      Computational example: The antiderivative of a combination of sine and cosine (optional)   Determine .          Computational example: Linear arguments — and where the rule ends   Determine , and . Can be handled in the same way?    In all three cases, the argument is linear, and we divide by the factor in front of : Check by differentiating, for example for the first one: . When you integrate, this check is always possible, and it is highly recommended.  For , the argument is not linear. The obvious attempt fails the check: by the quotient rule, the result is not . In fact, has no antiderivative at all that can be written down with elementary functions — a phenomenon that does not exist for differentiation. Such statements were proved by the French mathematician Joseph Liouville in the 19th century. Ironically, the same holds for , the bell curve of the normal distribution, which is probably the most important function in statistics: its integrals have to be computed numerically, as shown in . Differentiation is a craft, integration is sometimes an art — and sometimes impossible.      Application examples  Because antiderivatives are determined only up to a constant, in applications you need additional information to choose the right one — for example, a known function value. The constant then often has a very concrete meaning.   Application: The cost function from the marginal cost   The cost accounting department of a company knows the marginal cost (in euros per unit at a production quantity of units) and the fixed costs of € . Determine the cost function . By how much do the costs increase if production is increased from to units?    Integrating term by term gives all antiderivatives The fixed costs are the costs at , so , and This is exactly the cost function from — differentiation and integration undo each other, and the constant of integration turns out to be the fixed costs. For the increase in costs, you do not even need the constant: by the net change principle, it is      Application: Consumer surplus in market equilibrium   We return to the motivating example from . In a market, let the supply and demand functions be given by each giving the price as a function of the quantity . Determine the equilibrium quantity , the equilibrium price and the consumer surplus .    Setting supply equal to demand: The quadratic formula gives and ; the negative solution is ruled out as a quantity, so . The equilibrium price is (check: ✓).  The consumer surplus is the area between the demand curve and the line :      Application: The daily yield of a solar power system (optional)   On a sunny day, the power of a photovoltaic system between sunrise (6:00) and sunset (18:00) is modeled by ( in hours). How much energy does it deliver on this day?    Energy is the area under the power curve — the same idea as for the server room in , only now exact. The argument of the sine is linear in with factor , so is an antiderivative: Plausibility check: twelve hours at peak power would be  kWh; the sine curve fills the fraction of this. With just under  kWh, you could supply an average four-person household for about four days.     Application: The average temperature of a day   For a continuous function , the average value on an interval is defined as — you divide the area under by the length of the interval, just as you divide the sum of the values by their number for discrete data. On a summer day, let the temperature (in °C) approximately follow , where is the time in hours from 9:00 in the morning (the maximum is then at 15:00, the minimum at 3:00 at night). Determine the average temperature over the whole day.     The constant part gives . For the oscillating part, is an antiderivative. Since is exactly one full period of the function (period ), we have , and the term vanishes: Hence — the fluctuation around the mean contributes nothing to the daily average; the average temperature is exactly the constant part .       Improper integrals   The fundamental theorem requires to be continuous on a closed, finite interval . But in many applications — for example, when a process continues without a time limit, or when a density function becomes unbounded at a point — we want to integrate over unbounded regions or unbounded functions. Both cases are handled by passing to a limit.  Here you meet a familiar idea from in a new form: a region that extends infinitely far can still have a finite area — or not, and once again it depends on how fast the integrand goes to zero. And you will see why you have to look closely at integrands with poles before you apply the fundamental theorem.    Infinite limits of integration   Improper integral with infinite limits of integration   Let be continuous on the appropriate domain. If the following limits exist, we define If the limit in question exists, the integral is called convergent ; otherwise, it is called divergent .     Computational example: The improper integral of the exponential function   Determine .     Since for , the integral is convergent with the value So a region that extends infinitely far to the right has a finite area — the same phenomenon as for the geometric series in .     Computational example: versus   Determine whether and converge.    For , is an antiderivative: For , is an antiderivative: The first integral converges, the second diverges, although both integrands go to . Does this remind you of something? The series converges, the harmonic series diverges ( ). Here, the integral and the series behave in the same way — simply decreases too slowly.      Unbounded integrand   Improper integral with an unbounded integrand   Let , and let or , respectively, be continuous, but unbounded near the endpoint that is excluded. If the following limits exist, we define      Computational example: An improper integral with a singularity at an endpoint   Determine .    The integrand is not defined at the point and is unbounded there, so the integral is improper. So the integral is convergent with the value .    You cannot always recognize improper integrals by their notation. If the problematic point lies in the interior of the interval, you have to split the integral there — otherwise the fundamental theorem gives nonsense.   Caution, a pole: A negative integral of a positive function?   Someone computes What went wrong here, and what is correct?    The result cannot be right: the integrand is positive everywhere, so every Riemann sum is positive. The mistake is that is not defined and is unbounded at — in the middle of the interval. But the fundamental theorem requires a function that is continuous on the whole interval. The correct approach is to split the integral at into two improper integrals. The right one alone already diverges: So the integral is divergent; the area under the graph is infinite.    In general: if has a singularity at a point in the interior of , you split into two improper integrals. The integral converges only if both of these integrals converge. And before you substitute the limits into an antiderivative, it is always worth a quick check whether the integrand is continuous on the whole interval.    Application examples   Application: The density function of the exponential distribution   In data science, waiting times or lifetimes are often modeled with the exponential distribution . For a parameter , its density function is given by for . A fundamental property of every probability density is that the total area under its graph is equal to — the total probability. Show that .  The probability that the lifetime is at least is the area under the density to the right of . Suppose a component has an exponentially distributed lifetime with per hour. How likely is it that it lasts longer than hours?     Since , we have for , so as claimed. This property — the area under a density is always — is the reason why integrals are everywhere in probability theory and statistics.  For the lifetime, we compute in the same way, only from on: With a probability of about , the component lasts longer than hours. This answers the first question from the introduction to this section.     Application: The present value of a perpetuity   A payment flows continuously at a constant rate per unit of time and is discounted continuously at the interest rate ; so a payment that flows at time is worth today. Derive a general formula for the present value of such a payment that flows indefinitely , .     Since , we have for , so This simple formula — payment rate divided by interest rate — is the continuous version of the perpetuity : in , we obtained exactly the same result for annual payments and an annual interest rate via a geometric series. Here, the series and the integral are the discrete and the continuous version of the same computation.       Summary     Definite integral:  — the limit of the Riemann sums; geometrically, the signed area (negative below the axis). , . Reading: the sum of height times width.    Fundamental theorem: the accumulation function is an antiderivative of ( ); for every antiderivative, . Net change principle:  — the accumulated rate of change is the total change. If the upper limit is a function , the chain rule comes in: .   Indefinite integral  : all antiderivatives, unique up to the constant . Basic integrals = the table of derivatives read backward; linear argument: , for example ; . The constant is determined by a known function value (fixed costs ). Not every elementary function has an elementary antiderivative ( ).   Improper integrals:  ; for a singularity at the endpoint : . Convergent if the limit exists. For a singularity in the interior, split at this point — convergent only if both parts converge. Examples: , ; converges, does not. Be careful with poles in the interior: split there, otherwise the fundamental theorem gives nonsense.   Applications: consumer surplus ; average value ; density function with ; present value .      Exercises    Determine all antiderivatives of .           Compute .           Let . Determine .    By the fundamental theorem of calculus, is an antiderivative of the integrand, so immediately       Compute the area between the graph of and the -axis on the interval .    On , we have (with zeros exactly at the endpoints), so the graph lies on or below the -axis throughout. The area is therefore the absolute value of the integral: so the area is .      Determine whether converges, and if it does, compute its value.     The integral is convergent with the value .     "
},
{
  "id": "sec-riemannsches-integral-2",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sec-riemannsches-integral-2",
  "type": "Objectives",
  "number": "4.1",
  "title": "",
  "body": "  After this section, you can    explain the definite integral as a limit of Riemann sums and interpret it as a signed area;  compute definite integrals with the fundamental theorem of calculus via an antiderivative;  differentiate accumulation functions, including when the upper limit is a function of ;  find antiderivatives with the table of basic integrals and the rule for linear arguments, and determine the constant of integration from a known function value;  compute improper integrals over unbounded regions or with an unbounded integrand as limits;  express consumer surplus, average values, probability densities and present values as integrals and compute them.   "
},
{
  "id": "sub-riemannsumme-integralbegriff-2-2",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-riemannsumme-integralbegriff-2-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Riemann integral "
},
{
  "id": "sub-flaechenproblem-2",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-flaechenproblem-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "integral limits of integration integrand "
},
{
  "id": "fig-flaeche-unter-graph",
  "level": "2",
  "url": "sec-riemannsches-integral.html#fig-flaeche-unter-graph",
  "type": "Figure",
  "number": "4.1.1",
  "title": "",
  "body": " The area we are looking for, between the graph of and the -axis on .    A coordinate system with an upward-opening parabola . The region between the piece of the curve from to and the -axis is shaded.     "
},
{
  "id": "sub-flaechenproblem-4",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-flaechenproblem-4",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "supply function demand function "
},
{
  "id": "fig-angebot-nachfrage",
  "level": "2",
  "url": "sec-riemannsches-integral.html#fig-angebot-nachfrage",
  "type": "Figure",
  "number": "4.1.2",
  "title": "",
  "body": " Supply and demand curves with the market equilibrium .    A coordinate system with the quantity on the horizontal axis and the price on the vertical axis. An increasing line (supply) and a decreasing line (demand) intersect at a point whose coordinates and are marked by dashed auxiliary lines.     "
},
{
  "id": "sub-flaechenproblem-6",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-flaechenproblem-6",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "consumer surplus producer surplus "
},
{
  "id": "fig-riemannsumme-rechtecke",
  "level": "2",
  "url": "sec-riemannsches-integral.html#fig-riemannsumme-rechtecke",
  "type": "Figure",
  "number": "4.1.3",
  "title": "",
  "body": " Approximating the area under by five rectangles (Riemann sum with midpoints).    The same upward-opening parabola as in , this time covered by five rectangles of equal width. The height of each rectangle is the function value at the midpoint of its subinterval.     "
},
{
  "id": "def-riemannsumme",
  "level": "2",
  "url": "sec-riemannsches-integral.html#def-riemannsumme",
  "type": "Definition",
  "number": "4.1.4",
  "title": "Riemann sum.",
  "body": " Riemann sum   Let be continuous, let be divided into subintervals of equal length , and let be a point in the th subinterval ( ). Then is called a Riemann sum of for the given partition.   "
},
{
  "id": "ex-anwendung-energie-aus-leistungsdaten",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-energie-aus-leistungsdaten",
  "type": "Example",
  "number": "4.1.5",
  "title": "Application: Energy consumption from measured data (optional).",
  "body": " Application: Energy consumption from measured data (optional)   The electrical power of a server room is measured over four hours, once in the middle of each hour: , , and  kW. Estimate the energy consumed in these four hours.    Energy is power times time — so if the power varies, it is the area under the power curve . With the partition into four hours (  h) and the measured values at the midpoints, we get the Riemann sum Monitoring tools, for example, work this way: measured values taken at fixed time intervals are multiplied by the step size and added up. The shorter the interval between measurements, the more accurate the estimate — the following definition makes this passage to the limit precise.   "
},
{
  "id": "def-riemann-integral",
  "level": "2",
  "url": "sec-riemannsches-integral.html#def-riemann-integral",
  "type": "Definition",
  "number": "4.1.6",
  "title": "Riemann integral.",
  "body": " Riemann integral   Let be continuous. For finer and finer partitions ( ), the sequence of Riemann sums converges to a limit that does not depend on the specific choice of the partition and of the points . This limit is called the definite integral of on :    "
},
{
  "id": "ex-integral-konstante-funktion",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-integral-konstante-funktion",
  "type": "Example",
  "number": "4.1.7",
  "title": "The integral of a constant function (optional).",
  "body": " The integral of a constant function (optional)   Determine .    For the constant function , every Riemann sum, whatever the partition, is already exactly the area we are looking for: a rectangle of width and height . So, even without passing to the limit, we have    "
},
{
  "id": "ex-integral-lineare-funktion",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-integral-lineare-funktion",
  "type": "Example",
  "number": "4.1.8",
  "title": "The integral of a linear function (optional).",
  "body": " The integral of a linear function (optional)   Determine .    The region between the line and the -axis on is a right triangle with base and height , so Here, too, you can read off the result directly from the geometry, without computing the limit of the Riemann sums explicitly.   "
},
{
  "id": "ex-riemannsumme-quadratfunktion-tabelle",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-riemannsumme-quadratfunktion-tabelle",
  "type": "Example",
  "number": "4.1.9",
  "title": "Computational example: Convergence of the Riemann sums of <span class=\"process-math\">\\(f(x)=\\frac13x^2\\)<\/span>.",
  "body": " Computational example: Convergence of the Riemann sums of   Consider and the Riemann sums (with midpoints) for with finer and finer subdivisions. The following table shows the values for subintervals. Verify the value for by hand.    For , we have ; the subintervals are and with the midpoints and : The other values in the table arise in the same way, only with more terms — a job for the computer.   Riemann sums of on    Subintervals  Step size  Riemann sum            The Riemann sums clearly approach the value . In the next section, we will confirm with the fundamental theorem of calculus that indeed — without ever having to add up a Riemann sum by hand again.   "
},
{
  "id": "sub-eigenschaften-integral-3",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-eigenschaften-integral-3",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "positive negative "
},
{
  "id": "ex-integral-negative-funktion",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-integral-negative-funktion",
  "type": "Example",
  "number": "4.1.11",
  "title": "The sign of the integral of a negative function (optional).",
  "body": " The sign of the integral of a negative function (optional)   Compare (see ) with .    The function is negative everywhere on ; its graph runs below the -axis. Every term of every Riemann sum of is times the corresponding term for . So already holds for every single Riemann sum, and hence also in the limit The integral is negative — this is not a mistake but exactly the sign convention: the integral measures the signed area, in which areas below the axis count as negative.   "
},
{
  "id": "ex-integral-sinus-periode",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-integral-sinus-periode",
  "type": "Example",
  "number": "4.1.12",
  "title": "The integral of the sine function over a full period.",
  "body": " The integral of the sine function over a full period   Determine without computing an antiderivative.    The graph of is symmetric about its point at : on , it is positive; on , it is negative as an exact mirror image, with an area of the same size. So the positive and negative contributions to the Riemann sum cancel completely, and Note: this does not mean that there is no area between the graph of and the -axis on — the actual (unsigned) area is positive. The integral simply measures the signed area.   "
},
{
  "id": "thm-hauptsatz-integral",
  "level": "2",
  "url": "sec-riemannsches-integral.html#thm-hauptsatz-integral",
  "type": "Theorem",
  "number": "4.1.13",
  "title": "Fundamental theorem of calculus.",
  "body": " Fundamental theorem of calculus   Let be continuous.    The function with is an antiderivative of , that is, .  If is any antiderivative of , that is, , then     Since the expression occurs so often, it is written for short as .   "
},
{
  "id": "ex-hauptsatz-quadratische-funktion",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-hauptsatz-quadratische-funktion",
  "type": "Example",
  "number": "4.1.14",
  "title": "Computational example: Checking the limit of the Riemann sums.",
  "body": " Computational example: Checking the limit of the Riemann sums   Determine with the fundamental theorem, and compare with .    An antiderivative of is (because ). Hence This is exactly the value that the Riemann sums in approached more and more closely — the fundamental theorem gives it exactly and without taking a limit.   "
},
{
  "id": "ex-hauptsatz-summe-exp-quadrat",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-hauptsatz-summe-exp-quadrat",
  "type": "Example",
  "number": "4.1.15",
  "title": "The integral of a sum of an exponential function and a quadratic function (optional).",
  "body": " The integral of a sum of an exponential function and a quadratic function (optional)   Determine .    An antiderivative is . Hence    "
},
{
  "id": "ex-anwendung-strecke-aus-geschwindigkeit",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-strecke-aus-geschwindigkeit",
  "type": "Example",
  "number": "4.1.16",
  "title": "Application: From the speedometer to the distance (optional).",
  "body": " Application: From the speedometer to the distance (optional)   A vehicle accelerates from rest; its speed is (in m\/s, in seconds, ). What distance does it travel in the first seconds?    The distance is the area under the speed curve. An antiderivative of is , so Here, the antiderivative has an intuitive meaning: is the distance traveled up to time , and its derivative is — as on the speedometer — the speed.   "
},
{
  "id": "sub-integralfunktion-2",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-integralfunktion-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "accumulation function "
},
{
  "id": "ex-integralfunktion-ableiten-einfach",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-integralfunktion-ableiten-einfach",
  "type": "Example",
  "number": "4.1.17",
  "title": "The derivative of an accumulation function (without the chain rule) (optional).",
  "body": " The derivative of an accumulation function (without the chain rule) (optional)   Let . Determine .    By the fundamental theorem, is an antiderivative of the integrand, so immediately without having to compute itself explicitly at all.   "
},
{
  "id": "ex-integralfunktion-kettenregel",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-integralfunktion-kettenregel",
  "type": "Example",
  "number": "4.1.18",
  "title": "Computational example: The derivative of an accumulation function with the chain rule.",
  "body": " Computational example: The derivative of an accumulation function with the chain rule   Let . Determine .    The upper limit is , so it is not just the variable. We write with . By the fundamental theorem, , and with the chain rule    "
},
{
  "id": "def-unbestimmtes-integral",
  "level": "2",
  "url": "sec-riemannsches-integral.html#def-unbestimmtes-integral",
  "type": "Definition",
  "number": "4.1.19",
  "title": "Indefinite integral.",
  "body": " Indefinite integral   An antiderivative of a function is also called an indefinite integral of . We write    "
},
{
  "id": "ssub-stammfunktionen-grundintegrale-3",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ssub-stammfunktionen-grundintegrale-3",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Caution: constant of integration "
},
{
  "id": "tab-grundintegrale",
  "level": "2",
  "url": "sec-riemannsches-integral.html#tab-grundintegrale",
  "type": "Table",
  "number": "4.1.20",
  "title": "Basic integrals",
  "body": " Basic integrals    Function  Antiderivative             "
},
{
  "id": "ex-stammfunktion-potenzfunktionen",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-stammfunktion-potenzfunktionen",
  "type": "Example",
  "number": "4.1.21",
  "title": "Computational example: The antiderivative of a sum of power functions.",
  "body": " Computational example: The antiderivative of a sum of power functions   Determine .    First, we write all terms as powers of : and . Integrating term by term with the power rule gives Altogether,    "
},
{
  "id": "ex-stammfunktion-exp-log",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-stammfunktion-exp-log",
  "type": "Example",
  "number": "4.1.22",
  "title": "Computational example: An antiderivative with a logarithmic and an exponential term (optional).",
  "body": " Computational example: An antiderivative with a logarithmic and an exponential term (optional)   Determine .    The constant term (Euler's number, a fixed real value) integrates like any constant to . Together with the other two basic integrals:    "
},
{
  "id": "ex-stammfunktion-trig",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-stammfunktion-trig",
  "type": "Example",
  "number": "4.1.23",
  "title": "Computational example: The antiderivative of a combination of sine and cosine (optional).",
  "body": " Computational example: The antiderivative of a combination of sine and cosine (optional)   Determine .        "
},
{
  "id": "ex-stammfunktion-lineares-argument",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-stammfunktion-lineares-argument",
  "type": "Example",
  "number": "4.1.24",
  "title": "Computational example: Linear arguments — and where the rule ends.",
  "body": " Computational example: Linear arguments — and where the rule ends   Determine , and . Can be handled in the same way?    In all three cases, the argument is linear, and we divide by the factor in front of : Check by differentiating, for example for the first one: . When you integrate, this check is always possible, and it is highly recommended.  For , the argument is not linear. The obvious attempt fails the check: by the quotient rule, the result is not . In fact, has no antiderivative at all that can be written down with elementary functions — a phenomenon that does not exist for differentiation. Such statements were proved by the French mathematician Joseph Liouville in the 19th century. Ironically, the same holds for , the bell curve of the normal distribution, which is probably the most important function in statistics: its integrals have to be computed numerically, as shown in . Differentiation is a craft, integration is sometimes an art — and sometimes impossible.   "
},
{
  "id": "ex-anwendung-kosten-aus-grenzkosten",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-kosten-aus-grenzkosten",
  "type": "Example",
  "number": "4.1.25",
  "title": "Application: The cost function from the marginal cost.",
  "body": " Application: The cost function from the marginal cost   The cost accounting department of a company knows the marginal cost (in euros per unit at a production quantity of units) and the fixed costs of € . Determine the cost function . By how much do the costs increase if production is increased from to units?    Integrating term by term gives all antiderivatives The fixed costs are the costs at , so , and This is exactly the cost function from — differentiation and integration undo each other, and the constant of integration turns out to be the fixed costs. For the increase in costs, you do not even need the constant: by the net change principle, it is    "
},
{
  "id": "ex-anwendung-konsumentenrente",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-konsumentenrente",
  "type": "Example",
  "number": "4.1.26",
  "title": "Application: Consumer surplus in market equilibrium.",
  "body": " Application: Consumer surplus in market equilibrium   We return to the motivating example from . In a market, let the supply and demand functions be given by each giving the price as a function of the quantity . Determine the equilibrium quantity , the equilibrium price and the consumer surplus .    Setting supply equal to demand: The quadratic formula gives and ; the negative solution is ruled out as a quantity, so . The equilibrium price is (check: ✓).  The consumer surplus is the area between the demand curve and the line :    "
},
{
  "id": "ex-anwendung-solarertrag",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-solarertrag",
  "type": "Example",
  "number": "4.1.27",
  "title": "Application: The daily yield of a solar power system (optional).",
  "body": " Application: The daily yield of a solar power system (optional)   On a sunny day, the power of a photovoltaic system between sunrise (6:00) and sunset (18:00) is modeled by ( in hours). How much energy does it deliver on this day?    Energy is the area under the power curve — the same idea as for the server room in , only now exact. The argument of the sine is linear in with factor , so is an antiderivative: Plausibility check: twelve hours at peak power would be  kWh; the sine curve fills the fraction of this. With just under  kWh, you could supply an average four-person household for about four days.   "
},
{
  "id": "ex-anwendung-mittelwert-temperatur",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-mittelwert-temperatur",
  "type": "Example",
  "number": "4.1.28",
  "title": "Application: The average temperature of a day.",
  "body": " Application: The average temperature of a day   For a continuous function , the average value on an interval is defined as — you divide the area under by the length of the interval, just as you divide the sum of the values by their number for discrete data. On a summer day, let the temperature (in °C) approximately follow , where is the time in hours from 9:00 in the morning (the maximum is then at 15:00, the minimum at 3:00 at night). Determine the average temperature over the whole day.     The constant part gives . For the oscillating part, is an antiderivative. Since is exactly one full period of the function (period ), we have , and the term vanishes: Hence — the fluctuation around the mean contributes nothing to the daily average; the average temperature is exactly the constant part .   "
},
{
  "id": "def-uneigentlich-grenzen",
  "level": "2",
  "url": "sec-riemannsches-integral.html#def-uneigentlich-grenzen",
  "type": "Definition",
  "number": "4.1.29",
  "title": "Improper integral with infinite limits of integration.",
  "body": " Improper integral with infinite limits of integration   Let be continuous on the appropriate domain. If the following limits exist, we define If the limit in question exists, the integral is called convergent ; otherwise, it is called divergent .   "
},
{
  "id": "ex-uneigentlich-exponentiell",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-uneigentlich-exponentiell",
  "type": "Example",
  "number": "4.1.30",
  "title": "Computational example: The improper integral of the exponential function.",
  "body": " Computational example: The improper integral of the exponential function   Determine .     Since for , the integral is convergent with the value So a region that extends infinitely far to the right has a finite area — the same phenomenon as for the geometric series in .   "
},
{
  "id": "ex-uneigentlich-potenzen-vergleich",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-uneigentlich-potenzen-vergleich",
  "type": "Example",
  "number": "4.1.31",
  "title": "Computational example: <span class=\"process-math\">\\(\\frac1x\\)<\/span> versus <span class=\"process-math\">\\(\\frac1{x^2}\\)<\/span>.",
  "body": " Computational example: versus   Determine whether and converge.    For , is an antiderivative: For , is an antiderivative: The first integral converges, the second diverges, although both integrands go to . Does this remind you of something? The series converges, the harmonic series diverges ( ). Here, the integral and the series behave in the same way — simply decreases too slowly.   "
},
{
  "id": "def-uneigentlich-integrand",
  "level": "2",
  "url": "sec-riemannsches-integral.html#def-uneigentlich-integrand",
  "type": "Definition",
  "number": "4.1.32",
  "title": "Improper integral with an unbounded integrand.",
  "body": " Improper integral with an unbounded integrand   Let , and let or , respectively, be continuous, but unbounded near the endpoint that is excluded. If the following limits exist, we define    "
},
{
  "id": "ex-uneigentlich-wurzel-integrand",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-uneigentlich-wurzel-integrand",
  "type": "Example",
  "number": "4.1.33",
  "title": "Computational example: An improper integral with a singularity at an endpoint.",
  "body": " Computational example: An improper integral with a singularity at an endpoint   Determine .    The integrand is not defined at the point and is unbounded there, so the integral is improper. So the integral is convergent with the value .   "
},
{
  "id": "ex-uneigentlich-falle-polstelle",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-uneigentlich-falle-polstelle",
  "type": "Example",
  "number": "4.1.34",
  "title": "Caution, a pole: A negative integral of a positive function?",
  "body": " Caution, a pole: A negative integral of a positive function?   Someone computes What went wrong here, and what is correct?    The result cannot be right: the integrand is positive everywhere, so every Riemann sum is positive. The mistake is that is not defined and is unbounded at — in the middle of the interval. But the fundamental theorem requires a function that is continuous on the whole interval. The correct approach is to split the integral at into two improper integrals. The right one alone already diverges: So the integral is divergent; the area under the graph is infinite.   "
},
{
  "id": "ex-anwendung-dichtefunktion-exponentialverteilung",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-dichtefunktion-exponentialverteilung",
  "type": "Example",
  "number": "4.1.35",
  "title": "Application: The density function of the exponential distribution.",
  "body": " Application: The density function of the exponential distribution   In data science, waiting times or lifetimes are often modeled with the exponential distribution . For a parameter , its density function is given by for . A fundamental property of every probability density is that the total area under its graph is equal to — the total probability. Show that .  The probability that the lifetime is at least is the area under the density to the right of . Suppose a component has an exponentially distributed lifetime with per hour. How likely is it that it lasts longer than hours?     Since , we have for , so as claimed. This property — the area under a density is always — is the reason why integrals are everywhere in probability theory and statistics.  For the lifetime, we compute in the same way, only from on: With a probability of about , the component lasts longer than hours. This answers the first question from the introduction to this section.   "
},
{
  "id": "ex-anwendung-barwert-herleitung",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-barwert-herleitung",
  "type": "Example",
  "number": "4.1.36",
  "title": "Application: The present value of a perpetuity.",
  "body": " Application: The present value of a perpetuity   A payment flows continuously at a constant rate per unit of time and is discounted continuously at the interest rate ; so a payment that flows at time is worth today. Derive a general formula for the present value of such a payment that flows indefinitely , .     Since , we have for , so This simple formula — payment rate divided by interest rate — is the continuous version of the perpetuity : in , we obtained exactly the same result for annual payments and an annual interest rate via a geometric series. Here, the series and the integral are the discrete and the continuous version of the same computation.   "
},
{
  "id": "sub-zusammenfassung-4-1-2",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-zusammenfassung-4-1-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Definite integral: Fundamental theorem: Indefinite integral Improper integrals: Applications: "
},
{
  "id": "exercise-buch-stammfunktion-polynom",
  "level": "2",
  "url": "sec-riemannsches-integral.html#exercise-buch-stammfunktion-polynom",
  "type": "Exercise",
  "number": "4.1.6.1",
  "title": "",
  "body": "  Determine all antiderivatives of .        "
},
{
  "id": "exercise-buch-bestimmtes-integral-polynom",
  "level": "2",
  "url": "sec-riemannsches-integral.html#exercise-buch-bestimmtes-integral-polynom",
  "type": "Exercise",
  "number": "4.1.6.2",
  "title": "",
  "body": "  Compute .        "
},
{
  "id": "exercise-buch-integralfunktion-einfach",
  "level": "2",
  "url": "sec-riemannsches-integral.html#exercise-buch-integralfunktion-einfach",
  "type": "Exercise",
  "number": "4.1.6.3",
  "title": "",
  "body": "  Let . Determine .    By the fundamental theorem of calculus, is an antiderivative of the integrand, so immediately    "
},
{
  "id": "exercise-buch-flaeche-parabel-negativ",
  "level": "2",
  "url": "sec-riemannsches-integral.html#exercise-buch-flaeche-parabel-negativ",
  "type": "Exercise",
  "number": "4.1.6.4",
  "title": "",
  "body": "  Compute the area between the graph of and the -axis on the interval .    On , we have (with zeros exactly at the endpoints), so the graph lies on or below the -axis throughout. The area is therefore the absolute value of the integral: so the area is .   "
},
{
  "id": "exercise-buch-uneigentliches-integral-potenz",
  "level": "2",
  "url": "sec-riemannsches-integral.html#exercise-buch-uneigentliches-integral-potenz",
  "type": "Exercise",
  "number": "4.1.6.5",
  "title": "",
  "body": "  Determine whether converges, and if it does, compute its value.     The integral is convergent with the value .   "
},
{
  "id": "sec-integrationstechniken-anwendungen",
  "level": "1",
  "url": "sec-integrationstechniken-anwendungen.html",
  "type": "Section",
  "number": "4.2",
  "title": "Integration techniques and applications",
  "body": " Integration techniques and applications    After this section, you can    apply the linearity of the integral and its additivity over intervals;  integrate products by parts, including the logarithm trick and the technique of solving for the integral;  evaluate integrals by substitution, transform the limits of integration as well for definite integrals, and recognize logarithmic integration;  set up and compute RMS values, arc lengths, volumes of solids of revolution and lateral surface areas as integrals;  approximate integrals numerically with the trapezoidal rule and Simpson's rule, and judge when this is necessary;  compute expected values and normalizing constants of density functions as well as present values of growing streams of payments.     In the previous section, we introduced the Riemann integral and connected it with antiderivatives via the fundamental theorem. But this answers the question of how to actually find an antiderivative only in part: our table of basic integrals covers only individual elementary functions, not their products or compositions. In this section, we introduce the two techniques that close exactly this gap, integration by parts and substitution — each of them a differentiation rule read backward. After that, we apply the integral to RMS values, arc lengths and solids of revolution. Finally, we introduce numerical methods for the cases in which no elementary antiderivative exists — and, as the normal distribution shows, these cases are by no means exotic.  Along the way, you will see what the  volts on the rating plate actually mean, how long a sagging power line is, why you can fill a certain trumpet with paint but cannot paint it, and how buying wine led Johannes Kepler to numerical integration. The sigmoid function from also gets an antiderivative that looks like a smoothed ReLU.    Basic rules: Linearity and additivity over intervals  There is no recipe for integration that always works — but there is a handful of techniques that succeed in the vast majority of practically important cases, and there are numerical methods for the rest. Before we introduce the two most important techniques, integration by parts and substitution, we record two simple but constantly used rules. They follow directly from the definition of the integral as a limit of Riemann sums.   Linearity of the integral   Let be continuous functions and . Then The same rules also hold for indefinite integrals.     Additivity over intervals   Let be continuous and . Then So you can split the interval of integration at any point — intuitively, you simply divide the area under into two parts.     Computational example: Combining linearity and additivity over intervals   For a continuous function , let and . Determine .    With additivity over intervals (splitting at ) followed by linearity:     Additivity over intervals is indispensable above all when the question asks not for the (signed) integral but for the actual area. Then you split at the zeros of the integrand and add the absolute values of the resulting integrals.   Computational example: Area instead of signed area   In , we saw that positive and negative contributions to an integral can cancel. For , compute the integral and the area between the graph of and the -axis on .    An antiderivative is . Over the whole interval: But an area of cannot be right — after all, the graph clearly deviates from the axis. The zeros of are and ; on , is negative; on , it is positive. We split at : The area is the sum of the absolute values, . The two parts happen to be equal in size and cancel exactly in the integral. So if you simply integrate over , you get — a classic mistake when the question asks for an area.      Integration by parts   The basic integrals so far are not enough to integrate a product such as — none of the known rules applies directly. Integration by parts arises from reversing the product rule of differential calculus, and it is the tool for exactly such products.  Such products are more common in applications than you might think: the expected value of a waiting time leads to , the present value of a linearly growing stream of payments to . In both cases, the integrand is a power function times an exponential function.    The rule and typical cases   Integration by parts   Let be continuously differentiable functions. Then The same rule also holds for indefinite integrals: .    By the product rule, , so is an antiderivative of . By the fundamental theorem, , and rearranging gives the formula.    The art lies in splitting the integrand into a factor (which is differentiated) and a factor (which is integrated) in such a way that the new integral is simpler than the original one. A well-established mnemonic comes from the English-speaking world: in the order L ogarithmic function, I nverse trigonometric function, A lgebraic function (powers, polynomials), T rigonometric function, E xponential function — LIATE for short — you choose the factor that comes earlier as (to be differentiated). For products with a power function, this usually means: the power is differentiated (this makes it simpler), and the other factor ( , , …) is integrated. This is no guarantee, but it is a good first attempt.   Computational example: A power function times an exponential function (optional)   Determine .    We choose (to be differentiated) and (to be integrated), so and . With the formula: Check by differentiating: ✓.  What if you swap the roles? With and , so , the new integral would be — more difficult than the original one. If one choice leads in the wrong direction, try the other one.     Computational example: A definite integral with cosine (optional)   Determine .    With , , so , :      Computational example: The logarithm trick   Determine .    At first sight, there is no product here. The trick is to read as and to integrate the constant factor : , , so , . Hence This confirms the entry for in the table of basic integrals from . The same trick — introduce a factor and integrate it — works in exactly the same way for and .     Computational example: Integrating by parts twice and solving for the integral   Determine .    With , : We integrate the new integral by parts once more, this time with , : If we insert this, the original integral appears again on the right: We add to both sides and divide by : This technique of solving for the integral — the integral we are looking for reappears after integrating by parts twice and is treated like an unknown in an equation — works whenever the factors reproduce themselves when you differentiate them, as does together with and .      Application examples   Application: The expected value of the exponential distribution   In , we showed that the density function of the exponential distribution (parameter ) gives the total probability . The expected value of this distribution is defined as Determine .    First, we find an antiderivative by integration by parts, with , , so , : Since the upper limit is infinite, we consider the limit as : As , we have (the exponential function wins against the polynomial ), and likewise . Hence The larger the rate (the faster the distribution decays ), the smaller the expected value — a result that is used all the time in queueing theory and in time-to-failure models. For the component from with per hour, this means: on average, it lasts hours.     Application: The present value of a growing stream of payments   A software company expects continuous revenue from a subscription product at the rate (in thousands of euros per year, in years) — so the revenue grows linearly. As in , the payments are discounted continuously, here at . Determine the present value of the revenue of the first five years, , as well as the present value for an unlimited time horizon.    The constant part is a basic integral: . For the growing part, we integrate by parts with , , so : Together: So the revenue of the first five years (nominally € thousand) is worth just under € thousand today. For an unlimited time horizon, all terms with go to as — this includes , because the exponential function wins against every power — and the present value of € thousand remains. In general, the same computation for gives the present value the growth is divided by and carries particular weight when interest rates are low.       Integration by substitution   The second basic integration technique arises from reversing the chain rule. It is the right tool when the integrand contains the derivative of an inner function as a factor.  In , we saw that cannot be integrated in terms of elementary functions. Surprisingly, is very easy to integrate: the additional factor is — up to the factor — exactly the derivative of the inner function . Integration by substitution recognizes and exploits exactly this situation.    The rule and typical cases   Integration by substitution   Let be continuous and continuously differentiable. Then The same rule holds for indefinite integrals; there, you substitute back to at the end.    If is an antiderivative of , then by the chain rule, . By the fundamental theorem, both sides are therefore equal to .    In practice, you proceed in three steps: you choose a substitution , express in terms of using , and integrate the resulting (hopefully simpler) integral in the variable . For a definite integral, there are two equivalent ways to deal with the limits: either you first compute the indefinite integral in and insert the original limits at the end, or you transform the limits directly with — then you do not have to substitute back at the end. uses the second way.   Computational example: The derivative of the inner function is already there   Determine .    We substitute , so , or : Check: ✓.     Computational example: Logarithmic integration   Determine .    The numerator is exactly the derivative of the denominator: with , we have . Hence where the absolute value can be dropped because for all (the discriminant is negative). In general, for every differentiable function with : — you recognize this form by the fact that the numerator is (up to a constant factor) the derivative of the denominator.     Computational example: A definite integral with transformed limits   Determine .    Substitution , . The limits are transformed as well: at , we have ; at , we have . Hence Since we transformed the limits as well, we do not have to return to at the end.      Application examples   Application: The normalizing constant of a density function   Let a continuous random variable have the density function where is a constant. As in , a probability density must satisfy . Determine .    With the substitution , : The normalization condition gives This density — with — is known as the Rayleigh distribution (a special case). It describes, for example, the distribution of the magnitude of the error for measured quantities with a two-dimensional normal distribution.     Application: Softplus — the antiderivative of the sigmoid function   Determine an antiderivative of the sigmoid function from . How does this antiderivative behave for large positive and for large negative ?    In the given form, you cannot see the derivative of an inner function. Multiplying the numerator and denominator by helps: . Now the numerator is the derivative of the denominator, and with , , we get The function is known in machine learning as softplus . For large , we have , so ; for large negative , we have , so . Softplus therefore behaves like the ReLU function from — only without the kink, and differentiable everywhere. So we are back where we started: the derivative of this smoothed ReLU is exactly the sigmoid function.       Application: The RMS value of an AC voltage  The power outlet supplies volts — or so people say. In fact, the grid voltage oscillates fifty times per second between about and volts, and its average over time is . So what does the mean?  In , we introduced the average value of a function. For a periodically oscillating quantity such as an AC voltage, this average over a full period is usually — so it says nothing about the power actually delivered. We need a different kind of average, one in which negative and positive values do not cancel each other out. The idea: first square (then everything is positive), then average, then take the square root to get back to volts.   RMS value   The RMS value of a periodic function with period is that is, the square root of the mean of the square of the function ( root mean square, RMS). Physically, the RMS value of an AC voltage is exactly the value of the DC voltage that delivers the same power to a resistor over one period as .     Application: The RMS value of a sinusoidal AC voltage   Let an AC voltage be given by with amplitude and angular frequency ; the period is . Determine the RMS value .    First, we need the average value of . We use the identity (by the addition formula, ): The constant part gives . For the oscillating part, is an antiderivative. Since covers exactly two full periods of (period ), this term vanishes when you insert the limits (as for the average daily temperature in ): Hence and the RMS value is This is the well-known rule of thumb of electrical engineering: the RMS voltage of the European household grid,  V, corresponds to an amplitude of . So the  V on the rating plate is exactly the RMS value: a fan heater gets just as warm on the AC voltage as on a DC voltage of  V.    The factor holds only for sinusoidal signals. For other waveforms, you have to redo the computation.   Application: The RMS value of a sawtooth voltage (optional)   In each period , a sawtooth voltage rises linearly from to and then drops abruptly back to : for . Determine the RMS value.     So with the same peak voltage, the sawtooth voltage delivers less power than the sinusoidal voltage ( ). You may know the same construction, the square root of the mean of the squares, from statistics: the RMSE (root mean squared error) measures the typical deviation of a forecasting model without positive and negative errors canceling each other out.      Arc length of a plane curve   Besides areas, the lengths of curved lines can also be computed with integrals. To do so, we first describe a curve by a parametrization .  How long is a cable that sags in an arc? How far does a point on the edge of a rolling wheel travel? For line segments, the Pythagorean theorem is enough; curved lines are cut — as for the integral itself — into many small, almost straight pieces.    Curves and their length   Plane curve   A plane curve parametrized on an interval is a function where are piecewise continuously differentiable functions.     Arc length   For a plane curve , , the arc length is given by In particular, the arc length of the graph of a function (viewed as the curve ) is given by     Intuitively, you approximate the curve by a polygonal path. A small piece of the curve between and has approximately the length of a line segment with height and side length and , respectively, so by the Pythagorean theorem, its length is . Adding up and passing to the limit gives the integral formula above — the same idea as in the derivation of the Riemann integral itself.   Computational example: Checking with a straight line (optional)   Determine the arc length of the graph of on with the integral formula, and compare with the result that the Pythagorean theorem gives directly.    We have , so Check: the line segment runs from to , and the Pythagorean theorem gives directly — the same length ✓. For a straight line, is constant, so the integral becomes a simple multiplication.     Computational example: The arc length of the graph of a function   Determine the arc length of the graph of on the interval .    We have , so and Substitution , , limits , :       Application examples   Application: The arc length of a cycloid arch   If a circle of radius rolls along a straight line without slipping, a fixed point on the circle traces a cycloid . This is, for example, the path of a small stone stuck in the tread of a rolling tire. One arch of this curve is Determine the arc length of this one cycloid arch.    We have and , so With the half-angle identity (by the addition formula, ), this becomes , and for , we have , so Hence So a cycloid arch is exactly times as long as the radius of the generating circle — a remarkably simple result for a curve that looks complicated at first sight. It was discovered in 1658 by the English astronomer and mathematician Christopher Wren — later famous as the architect of St. Paul's Cathedral in London.    Square roots under the integral sign are the reason why arc lengths can rarely be computed exactly. This makes it especially nice when an identity makes the square root disappear — as for the cycloid or in the following example, which takes up the catenary from again.   Application: How long is a sagging power line?   A power line hangs between two poles of equal height that are  m apart. It has the shape of the catenary , (in meters). How long is the line?    From the definitions and , it follows immediately that and . So , and with from , the square root becomes very simple: Hence So the line is just over longer than the distance between the poles. In general, by the same computation, the catenary on has the length . Exactly such computations are needed when overhead power lines are planned: too little length means too much tension, too much length means too much sag.       The volume of a solid of revolution   If you rotate the graph of a function about the -axis, you get a three-dimensional solid whose volume and surface area can also be expressed by integrals. Vases, bottles, glasses, pistons and turned parts from the workshop are such solids of revolution — and at the end of this subsection, there is a solid that you can fill with paint but cannot paint.    Volume and lateral surface area   Solid of revolution   For a continuous function , the three-dimensional volume enclosed by the surface that arises when the graph of is rotated about the -axis is called the solid of revolution generated by .    If you divide into narrow strips of width , as for the Riemann integral, the corresponding part of the solid of revolution is approximately a circular cylinder with radius and height , that is, with volume . Adding up and passing to the limit gives the first part of the following theorem. The lateral surface area follows in the same way from the arc length formula of the previous subsection, applied to the circumferences of the strips.   Volume and lateral surface area of a solid of revolution   Let be continuously differentiable. Then the volume of the solid of revolution generated by is and the lateral surface area of the solid of revolution generated by is      Computational example: Checking with a cone   A cone with base radius and height arises by rotating the line on about the -axis. Determine its volume and lateral surface area with the formulas above, and compare with the cone formulas you know from school, and (with the slant height ).     For the lateral surface area, is constant, so : So both integral formulas reproduce exactly the cone formulas known from elementary geometry — a good sign that the general formulas are correct before you apply them to solids for which there is no elementary formula to compare with.      Application examples   Application: The volume of a champagne glass   A champagne glass is modeled approximately as the solid of revolution generated by the parabola (with ) between the limits and . Determine the volume of the champagne glass.     If you double the height of the glass while keeping its shape (that is, the same ), the volume grows by the factor — an effect of the strong curvature of the parabola that you do not immediately see in the narrow lower part of a champagne glass. In principle, the lateral surface area of the champagne glass could be determined with the same formula, but has no antiderivative among the basic integrals covered in this course. Here, analytical integration reaches its limits, and you have to rely on numerical methods ( ).     Torricelli's trumpet: Finite volume, infinite surface area   If you rotate the graph of for about the -axis, you get an infinitely long, trumpet-shaped solid, which the Italian physicist and mathematician Evangelista Torricelli studied in 1643. Determine its volume, and show that its lateral surface area is infinite.    The volume is an improper integral, and we know it from : For the lateral surface area, we bound the integrand from below. Since , we have (larger integrand, larger integral) because the integral on the right diverges, also by .  The mere fact that an infinitely long solid can have a finite volume troubled Torricelli's contemporaries considerably. Later, the paradox was made even sharper: you could fill the trumpet with cubic units of paint, but no amount of paint in the world would be enough to paint its inner wall. The resolution: a mathematical layer of paint may become arbitrarily thin, a real one cannot. Mathematically, this is once again the difference between and that we already saw for series.       Numerical integration   Integration by parts and substitution solve many integrals, but by no means all of them. Some important functions provably have no antiderivative that can be determined analytically from the known elementary functions — for example, (central in probability theory; see the density function of the normal distribution) or (which comes up when you compute the circumference of an ellipse). As we saw with the champagne glass in , even an integral that looks harmless in itself can take this form. In such cases, the integral is approximated numerically.  The general approach: you divide into subintervals of length , approximate on each subinterval by a function that is easy to integrate, integrate this function locally, and add up the integrals over the subintervals.    The trapezoidal rule  The simplest choice approximates on each subinterval by the secant through and — geometrically, this gives a trapezoid.   Trapezoidal rule   Let be continuous, and let with for . Then, approximately,      The trapezoidal rule with subintervals: on each subinterval, is replaced by the secant; the approximation is the sum of the areas of the four trapezoids. For a convex function, the secants lie above the graph, so the trapezoidal rule then overestimates the integral.    The same upward-opening parabola as for the Riemann sums, this time laid over four trapezoids of equal width. Their top edges connect the points of the curve at the five sample points to by straight lines.        Simpson's rule (Kepler's barrel rule)  There is a nice story behind the second name of this rule. When Johannes Kepler bought wine for his wedding in 1613, the merchant measured the contents of the barrels by pushing a rod diagonally through the bunghole to the opposite edge of the bottom and reading off on a scale how far it reached — no matter how much the barrel bulged. Kepler found this mathematically questionable and promptly wrote a book on computing the volume of wine barrels (1615). The approximation formula that estimates the volume of a barrel from only three cross-sectional areas (bottom, middle, top) is named after him: Kepler's barrel rule . It is exactly the following rule with two subintervals. As a general method for any number of subintervals, it is named after the Englishman Thomas Simpson, who published it in 1743.  If, on each pair of neighboring subintervals, you approximate not by a straight line but by a piece of a parabola through the three points , and , you get a much more accurate approximation.   Simpson's rule   Let be continuous, let be even, and let with . Then, approximately,      Computational example: Comparing the trapezoidal rule and Simpson's rule   Approximate with subintervals, both with the trapezoidal rule and with Simpson's rule, and compare with the exact value.    With , the sample points are with the function values .   Trapezoidal rule:     Simpson's rule ( with weight , with weight ):   The exact value is . Here, the trapezoidal rule slightly overestimates (for a convex function such as , the secant always lies above the graph), while Simpson's rule even hits the exact value precisely — no coincidence: Simpson's parabolic arcs integrate every polynomial of degree up to exactly, and has degree .      Application examples   Application: Approximating a probability integral (optional)   The density function of the standard normal distribution is (up to a constant factor) . As mentioned in the introduction, this function has no elementary antiderivative. Approximate with the trapezoidal rule and subintervals, and compare with Simpson's rule; the function values you need are given, rounded, in the table.                      With : If you multiply this result by the usual factor of the density function, you get for a standard normally distributed random variable . The tabulated value is ; so just four trapezoids already give two correct decimal places. This is exactly how the values in standard normal tables in statistics are actually produced: by numerical integration, not by a closed-form antiderivative.  With the same five function values, Simpson's rule gives and hence — the tabulated value to four decimal places. So with the same computational effort (five function values), Simpson's rule is much more accurate here than the trapezoidal rule: compared with the exact value , the error of the trapezoidal rule is about , and that of Simpson's rule (with exact function values) about — more than a hundred times smaller.       Summary     Basic rules: linearity , ; additivity over intervals .   Integration by parts (the product rule backward): . Rule of thumb: differentiate the power; integrate , , . The mnemonic LIATE helps to choose . Logarithm trick: . Solving for the integral: if the original integral reappears, solve the equation for it.   Substitution (the chain rule backward): with , , we get . For definite integrals, transform the limits as well or substitute back at the end. Special case: .   RMS value of a -periodic quantity: ; for , (  V RMS value   V amplitude).   Geometry: arc length , for graphs ; solid of revolution about the -axis: , lateral surface area . Torricelli's trumpet ( , ): volume , infinite lateral surface area.   Numerical integration: trapezoidal rule (secants, endpoint values weighted by one half), Simpson's rule (parabolas, even, weights with the factor , exact up to degree ). Needed when no elementary antiderivative exists — for example, for .   Applications:  as the expected value of the exponential distribution (by parts); present value of for an unlimited time horizon: ; normalizing a density (substitution); softplus as the antiderivative of the sigmoid function; catenary of length on ; cycloid arch of length ; champagne glass .      Exercises    Determine .    With , , so , :       Determine .    Substitution , :       Determine the arc length of the graph of on the interval .    We have , so       Determine the volume of the solid of revolution that arises when the graph of on is rotated about the -axis.    Since , we have       Approximate with the trapezoidal rule and subintervals. Compare with the exact value and explain the difference.    With : sample points , function values : The exact value is — the trapezoidal rule and the exact value agree exactly, because for a linear function, the secant of the trapezoidal rule reproduces the graph exactly; there is no approximation error.     "
},
{
  "id": "sec-integrationstechniken-anwendungen-2",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#sec-integrationstechniken-anwendungen-2",
  "type": "Objectives",
  "number": "4.2",
  "title": "",
  "body": "  After this section, you can    apply the linearity of the integral and its additivity over intervals;  integrate products by parts, including the logarithm trick and the technique of solving for the integral;  evaluate integrals by substitution, transform the limits of integration as well for definite integrals, and recognize logarithmic integration;  set up and compute RMS values, arc lengths, volumes of solids of revolution and lateral surface areas as integrals;  approximate integrals numerically with the trapezoidal rule and Simpson's rule, and judge when this is necessary;  compute expected values and normalizing constants of density functions as well as present values of growing streams of payments.   "
},
{
  "id": "thm-linearitaet-integral",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-linearitaet-integral",
  "type": "Theorem",
  "number": "4.2.1",
  "title": "Linearity of the integral.",
  "body": " Linearity of the integral   Let be continuous functions and . Then The same rules also hold for indefinite integrals.   "
},
{
  "id": "thm-intervalladditivitaet",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-intervalladditivitaet",
  "type": "Theorem",
  "number": "4.2.2",
  "title": "Additivity over intervals.",
  "body": " Additivity over intervals   Let be continuous and . Then So you can split the interval of integration at any point — intuitively, you simply divide the area under into two parts.   "
},
{
  "id": "ex-linearitaet-intervalladditivitaet-kombiniert",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-linearitaet-intervalladditivitaet-kombiniert",
  "type": "Example",
  "number": "4.2.3",
  "title": "Computational example: Combining linearity and additivity over intervals.",
  "body": " Computational example: Combining linearity and additivity over intervals   For a continuous function , let and . Determine .    With additivity over intervals (splitting at ) followed by linearity:    "
},
{
  "id": "ex-flaecheninhalt-aufteilen",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-flaecheninhalt-aufteilen",
  "type": "Example",
  "number": "4.2.4",
  "title": "Computational example: Area instead of signed area.",
  "body": " Computational example: Area instead of signed area   In , we saw that positive and negative contributions to an integral can cancel. For , compute the integral and the area between the graph of and the -axis on .    An antiderivative is . Over the whole interval: But an area of cannot be right — after all, the graph clearly deviates from the axis. The zeros of are and ; on , is negative; on , it is positive. We split at : The area is the sum of the absolute values, . The two parts happen to be equal in size and cancel exactly in the integral. So if you simply integrate over , you get — a classic mistake when the question asks for an area.   "
},
{
  "id": "sub-partielle-integration-2-1",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#sub-partielle-integration-2-1",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Integration by parts "
},
{
  "id": "thm-partielle-integration",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-partielle-integration",
  "type": "Theorem",
  "number": "4.2.5",
  "title": "Integration by parts.",
  "body": " Integration by parts   Let be continuously differentiable functions. Then The same rule also holds for indefinite integrals: .    By the product rule, , so is an antiderivative of . By the fundamental theorem, , and rearranging gives the formula.   "
},
{
  "id": "ssub-partielle-integration-regel-3",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ssub-partielle-integration-regel-3",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "LIATE "
},
{
  "id": "ex-partielle-integration-potenz-exponential",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-partielle-integration-potenz-exponential",
  "type": "Example",
  "number": "4.2.6",
  "title": "Computational example: A power function times an exponential function (optional).",
  "body": " Computational example: A power function times an exponential function (optional)   Determine .    We choose (to be differentiated) and (to be integrated), so and . With the formula: Check by differentiating: ✓.  What if you swap the roles? With and , so , the new integral would be — more difficult than the original one. If one choice leads in the wrong direction, try the other one.   "
},
{
  "id": "ex-partielle-integration-potenz-trig",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-partielle-integration-potenz-trig",
  "type": "Example",
  "number": "4.2.7",
  "title": "Computational example: A definite integral with cosine (optional).",
  "body": " Computational example: A definite integral with cosine (optional)   Determine .    With , , so , :    "
},
{
  "id": "ex-partielle-integration-logarithmus-trick",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-partielle-integration-logarithmus-trick",
  "type": "Example",
  "number": "4.2.8",
  "title": "Computational example: The logarithm trick.",
  "body": " Computational example: The logarithm trick   Determine .    At first sight, there is no product here. The trick is to read as and to integrate the constant factor : , , so , . Hence This confirms the entry for in the table of basic integrals from . The same trick — introduce a factor and integrate it — works in exactly the same way for and .   "
},
{
  "id": "ex-partielle-integration-doppelt-selbstbezueglich",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-partielle-integration-doppelt-selbstbezueglich",
  "type": "Example",
  "number": "4.2.9",
  "title": "Computational example: Integrating by parts twice and solving for the integral.",
  "body": " Computational example: Integrating by parts twice and solving for the integral   Determine .    With , : We integrate the new integral by parts once more, this time with , : If we insert this, the original integral appears again on the right: We add to both sides and divide by : This technique of solving for the integral — the integral we are looking for reappears after integrating by parts twice and is treated like an unknown in an equation — works whenever the factors reproduce themselves when you differentiate them, as does together with and .   "
},
{
  "id": "ex-anwendung-erwartungswert-exponentialverteilung",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-erwartungswert-exponentialverteilung",
  "type": "Example",
  "number": "4.2.10",
  "title": "Application: The expected value of the exponential distribution.",
  "body": " Application: The expected value of the exponential distribution   In , we showed that the density function of the exponential distribution (parameter ) gives the total probability . The expected value of this distribution is defined as Determine .    First, we find an antiderivative by integration by parts, with , , so , : Since the upper limit is infinite, we consider the limit as : As , we have (the exponential function wins against the polynomial ), and likewise . Hence The larger the rate (the faster the distribution decays ), the smaller the expected value — a result that is used all the time in queueing theory and in time-to-failure models. For the component from with per hour, this means: on average, it lasts hours.   "
},
{
  "id": "ex-anwendung-barwert-wachsender-zahlungsstrom",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-barwert-wachsender-zahlungsstrom",
  "type": "Example",
  "number": "4.2.11",
  "title": "Application: The present value of a growing stream of payments.",
  "body": " Application: The present value of a growing stream of payments   A software company expects continuous revenue from a subscription product at the rate (in thousands of euros per year, in years) — so the revenue grows linearly. As in , the payments are discounted continuously, here at . Determine the present value of the revenue of the first five years, , as well as the present value for an unlimited time horizon.    The constant part is a basic integral: . For the growing part, we integrate by parts with , , so : Together: So the revenue of the first five years (nominally € thousand) is worth just under € thousand today. For an unlimited time horizon, all terms with go to as — this includes , because the exponential function wins against every power — and the present value of € thousand remains. In general, the same computation for gives the present value the growth is divided by and carries particular weight when interest rates are low.   "
},
{
  "id": "thm-substitutionsregel",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-substitutionsregel",
  "type": "Theorem",
  "number": "4.2.12",
  "title": "Integration by substitution.",
  "body": " Integration by substitution   Let be continuous and continuously differentiable. Then The same rule holds for indefinite integrals; there, you substitute back to at the end.    If is an antiderivative of , then by the chain rule, . By the fundamental theorem, both sides are therefore equal to .   "
},
{
  "id": "ex-substitution-kettenregel-exponential",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-substitution-kettenregel-exponential",
  "type": "Example",
  "number": "4.2.13",
  "title": "Computational example: The derivative of the inner function is already there.",
  "body": " Computational example: The derivative of the inner function is already there   Determine .    We substitute , so , or : Check: ✓.   "
},
{
  "id": "ex-substitution-logarithmisch",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-substitution-logarithmisch",
  "type": "Example",
  "number": "4.2.14",
  "title": "Computational example: Logarithmic integration.",
  "body": " Computational example: Logarithmic integration   Determine .    The numerator is exactly the derivative of the denominator: with , we have . Hence where the absolute value can be dropped because for all (the discriminant is negative). In general, for every differentiable function with : — you recognize this form by the fact that the numerator is (up to a constant factor) the derivative of the denominator.   "
},
{
  "id": "ex-substitution-grenzen-transformiert",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-substitution-grenzen-transformiert",
  "type": "Example",
  "number": "4.2.15",
  "title": "Computational example: A definite integral with transformed limits.",
  "body": " Computational example: A definite integral with transformed limits   Determine .    Substitution , . The limits are transformed as well: at , we have ; at , we have . Hence Since we transformed the limits as well, we do not have to return to at the end.   "
},
{
  "id": "ex-anwendung-normierung-dichte-substitution",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-normierung-dichte-substitution",
  "type": "Example",
  "number": "4.2.16",
  "title": "Application: The normalizing constant of a density function.",
  "body": " Application: The normalizing constant of a density function   Let a continuous random variable have the density function where is a constant. As in , a probability density must satisfy . Determine .    With the substitution , : The normalization condition gives This density — with — is known as the Rayleigh distribution (a special case). It describes, for example, the distribution of the magnitude of the error for measured quantities with a two-dimensional normal distribution.   "
},
{
  "id": "ex-anwendung-softplus",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-softplus",
  "type": "Example",
  "number": "4.2.17",
  "title": "Application: Softplus — the antiderivative of the sigmoid function.",
  "body": " Application: Softplus — the antiderivative of the sigmoid function   Determine an antiderivative of the sigmoid function from . How does this antiderivative behave for large positive and for large negative ?    In the given form, you cannot see the derivative of an inner function. Multiplying the numerator and denominator by helps: . Now the numerator is the derivative of the denominator, and with , , we get The function is known in machine learning as softplus . For large , we have , so ; for large negative , we have , so . Softplus therefore behaves like the ReLU function from — only without the kink, and differentiable everywhere. So we are back where we started: the derivative of this smoothed ReLU is exactly the sigmoid function.   "
},
{
  "id": "def-effektivwert",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#def-effektivwert",
  "type": "Definition",
  "number": "4.2.18",
  "title": "RMS value.",
  "body": " RMS value   The RMS value of a periodic function with period is that is, the square root of the mean of the square of the function ( root mean square, RMS). Physically, the RMS value of an AC voltage is exactly the value of the DC voltage that delivers the same power to a resistor over one period as .   "
},
{
  "id": "ex-anwendung-effektivwert-sinusspannung",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-effektivwert-sinusspannung",
  "type": "Example",
  "number": "4.2.19",
  "title": "Application: The RMS value of a sinusoidal AC voltage.",
  "body": " Application: The RMS value of a sinusoidal AC voltage   Let an AC voltage be given by with amplitude and angular frequency ; the period is . Determine the RMS value .    First, we need the average value of . We use the identity (by the addition formula, ): The constant part gives . For the oscillating part, is an antiderivative. Since covers exactly two full periods of (period ), this term vanishes when you insert the limits (as for the average daily temperature in ): Hence and the RMS value is This is the well-known rule of thumb of electrical engineering: the RMS voltage of the European household grid,  V, corresponds to an amplitude of . So the  V on the rating plate is exactly the RMS value: a fan heater gets just as warm on the AC voltage as on a DC voltage of  V.   "
},
{
  "id": "ex-anwendung-effektivwert-saegezahn",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-effektivwert-saegezahn",
  "type": "Example",
  "number": "4.2.20",
  "title": "Application: The RMS value of a sawtooth voltage (optional).",
  "body": " Application: The RMS value of a sawtooth voltage (optional)   In each period , a sawtooth voltage rises linearly from to and then drops abruptly back to : for . Determine the RMS value.     So with the same peak voltage, the sawtooth voltage delivers less power than the sinusoidal voltage ( ). You may know the same construction, the square root of the mean of the squares, from statistics: the RMSE (root mean squared error) measures the typical deviation of a forecasting model without positive and negative errors canceling each other out.   "
},
{
  "id": "sub-bogenlaenge-2-1",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#sub-bogenlaenge-2-1",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "parametrization "
},
{
  "id": "def-ebene-kurve",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#def-ebene-kurve",
  "type": "Definition",
  "number": "4.2.21",
  "title": "Plane curve.",
  "body": " Plane curve   A plane curve parametrized on an interval is a function where are piecewise continuously differentiable functions.   "
},
{
  "id": "thm-bogenlaenge",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-bogenlaenge",
  "type": "Theorem",
  "number": "4.2.22",
  "title": "Arc length.",
  "body": " Arc length   For a plane curve , , the arc length is given by In particular, the arc length of the graph of a function (viewed as the curve ) is given by    "
},
{
  "id": "ex-bogenlaenge-gerade-kontrolle",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-bogenlaenge-gerade-kontrolle",
  "type": "Example",
  "number": "4.2.23",
  "title": "Computational example: Checking with a straight line (optional).",
  "body": " Computational example: Checking with a straight line (optional)   Determine the arc length of the graph of on with the integral formula, and compare with the result that the Pythagorean theorem gives directly.    We have , so Check: the line segment runs from to , and the Pythagorean theorem gives directly — the same length ✓. For a straight line, is constant, so the integral becomes a simple multiplication.   "
},
{
  "id": "ex-bogenlaenge-funktionsgraph-potenz",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-bogenlaenge-funktionsgraph-potenz",
  "type": "Example",
  "number": "4.2.24",
  "title": "Computational example: The arc length of the graph of a function.",
  "body": " Computational example: The arc length of the graph of a function   Determine the arc length of the graph of on the interval .    We have , so and Substitution , , limits , :    "
},
{
  "id": "ex-anwendung-zykloide-bogenlaenge",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-zykloide-bogenlaenge",
  "type": "Example",
  "number": "4.2.25",
  "title": "Application: The arc length of a cycloid arch.",
  "body": " Application: The arc length of a cycloid arch   If a circle of radius rolls along a straight line without slipping, a fixed point on the circle traces a cycloid . This is, for example, the path of a small stone stuck in the tread of a rolling tire. One arch of this curve is Determine the arc length of this one cycloid arch.    We have and , so With the half-angle identity (by the addition formula, ), this becomes , and for , we have , so Hence So a cycloid arch is exactly times as long as the radius of the generating circle — a remarkably simple result for a curve that looks complicated at first sight. It was discovered in 1658 by the English astronomer and mathematician Christopher Wren — later famous as the architect of St. Paul's Cathedral in London.   "
},
{
  "id": "ex-anwendung-laenge-kettenlinie",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-laenge-kettenlinie",
  "type": "Example",
  "number": "4.2.26",
  "title": "Application: How long is a sagging power line?",
  "body": " Application: How long is a sagging power line?   A power line hangs between two poles of equal height that are  m apart. It has the shape of the catenary , (in meters). How long is the line?    From the definitions and , it follows immediately that and . So , and with from , the square root becomes very simple: Hence So the line is just over longer than the distance between the poles. In general, by the same computation, the catenary on has the length . Exactly such computations are needed when overhead power lines are planned: too little length means too much tension, too much length means too much sag.   "
},
{
  "id": "def-rotationskoerper",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#def-rotationskoerper",
  "type": "Definition",
  "number": "4.2.27",
  "title": "Solid of revolution.",
  "body": " Solid of revolution   For a continuous function , the three-dimensional volume enclosed by the surface that arises when the graph of is rotated about the -axis is called the solid of revolution generated by .   "
},
{
  "id": "thm-volumen-mantelflaeche-rotationskoerper",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-volumen-mantelflaeche-rotationskoerper",
  "type": "Theorem",
  "number": "4.2.28",
  "title": "Volume and lateral surface area of a solid of revolution.",
  "body": " Volume and lateral surface area of a solid of revolution   Let be continuously differentiable. Then the volume of the solid of revolution generated by is and the lateral surface area of the solid of revolution generated by is    "
},
{
  "id": "ex-rotationskoerper-kegel-kontrolle",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-rotationskoerper-kegel-kontrolle",
  "type": "Example",
  "number": "4.2.29",
  "title": "Computational example: Checking with a cone.",
  "body": " Computational example: Checking with a cone   A cone with base radius and height arises by rotating the line on about the -axis. Determine its volume and lateral surface area with the formulas above, and compare with the cone formulas you know from school, and (with the slant height ).     For the lateral surface area, is constant, so : So both integral formulas reproduce exactly the cone formulas known from elementary geometry — a good sign that the general formulas are correct before you apply them to solids for which there is no elementary formula to compare with.   "
},
{
  "id": "ex-anwendung-sektglas-volumen",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-sektglas-volumen",
  "type": "Example",
  "number": "4.2.30",
  "title": "Application: The volume of a champagne glass.",
  "body": " Application: The volume of a champagne glass   A champagne glass is modeled approximately as the solid of revolution generated by the parabola (with ) between the limits and . Determine the volume of the champagne glass.     If you double the height of the glass while keeping its shape (that is, the same ), the volume grows by the factor — an effect of the strong curvature of the parabola that you do not immediately see in the narrow lower part of a champagne glass. In principle, the lateral surface area of the champagne glass could be determined with the same formula, but has no antiderivative among the basic integrals covered in this course. Here, analytical integration reaches its limits, and you have to rely on numerical methods ( ).   "
},
{
  "id": "ex-torricellis-trompete",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-torricellis-trompete",
  "type": "Example",
  "number": "4.2.31",
  "title": "Torricelli’s trumpet: Finite volume, infinite surface area.",
  "body": " Torricelli's trumpet: Finite volume, infinite surface area   If you rotate the graph of for about the -axis, you get an infinitely long, trumpet-shaped solid, which the Italian physicist and mathematician Evangelista Torricelli studied in 1643. Determine its volume, and show that its lateral surface area is infinite.    The volume is an improper integral, and we know it from : For the lateral surface area, we bound the integrand from below. Since , we have (larger integrand, larger integral) because the integral on the right diverges, also by .  The mere fact that an infinitely long solid can have a finite volume troubled Torricelli's contemporaries considerably. Later, the paradox was made even sharper: you could fill the trumpet with cubic units of paint, but no amount of paint in the world would be enough to paint its inner wall. The resolution: a mathematical layer of paint may become arbitrarily thin, a real one cannot. Mathematically, this is once again the difference between and that we already saw for series.   "
},
{
  "id": "thm-trapezregel",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-trapezregel",
  "type": "Theorem",
  "number": "4.2.32",
  "title": "Trapezoidal rule.",
  "body": " Trapezoidal rule   Let be continuous, and let with for . Then, approximately,    "
},
{
  "id": "fig-trapezregel",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#fig-trapezregel",
  "type": "Figure",
  "number": "4.2.33",
  "title": "",
  "body": " The trapezoidal rule with subintervals: on each subinterval, is replaced by the secant; the approximation is the sum of the areas of the four trapezoids. For a convex function, the secants lie above the graph, so the trapezoidal rule then overestimates the integral.    The same upward-opening parabola as for the Riemann sums, this time laid over four trapezoids of equal width. Their top edges connect the points of the curve at the five sample points to by straight lines.     "
},
{
  "id": "sub-simpsonregel-2",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#sub-simpsonregel-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Kepler's barrel rule "
},
{
  "id": "thm-simpsonregel",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-simpsonregel",
  "type": "Theorem",
  "number": "4.2.34",
  "title": "Simpson’s rule.",
  "body": " Simpson's rule   Let be continuous, let be even, and let with . Then, approximately,    "
},
{
  "id": "ex-trapez-simpson-vergleich",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-trapez-simpson-vergleich",
  "type": "Example",
  "number": "4.2.35",
  "title": "Computational example: Comparing the trapezoidal rule and Simpson’s rule.",
  "body": " Computational example: Comparing the trapezoidal rule and Simpson's rule   Approximate with subintervals, both with the trapezoidal rule and with Simpson's rule, and compare with the exact value.    With , the sample points are with the function values .   Trapezoidal rule:     Simpson's rule ( with weight , with weight ):   The exact value is . Here, the trapezoidal rule slightly overestimates (for a convex function such as , the secant always lies above the graph), while Simpson's rule even hits the exact value precisely — no coincidence: Simpson's parabolic arcs integrate every polynomial of degree up to exactly, and has degree .   "
},
{
  "id": "ex-anwendung-numerik-normalverteilung",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-numerik-normalverteilung",
  "type": "Example",
  "number": "4.2.36",
  "title": "Application: Approximating a probability integral (optional).",
  "body": " Application: Approximating a probability integral (optional)   The density function of the standard normal distribution is (up to a constant factor) . As mentioned in the introduction, this function has no elementary antiderivative. Approximate with the trapezoidal rule and subintervals, and compare with Simpson's rule; the function values you need are given, rounded, in the table.                      With : If you multiply this result by the usual factor of the density function, you get for a standard normally distributed random variable . The tabulated value is ; so just four trapezoids already give two correct decimal places. This is exactly how the values in standard normal tables in statistics are actually produced: by numerical integration, not by a closed-form antiderivative.  With the same five function values, Simpson's rule gives and hence — the tabulated value to four decimal places. So with the same computational effort (five function values), Simpson's rule is much more accurate here than the trapezoidal rule: compared with the exact value , the error of the trapezoidal rule is about , and that of Simpson's rule (with exact function values) about — more than a hundred times smaller.   "
},
{
  "id": "sub-zusammenfassung-4-2-2",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#sub-zusammenfassung-4-2-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Basic rules: Integration by parts Substitution RMS value Geometry: Numerical integration: Applications: "
},
{
  "id": "exercise-buch-partielle-integration-linear-exponential",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#exercise-buch-partielle-integration-linear-exponential",
  "type": "Exercise",
  "number": "4.2.9.1",
  "title": "",
  "body": "  Determine .    With , , so , :    "
},
{
  "id": "exercise-buch-substitution-potenz-cosinus",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#exercise-buch-substitution-potenz-cosinus",
  "type": "Exercise",
  "number": "4.2.9.2",
  "title": "",
  "body": "  Determine .    Substitution , :    "
},
{
  "id": "exercise-buch-bogenlaenge-gerade",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#exercise-buch-bogenlaenge-gerade",
  "type": "Exercise",
  "number": "4.2.9.3",
  "title": "",
  "body": "  Determine the arc length of the graph of on the interval .    We have , so    "
},
{
  "id": "exercise-buch-rotationskoerper-exponential-einfach",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#exercise-buch-rotationskoerper-exponential-einfach",
  "type": "Exercise",
  "number": "4.2.9.4",
  "title": "",
  "body": "  Determine the volume of the solid of revolution that arises when the graph of on is rotated about the -axis.    Since , we have    "
},
{
  "id": "exercise-buch-trapezregel-linear-exakt",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#exercise-buch-trapezregel-linear-exakt",
  "type": "Exercise",
  "number": "4.2.9.5",
  "title": "",
  "body": "  Approximate with the trapezoidal rule and subintervals. Compare with the exact value and explain the difference.    With : sample points , function values : The exact value is — the trapezoidal rule and the exact value agree exactly, because for a linear function, the secant of the trapezoidal rule reproduces the graph exactly; there is no approximation error.   "
},
{
  "id": "sec-dgl-erster-ordnung",
  "level": "1",
  "url": "sec-dgl-erster-ordnung.html",
  "type": "Section",
  "number": "5.1",
  "title": "Basic concepts and first-order differential equations",
  "body": " Basic concepts and first-order differential equations    After this section, you can    determine the order of a differential equation, verify by substitution that a given function is a solution, and distinguish general from particular solutions;  solve initial value problems by determining the constants of integration from the initial conditions;  read a direction field and recognize equilibrium solutions;  recognize separable differential equations and solve them by separation of variables;  recognize first-order linear differential equations and solve them directly in the homogeneous case and with variation of parameters in the nonhomogeneous case;  set up processes of growth, decay, cooling, charging and saving as differential equations and interpret their solutions;  solve a first-order ODE approximately by hand with a few steps of Euler's method.     In October 1676, Isaac Newton sent a letter to Leibniz through an intermediary. In it, he hid his most important discovery — as a jumble of letters: 6accdae13eff7i3l9n4o4qrr4s8t12ux ; the numbers state how often each letter occurs in a Latin sentence. In this way, Newton wanted to secure the content of the sentence for himself without revealing it. The Russian mathematician Vladimir Arnold once freely translated the message in a single sentence: It is useful to solve differential equations.   It is indeed useful. So far, the function we computed with was always given. In many applications, however, we only know a rule for how it changes : a population grows in proportion to its size, a body cools in proportion to the temperature difference, a capacitor charges more slowly the fuller it is. A differential equation poses the task of reconstructing the function itself from such a rule. We first clarify the basic concepts — what is a solution, and how many are there? Then the direction field gives us a qualitative impression of how the solutions behave (and we see how a computer solves an ODE approximately). Finally, we learn two solution methods for first-order equations: separation of variables for separable equations and variation of parameters for linear equations. The applications range from a cup of coffee that cools down, through dating a glacier mummy, to a savings plan.    Basic concepts: Differential equations and their solutions   In , we made a remarkable observation about a discharging capacitor: the charge satisfies . Its rate of change is, at every moment, proportional to the charge still present. Now let us ask the reverse question: if we only know this law of change, can we deduce the function itself? Equations of this kind, in which an unknown function occurs together with its derivatives, are called differential equations . They are the language in which laws of nature, technical systems and many economic models are formulated.  We have already met the simplest differential equation in , without calling it that: if is a continuous function and is an antiderivative, this means exactly that the unknown function satisfies the equation — an equation in which not itself but its derivative is given explicitly. A differential equation generalizes this idea: instead of only the first derivative, any derivatives of the unknown function may occur, and the right-hand side may also depend on the unknown function itself.    Differential equations, order and solutions   Ordinary differential equation of order   An ordinary differential equation (ODE) of order is an equation for an unknown function of one variable in which and its derivatives up to order occur: The order of the ODE is the highest order of a derivative that occurs in it.    Strictly speaking, this is the definition of an explicit ODE of order , since the equation is already solved for . In this course, only such explicit ODEs occur, so we do not need a more general definition.   Computational example: Order and general solution of an ODE   The motion of a body under constant acceleration (for example, free fall) satisfies the ODE . Determine the order of this ODE and show that is a solution for any .    The highest derivative that occurs is , so the ODE has order . Substitution confirms the solution: from , we get and hence — regardless of the choice of and . So the family of functions satisfies the ODE for every choice of the two parameters.     Solution of an ODE   A solution of an ODE is an -times differentiable function that satisfies the differential equation.    A solution is called general if it depends on parameters (constants of integration).  A solution is called particular if it contains no free parameters. You typically obtain a particular solution from the general solution by imposing  initial conditions — this is called an initial value problem (IVP) — or  boundary conditions (boundary value problem).      Note: the solution of a differential equation is not a number but a function . Whether a given function is a solution is always checked in the same way: differentiate, substitute, compare.   Computational example: Checking a solution by substitution   Show that solves the ODE . Is also a solution?    For , we have — the ODE is satisfied for all . Likewise, solves the ODE for every constant . For , the derivative is the same, , but . The two sides differ by , so this function is not a solution. An additive constant is harmless for antiderivatives, but in general not for differential equations.    In , is the general solution: it depends on exactly parameters, matching the order of the ODE. An initial value problem fixes both parameters, as the following example shows.   Computational example: Initial value problem for free fall (optional)   Determine the particular solution of the initial value problem , , .    We substitute the initial conditions into the general solution from and into its derivative : So the particular solution of the IVP is Since a second-order ODE has two constants of integration, exactly two initial conditions are needed to fix them uniquely — one for and one for .    Not every differential equation has a solution at all. The Picard–Lindelöf theorem , which is central in mathematics, gives conditions under which an initial value problem has a unique solution. For this course, however, the mathematical existence theory is of minor importance: we typically assume that an ODE comes from an application in which it is already clear that a solution exists, and we concentrate on the question of how to find this solution.    Application examples   Application: Modeling population growth   We want to model the size of a population (for example, a bacterial culture) as a function of time .    In the simplest case, the growth of the population is proportional to the population currently present. How can this be formulated as an ODE?  A more realistic assumption is that the population can only grow up to a carrying capacity , and that the growth is proportional both to the size of the population and to the remaining (relative) capacity. What is the corresponding ODE?         Proportional to the population present means that there is a constant (the growth rate) such that the rate of change is times the current population: This is the ODE of exponential growth .  For a population of , the remaining relative capacity is — it is close to as long as is small compared with , and close to when approaches . Proportionality to the population and to the remaining capacity gives This is the ODE of logistic growth . For close to , it behaves almost like the ODE from (a); for close to , the factor slows the growth.    We will solve both equations in by separation of variables.       Qualitative understanding: The direction field  Before we actually solve first-order differential equations , it is worth looking at a simple tool. It gives a qualitative impression of how the solutions behave, without the need to solve the ODE at all.  The idea is that of a navigation device that shows only the direction of travel at each location: if you follow the arrows, you find the way without ever having seen the map. A first-order ODE does exactly this — at every point , it prescribes the slope that a solution must have there.   Direction field   For an ODE , the direction field assigns to each point of the plane the direction vector . Every solution of the ODE is tangent to this vector at every point — so at each point, the direction field shows the slope that a solution passing through it would have to have.    If you draw a short line segment with slope at many grid points , you get a picture from which you can roughly sketch the shape of a solution for a given initial value : you simply follow the line segments.   Direction field of the ODE . Along the line , the slope is everywhere — this is the equilibrium solution . For , the slope increases with and .    A grid of short line segments in the region , which show the slope of the ODE at each grid point. Along the horizontal axis , all line segments are horizontal. With increasing distance from the origin, the line segments become steeper; in the first and third quadrants (where ), they point up and to the right, and in the second and fourth quadrants (where ), down and to the right.       Computational example: Reading off an equilibrium solution from the direction field   Use the ODE (without solving it) to give a reason why is a solution, and explain why a solution with must stay positive for all .    If we substitute , the left-hand side is and the right-hand side is — the ODE is satisfied for all . So is a (constant) solution, a so-called equilibrium solution . A solution with cannot cross the axis : if it reached at some value , then at this point both and would agree with the equilibrium solution. By the Picard–Lindelöf theorem, the solution through this point would be uniquely determined — so it would have to coincide with , contradicting . A solution therefore always stays on one side of the equilibrium solution.     Application: How does a cup of coffee cool down?   Suppose the temperature (in °C) of a cup of coffee in a room at  °C satisfies the ODE , with in minutes ( ). Read off from the ODE: Where is the equilibrium solution? How do solutions above and below it behave? How fast does coffee at  °C cool down at first?   Direction field of with two solution curves: one starts at  °C (hot coffee), the other at  °C (cold drink). Both approach the equilibrium solution (dashed).    A coordinate system with time from to minutes on the horizontal axis and temperature from to  °C on the vertical axis. Short line segments point down and to the right above and up and to the right below it, and they become flatter toward the dashed line . One curve falls from and approaches from above; a second curve rises from and approaches from below.        The right-hand side does not depend on , only on ; so all line segments on a horizontal line are parallel. The slope is zero for : is the equilibrium solution — coffee that is already at room temperature stays that way. For , the slope is negative, and the solutions fall; for , it is positive, and the solutions rise (a cold drink warms up). In both cases, the line segments become flatter the closer you get to : all solutions approach room temperature more and more slowly. For , we have : at first, the coffee loses  °C per minute. We have read off all of this without solving the ODE; the solution formula follows in .    The picture of the navigation device can be taken literally: you start at the point , read off the slope there, follow this direction for a small time step , read off the new slope, and so on: This is Euler's method , which Leonhard Euler described in 1768 — the simplest algorithm with which computers solve differential equations approximately. Modern solvers, such as scipy.integrate.solve_ivp , work on the same principle, only with cleverer steps.   Computational example: Euler's method by hand   For the coffee from , with , compute two steps of Euler's method with step size minutes. The exact values (see ) are and .     The approximation underestimates the temperature: for five minutes, the method keeps going with the initial, steep cooling rate, although in reality the cooling slows down from the start. With a smaller step size, the approximation improves (with , ten steps give instead of the exact ; with , we only get ), but it takes more steps.    Watch out: a common trap. Larger steps are not simply less accurate — beyond a certain size, the method produces nonsense. For the coffee, , so in each step, the distance to room temperature is multiplied by . With , this factor is : the approximation jumps back and forth endlessly between  °C and  °C. With , it is , and the temperature swings back and forth with an amplitude that grows without bound — although the exact solution calmly approaches  °C. The approximation converges only for , because means   You already know this phenomenon under a different name. Gradient descent from , for a loss function (there it was called ), is nothing other than Euler's method with step size for the ODE . The exact solution of this ODE always runs downhill, toward a minimum; Euler's method follows it in discrete steps. A learning rate that is too large is simply a step size that is too large — and the jumping and the explosive growth that we saw for gradient descent with too large an are the same as for the coffee with .    Solution by separation of variables   For a large class of first-order differential equations, a solution can actually be computed explicitly by reducing the equation to integrals.  The idea is astonishingly simple: you move everything that has to do with to one side of the equation and everything that has to do with to the other — and then you integrate both sides. For this to work, the right-hand side of the ODE must split into a part and a part.    Separable equations and the method   Separable ODE   A first-order differential equation is called separable if it can be written in the form for functions and — that is, the right-hand side splits into a product of a pure part and a pure part.     Computational example: Recognizing separability   Which of the following differential equations are separable?             For , we can solve for : . This is a product of and — separable .  With and together in the argument, cannot be written as a product of a pure function of and a pure function of — not separable .  By the laws of exponents, , so and — separable .       Solution method: Separation of variables   Consider a separable ODE . Proceed as follows:     Separation of variables: all terms to the left, all pure terms to the right (for ):    Integration of both sides with respect to , where you substitute on the left-hand side:    Solving the resulting equation for .   Adding equilibrium solutions: every constant solution with also solves the ODE. However, it was excluded by the division in step 1 and must therefore be added to the solution separately.       Computational example: Separation of variables   Determine the general solution of the ODE from by separation of variables, as well as the particular solution of the initial value problem with .     General solution: for , we separate the variables: Integration of both sides, with on the left-hand side: Solving for : where , depending on the sign of . The equilibrium solution (from ) is exactly the case , which we had excluded in step 1. So the general solution is  Particular solution: the initial condition gives , so This matches the direction field from : the solution starts at above the equilibrium solution and grows more and more steeply for — matching the line segments, which become steeper as increases.      Application examples   Application: Logistic growth   Solve the ODE of logistic growth from , by separation of variables, and determine the particular solution for the initial value with .    Separation of variables gives (with ): For the integral on the left, we use the partial fraction decomposition . The technique behind it is neither assumed nor covered in this course; the decomposition is given here and is easy to check (bringing the fractions to a common denominator gives ✓). This gives where we can drop the absolute value signs because . So Solving for : This is the logistic function . From , we get , so , and hence the particular solution As , , so — the population approaches the carrying capacity, regardless of the initial value .  We have met the logistic function before: for , , , it is exactly the sigmoid function from . Logistic regression takes its name from this differential equation — and the derivative formula from is nothing other than the logistic ODE itself with .     Application: Newton's law of cooling    Newton's law of cooling states that a body with temperature in surroundings with a constant temperature cools down (or warms up) at a rate that is proportional to the temperature difference . Set up the ODE and solve the initial value problem with .     Proportional to the temperature difference means that there is a constant (the cooling constant) with The minus sign ensures that always moves toward : if , the right-hand side is negative, and falls; if , it is positive, and rises. This ODE is separable with , : Solving gives the general solution , . From , we get , so the particular solution is As , — in the long run, the body adjusts to the ambient temperature, regardless of the sign of . For the coffee from , , which is exactly the blue curve in .    In practice, the cooling constant is usually not known. Instead, it is determined from a measurement.   Application: The cooling constant from measured data (optional)   A cup of coffee is at  °C at first, and the room is at  °C. After minutes, you measure  °C. Determine . When will the coffee have cooled down to  °C?    With and , we have . The measurement gives For , we need , so The first  °C of cooling take minutes, the next  °C take a little over twelve minutes more — the closer the coffee gets to room temperature, the more slowly it cools down. This procedure — set up a model, estimate the parameters from measured data, compute a forecast — is the basic pattern of all data-driven modeling.    The same mathematics also works backward in time: if you know the decay rate of a substance and measure how much of it is still there, you can compute how long the decay has been going on.   Application: How old is Ötzi?   Living organisms contain a fixed proportion of the radioactive carbon isotope C-14. After death, no new C-14 is taken up, and the amount present decays according to the ODE ; the half-life of C-14 is years. Determine . A tissue sample still contains of the original proportion of C-14. How old is it? (Use and .)    The ODE is separable and has the solution . After one half-life, , so , and From , we get , so This is the order of magnitude of the age of the glacier mummy Ötzi, found in the Ötztal Alps in 1991. The radiocarbon method put its age at about years (the numbers here are simplified; in practice, the measurement result is also calibrated). The method earned the chemist Willard Libby, who developed it in the late 1940s, the Nobel Prize in Chemistry in 1960 — and it rests on nothing more than the simplest differential equation of this section.       First-order linear differential equations  When a capacitor charges or discharges and when a body cools down, and occur only linearly : not squared, not under a root, not in the exponent. Such linear differential equations are the most important class of all in engineering. For them, there is a closed-form solution formula. It saves you from going through all four steps of separation of variables again and again. Together with variation of parameters in , it also works when separation of variables fails.   Linear differential equation   A first-order differential equation is called linear if it can be written in the form for functions and .    If , the linear ODE is called homogeneous . In this case, it is separable: has the form with and .  If , the ODE is called nonhomogeneous . In this case, it is in general no longer separable, since and on the right-hand side are combined additively instead of multiplicatively as soon as is included.       Computational example: Recognizing linearity   Which of the following first-order ODEs are linear? Which of these are homogeneous, and which are nonhomogeneous?             Rearranged: . This is linear with , — so it is homogeneous .  The argument of contains the product , so the equation cannot be written in the form — not linear .  For , we divide by : . This is linear with , — so it is nonhomogeneous .      We first solve the homogeneous case by separation of variables: with , , the method from gives where is an antiderivative of . Solving for gives the following closed-form formula.   General solution of a homogeneous first-order linear ODE   Let be a homogeneous first-order linear ODE, and let be an antiderivative of . Then is the general solution of the ODE.    Check: with and the chain rule, , so . You can therefore always verify the formula by differentiating.   Computational example: Homogeneous linear ODE with a nonconstant coefficient   Determine the general solution of the ODE and the particular solution of the IVP with .    Here, , so (we choose the constant of integration to be , as is usual with this method — it would only be absorbed into the free constant ). By , the general solution is The initial condition gives , so the particular solution is The solution is a bell curve — the same shape as the density of the normal distribution from .    If the coefficient is constant, , then , and the solution formula reduces to — exactly the exponential functions that we saw for exponential growth and for the discharging capacitor ( ). So homogeneous linear ODEs with a constant coefficient are nothing new. They are a special case that we had already solved by separation of variables; the formula from generalizes this to arbitrary (nonconstant) coefficients .    Variation of parameters   What remains is the nonhomogeneous case with . The idea for obtaining a solution of the nonhomogeneous case from the known solution of the homogeneous case is known as variation of parameters (also called variation of constants): we let the constant in the homogeneous solution depend on . That is, we substitute the trial solution into the nonhomogeneous ODE and determine which function satisfies the equation.    The method  The computation is short. With the trial solution and the product rule, we have so The second term cancels exactly — this is no coincidence, because solves the homogeneous equation. So the nonhomogeneous ODE only requires , that is, , and is an antiderivative of this function. This gives the following solution formula.   Solution of a nonhomogeneous first-order linear ODE   Let be a nonhomogeneous first-order linear ODE. If is an antiderivative of and is an antiderivative of , then is the general solution of the ODE.    This general solution has a remarkable structure. Let be the general solution of the associated homogeneous ODE ( ), and let be a particular solution of the nonhomogeneous ODE (the case ). Then so the general solution of the nonhomogeneous ODE is always the sum of the general solution of the homogeneous ODE and any particular solution of the nonhomogeneous ODE.   Computational example: Variation of parameters   Use variation of parameters to determine the general solution of the ODE and the particular solution of the IVP with .    Here, and . First, With this, we determine as an antiderivative of . With the substitution , : By , the general solution is The initial condition gives , so , and the particular solution is Check: , and ✓.      Application examples   Application: Charging a capacitor   A capacitor with capacitance is connected in series with a resistor . At time , the capacitor is uncharged, , and a constant voltage is applied. The capacitor voltage then satisfies the ODE Determine how changes over time.    Here, and , both constant. Hence , and is an antiderivative of : So the general solution is From , we get , so the particular solution is As , : the capacitor charges exponentially up to the applied voltage. The quantity is called the time constant : after the time , , and after , more than of the final voltage has already been reached. With  kΩ and  µF, we get  s — after about five seconds, the capacitor is considered fully charged in practice.    The associated homogeneous case corresponds to discharging a previously charged capacitor ( , no applied ): directly gives , and the voltage decays exponentially. So charging and discharging the same circuit are exactly the nonhomogeneous and the homogeneous case, respectively, of the same linear ODE.   Application: A savings plan with continuous compounding   An account with continuous compounding at per year receives continuous deposits, a total of € per year. So in a short time interval , the balance (in euros, in years) grows by the interest and the deposit . Dividing by and letting gives Determine and the balance after years.    In standard form, , so , , . An antiderivative of is . Hence From , we get , so After years, and euros. The deposits total euros; the rest is interest, including interest on interest. (That also appears in the solution is a coincidence: the term of years is exactly .)  The constant is the equilibrium value of the ODE: a negative balance at which the interest on the debt would exactly offset the deposits. Every other solution moves away from this point exponentially — a repelling fixed point, as with the loan from , whose fixed point we examined in .    For a general savings plan with a continuous interest rate and a deposit rate , that is, with , the same computation gives the solution It is the continuous counterpart of the formula for the outstanding balance from : there, with and a deposit instead of an installment ( ), the balance is — geometric instead of exponential growth, but otherwise the same structure.     Summary     ODE of order :  . The general solution contains free constants; initial conditions ( , , …) determine a particular solution (initial value problem). To check a solution: substitute it.   Direction field of : at each point, a line segment with slope ; solutions follow the line segments. Where for all , is an equilibrium solution, which other solutions do not cross. Euler's method : follows the direction field in time steps ; steps that are too large make the approximation useless. Gradient descent for a loss function is Euler's method for , with the learning rate as the step size.   Separation of variables for : , solve for , add the equilibrium solutions ( ).   Linear ODE  with : homogeneous ( ) ; nonhomogeneous with (variation of parameters). General solution = homogeneous solution + a particular solution.   Models: exponential growth ( ); logistic growth (logistic function, sigmoid); Newton's law of cooling ( ); circuit ( ); radioactive decay with ; savings plan ( for ).      Exercises    Show that is a solution of the ODE . What is the order of this ODE, and is the given solution general or particular?    From , we get — the ODE is satisfied for all . The ODE has order (the highest derivative that occurs is ). Since contains no free parameter, it is a particular solution; the general solution would be , .      Determine the general solution of the ODE by separation of variables.    For : . Integration gives , so . The equilibrium solution corresponds to , so the general solution is       Solve the initial value problem , ( ).    With , we have , so . From , we get the particular solution       Use variation of parameters to determine the solution of the initial value problem , .    With , we have . For , we integrate : . The general solution is From , we get and the particular solution       Consider the initial value problem , . Use Euler's method with step size to compute an approximation for . Show by substitution that is the exact solution, and compare the two ( ).    With , , : For , we have and ; moreover, . So the exact value is . The approximation is too low: the solution becomes steeper and steeper, but in each step, the method uses the slope at the beginning of the step.     "
},
{
  "id": "sec-dgl-erster-ordnung-2",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#sec-dgl-erster-ordnung-2",
  "type": "Objectives",
  "number": "5.1",
  "title": "",
  "body": "  After this section, you can    determine the order of a differential equation, verify by substitution that a given function is a solution, and distinguish general from particular solutions;  solve initial value problems by determining the constants of integration from the initial conditions;  read a direction field and recognize equilibrium solutions;  recognize separable differential equations and solve them by separation of variables;  recognize first-order linear differential equations and solve them directly in the homogeneous case and with variation of parameters in the nonhomogeneous case;  set up processes of growth, decay, cooling, charging and saving as differential equations and interpret their solutions;  solve a first-order ODE approximately by hand with a few steps of Euler's method.   "
},
{
  "id": "sub-begriffsbildung-dgl-2-1",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#sub-begriffsbildung-dgl-2-1",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "differential equations "
},
{
  "id": "def-gewoehnliche-dgl",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#def-gewoehnliche-dgl",
  "type": "Definition",
  "number": "5.1.1",
  "title": "Ordinary differential equation of order <span class=\"process-math\">\\(n\\)<\/span>.",
  "body": " Ordinary differential equation of order   An ordinary differential equation (ODE) of order is an equation for an unknown function of one variable in which and its derivatives up to order occur: The order of the ODE is the highest order of a derivative that occurs in it.   "
},
{
  "id": "ssub-dgl-ordnung-loesung-3",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ssub-dgl-ordnung-loesung-3",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "explicit "
},
{
  "id": "ex-dgl-freier-fall-ordnung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-dgl-freier-fall-ordnung",
  "type": "Example",
  "number": "5.1.2",
  "title": "Computational example: Order and general solution of an ODE.",
  "body": " Computational example: Order and general solution of an ODE   The motion of a body under constant acceleration (for example, free fall) satisfies the ODE . Determine the order of this ODE and show that is a solution for any .    The highest derivative that occurs is , so the ODE has order . Substitution confirms the solution: from , we get and hence — regardless of the choice of and . So the family of functions satisfies the ODE for every choice of the two parameters.   "
},
{
  "id": "def-loesung-dgl",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#def-loesung-dgl",
  "type": "Definition",
  "number": "5.1.3",
  "title": "Solution of an ODE.",
  "body": " Solution of an ODE   A solution of an ODE is an -times differentiable function that satisfies the differential equation.    A solution is called general if it depends on parameters (constants of integration).  A solution is called particular if it contains no free parameters. You typically obtain a particular solution from the general solution by imposing  initial conditions — this is called an initial value problem (IVP) — or  boundary conditions (boundary value problem).     "
},
{
  "id": "ex-dgl-loesung-verifizieren",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-dgl-loesung-verifizieren",
  "type": "Example",
  "number": "5.1.4",
  "title": "Computational example: Checking a solution by substitution.",
  "body": " Computational example: Checking a solution by substitution   Show that solves the ODE . Is also a solution?    For , we have — the ODE is satisfied for all . Likewise, solves the ODE for every constant . For , the derivative is the same, , but . The two sides differ by , so this function is not a solution. An additive constant is harmless for antiderivatives, but in general not for differential equations.   "
},
{
  "id": "ex-dgl-freier-fall-awp",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-dgl-freier-fall-awp",
  "type": "Example",
  "number": "5.1.5",
  "title": "Computational example: Initial value problem for free fall (optional).",
  "body": " Computational example: Initial value problem for free fall (optional)   Determine the particular solution of the initial value problem , , .    We substitute the initial conditions into the general solution from and into its derivative : So the particular solution of the IVP is Since a second-order ODE has two constants of integration, exactly two initial conditions are needed to fix them uniquely — one for and one for .   "
},
{
  "id": "ssub-dgl-ordnung-loesung-10",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ssub-dgl-ordnung-loesung-10",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Picard–Lindelöf theorem "
},
{
  "id": "ex-anwendung-populationswachstum-modellierung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-populationswachstum-modellierung",
  "type": "Example",
  "number": "5.1.6",
  "title": "Application: Modeling population growth.",
  "body": " Application: Modeling population growth   We want to model the size of a population (for example, a bacterial culture) as a function of time .    In the simplest case, the growth of the population is proportional to the population currently present. How can this be formulated as an ODE?  A more realistic assumption is that the population can only grow up to a carrying capacity , and that the growth is proportional both to the size of the population and to the remaining (relative) capacity. What is the corresponding ODE?         Proportional to the population present means that there is a constant (the growth rate) such that the rate of change is times the current population: This is the ODE of exponential growth .  For a population of , the remaining relative capacity is — it is close to as long as is small compared with , and close to when approaches . Proportionality to the population and to the remaining capacity gives This is the ODE of logistic growth . For close to , it behaves almost like the ODE from (a); for close to , the factor slows the growth.    We will solve both equations in by separation of variables.   "
},
{
  "id": "def-richtungsfeld",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#def-richtungsfeld",
  "type": "Definition",
  "number": "5.1.7",
  "title": "Direction field.",
  "body": " Direction field   For an ODE , the direction field assigns to each point of the plane the direction vector . Every solution of the ODE is tangent to this vector at every point — so at each point, the direction field shows the slope that a solution passing through it would have to have.   "
},
{
  "id": "fig-richtungsfeld-beispiel",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#fig-richtungsfeld-beispiel",
  "type": "Figure",
  "number": "5.1.8",
  "title": "",
  "body": " Direction field of the ODE . Along the line , the slope is everywhere — this is the equilibrium solution . For , the slope increases with and .    A grid of short line segments in the region , which show the slope of the ODE at each grid point. Along the horizontal axis , all line segments are horizontal. With increasing distance from the origin, the line segments become steeper; in the first and third quadrants (where ), they point up and to the right, and in the second and fourth quadrants (where ), down and to the right.     "
},
{
  "id": "ex-richtungsfeld-gleichgewichtsloesung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-richtungsfeld-gleichgewichtsloesung",
  "type": "Example",
  "number": "5.1.9",
  "title": "Computational example: Reading off an equilibrium solution from the direction field.",
  "body": " Computational example: Reading off an equilibrium solution from the direction field   Use the ODE (without solving it) to give a reason why is a solution, and explain why a solution with must stay positive for all .    If we substitute , the left-hand side is and the right-hand side is — the ODE is satisfied for all . So is a (constant) solution, a so-called equilibrium solution . A solution with cannot cross the axis : if it reached at some value , then at this point both and would agree with the equilibrium solution. By the Picard–Lindelöf theorem, the solution through this point would be uniquely determined — so it would have to coincide with , contradicting . A solution therefore always stays on one side of the equilibrium solution.   "
},
{
  "id": "ex-anwendung-richtungsfeld-abkuehlung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-richtungsfeld-abkuehlung",
  "type": "Example",
  "number": "5.1.10",
  "title": "Application: How does a cup of coffee cool down?",
  "body": " Application: How does a cup of coffee cool down?   Suppose the temperature (in °C) of a cup of coffee in a room at  °C satisfies the ODE , with in minutes ( ). Read off from the ODE: Where is the equilibrium solution? How do solutions above and below it behave? How fast does coffee at  °C cool down at first?   Direction field of with two solution curves: one starts at  °C (hot coffee), the other at  °C (cold drink). Both approach the equilibrium solution (dashed).    A coordinate system with time from to minutes on the horizontal axis and temperature from to  °C on the vertical axis. Short line segments point down and to the right above and up and to the right below it, and they become flatter toward the dashed line . One curve falls from and approaches from above; a second curve rises from and approaches from below.        The right-hand side does not depend on , only on ; so all line segments on a horizontal line are parallel. The slope is zero for : is the equilibrium solution — coffee that is already at room temperature stays that way. For , the slope is negative, and the solutions fall; for , it is positive, and the solutions rise (a cold drink warms up). In both cases, the line segments become flatter the closer you get to : all solutions approach room temperature more and more slowly. For , we have : at first, the coffee loses  °C per minute. We have read off all of this without solving the ODE; the solution formula follows in .   "
},
{
  "id": "sub-richtungsfeld-9",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#sub-richtungsfeld-9",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Euler's method "
},
{
  "id": "ex-euler-verfahren-kaffee",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-euler-verfahren-kaffee",
  "type": "Example",
  "number": "5.1.12",
  "title": "Computational example: Euler’s method by hand.",
  "body": " Computational example: Euler's method by hand   For the coffee from , with , compute two steps of Euler's method with step size minutes. The exact values (see ) are and .     The approximation underestimates the temperature: for five minutes, the method keeps going with the initial, steep cooling rate, although in reality the cooling slows down from the start. With a smaller step size, the approximation improves (with , ten steps give instead of the exact ; with , we only get ), but it takes more steps.   "
},
{
  "id": "def-trennbare-dgl",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#def-trennbare-dgl",
  "type": "Definition",
  "number": "5.1.13",
  "title": "Separable ODE.",
  "body": " Separable ODE   A first-order differential equation is called separable if it can be written in the form for functions and — that is, the right-hand side splits into a product of a pure part and a pure part.   "
},
{
  "id": "ex-trennbarkeit-erkennen",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-trennbarkeit-erkennen",
  "type": "Example",
  "number": "5.1.14",
  "title": "Computational example: Recognizing separability.",
  "body": " Computational example: Recognizing separability   Which of the following differential equations are separable?             For , we can solve for : . This is a product of and — separable .  With and together in the argument, cannot be written as a product of a pure function of and a pure function of — not separable .  By the laws of exponents, , so and — separable .     "
},
{
  "id": "thm-loesungsverfahren-trennung-der-variablen",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#thm-loesungsverfahren-trennung-der-variablen",
  "type": "Theorem",
  "number": "5.1.15",
  "title": "Solution method: Separation of variables.",
  "body": " Solution method: Separation of variables   Consider a separable ODE . Proceed as follows:     Separation of variables: all terms to the left, all pure terms to the right (for ):    Integration of both sides with respect to , where you substitute on the left-hand side:    Solving the resulting equation for .   Adding equilibrium solutions: every constant solution with also solves the ODE. However, it was excluded by the division in step 1 and must therefore be added to the solution separately.     "
},
{
  "id": "ex-trennung-der-variablen-grundbeispiel",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-trennung-der-variablen-grundbeispiel",
  "type": "Example",
  "number": "5.1.16",
  "title": "Computational example: Separation of variables.",
  "body": " Computational example: Separation of variables   Determine the general solution of the ODE from by separation of variables, as well as the particular solution of the initial value problem with .     General solution: for , we separate the variables: Integration of both sides, with on the left-hand side: Solving for : where , depending on the sign of . The equilibrium solution (from ) is exactly the case , which we had excluded in step 1. So the general solution is  Particular solution: the initial condition gives , so This matches the direction field from : the solution starts at above the equilibrium solution and grows more and more steeply for — matching the line segments, which become steeper as increases.   "
},
{
  "id": "ex-anwendung-logistisches-wachstum",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-logistisches-wachstum",
  "type": "Example",
  "number": "5.1.17",
  "title": "Application: Logistic growth.",
  "body": " Application: Logistic growth   Solve the ODE of logistic growth from , by separation of variables, and determine the particular solution for the initial value with .    Separation of variables gives (with ): For the integral on the left, we use the partial fraction decomposition . The technique behind it is neither assumed nor covered in this course; the decomposition is given here and is easy to check (bringing the fractions to a common denominator gives ✓). This gives where we can drop the absolute value signs because . So Solving for : This is the logistic function . From , we get , so , and hence the particular solution As , , so — the population approaches the carrying capacity, regardless of the initial value .  We have met the logistic function before: for , , , it is exactly the sigmoid function from . Logistic regression takes its name from this differential equation — and the derivative formula from is nothing other than the logistic ODE itself with .   "
},
{
  "id": "ex-anwendung-newtonsche-abkuehlung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-newtonsche-abkuehlung",
  "type": "Example",
  "number": "5.1.18",
  "title": "Application: Newton’s law of cooling.",
  "body": " Application: Newton's law of cooling    Newton's law of cooling states that a body with temperature in surroundings with a constant temperature cools down (or warms up) at a rate that is proportional to the temperature difference . Set up the ODE and solve the initial value problem with .     Proportional to the temperature difference means that there is a constant (the cooling constant) with The minus sign ensures that always moves toward : if , the right-hand side is negative, and falls; if , it is positive, and rises. This ODE is separable with , : Solving gives the general solution , . From , we get , so the particular solution is As , — in the long run, the body adjusts to the ambient temperature, regardless of the sign of . For the coffee from , , which is exactly the blue curve in .   "
},
{
  "id": "ex-anwendung-abkuehlkonstante-bestimmen",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-abkuehlkonstante-bestimmen",
  "type": "Example",
  "number": "5.1.19",
  "title": "Application: The cooling constant from measured data (optional).",
  "body": " Application: The cooling constant from measured data (optional)   A cup of coffee is at  °C at first, and the room is at  °C. After minutes, you measure  °C. Determine . When will the coffee have cooled down to  °C?    With and , we have . The measurement gives For , we need , so The first  °C of cooling take minutes, the next  °C take a little over twelve minutes more — the closer the coffee gets to room temperature, the more slowly it cools down. This procedure — set up a model, estimate the parameters from measured data, compute a forecast — is the basic pattern of all data-driven modeling.   "
},
{
  "id": "ex-anwendung-radiokarbon",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-radiokarbon",
  "type": "Example",
  "number": "5.1.20",
  "title": "Application: How old is Ötzi?",
  "body": " Application: How old is Ötzi?   Living organisms contain a fixed proportion of the radioactive carbon isotope C-14. After death, no new C-14 is taken up, and the amount present decays according to the ODE ; the half-life of C-14 is years. Determine . A tissue sample still contains of the original proportion of C-14. How old is it? (Use and .)    The ODE is separable and has the solution . After one half-life, , so , and From , we get , so This is the order of magnitude of the age of the glacier mummy Ötzi, found in the Ötztal Alps in 1991. The radiocarbon method put its age at about years (the numbers here are simplified; in practice, the measurement result is also calibrated). The method earned the chemist Willard Libby, who developed it in the late 1940s, the Nobel Prize in Chemistry in 1960 — and it rests on nothing more than the simplest differential equation of this section.   "
},
{
  "id": "def-lineare-dgl-erster-ordnung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#def-lineare-dgl-erster-ordnung",
  "type": "Definition",
  "number": "5.1.21",
  "title": "Linear differential equation.",
  "body": " Linear differential equation   A first-order differential equation is called linear if it can be written in the form for functions and .    If , the linear ODE is called homogeneous . In this case, it is separable: has the form with and .  If , the ODE is called nonhomogeneous . In this case, it is in general no longer separable, since and on the right-hand side are combined additively instead of multiplicatively as soon as is included.     "
},
{
  "id": "ex-linearitaet-erkennen",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-linearitaet-erkennen",
  "type": "Example",
  "number": "5.1.22",
  "title": "Computational example: Recognizing linearity.",
  "body": " Computational example: Recognizing linearity   Which of the following first-order ODEs are linear? Which of these are homogeneous, and which are nonhomogeneous?             Rearranged: . This is linear with , — so it is homogeneous .  The argument of contains the product , so the equation cannot be written in the form — not linear .  For , we divide by : . This is linear with , — so it is nonhomogeneous .     "
},
{
  "id": "thm-loesung-homogene-lineare-dgl",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#thm-loesung-homogene-lineare-dgl",
  "type": "Theorem",
  "number": "5.1.23",
  "title": "General solution of a homogeneous first-order linear ODE.",
  "body": " General solution of a homogeneous first-order linear ODE   Let be a homogeneous first-order linear ODE, and let be an antiderivative of . Then is the general solution of the ODE.   "
},
{
  "id": "ex-lineare-dgl-homogen-nichtkonstant",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-lineare-dgl-homogen-nichtkonstant",
  "type": "Example",
  "number": "5.1.24",
  "title": "Computational example: Homogeneous linear ODE with a nonconstant coefficient.",
  "body": " Computational example: Homogeneous linear ODE with a nonconstant coefficient   Determine the general solution of the ODE and the particular solution of the IVP with .    Here, , so (we choose the constant of integration to be , as is usual with this method — it would only be absorbed into the free constant ). By , the general solution is The initial condition gives , so the particular solution is The solution is a bell curve — the same shape as the density of the normal distribution from .   "
},
{
  "id": "sub-variation-der-konstanten-2-1",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#sub-variation-der-konstanten-2-1",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "variation of parameters "
},
{
  "id": "thm-variation-der-konstanten",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#thm-variation-der-konstanten",
  "type": "Theorem",
  "number": "5.1.25",
  "title": "Solution of a nonhomogeneous first-order linear ODE.",
  "body": " Solution of a nonhomogeneous first-order linear ODE   Let be a nonhomogeneous first-order linear ODE. If is an antiderivative of and is an antiderivative of , then is the general solution of the ODE.   "
},
{
  "id": "ssub-variation-methode-4",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ssub-variation-methode-4",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "particular solution sum "
},
{
  "id": "ex-variation-der-konstanten-grundbeispiel",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-variation-der-konstanten-grundbeispiel",
  "type": "Example",
  "number": "5.1.26",
  "title": "Computational example: Variation of parameters.",
  "body": " Computational example: Variation of parameters   Use variation of parameters to determine the general solution of the ODE and the particular solution of the IVP with .    Here, and . First, With this, we determine as an antiderivative of . With the substitution , : By , the general solution is The initial condition gives , so , and the particular solution is Check: , and ✓.   "
},
{
  "id": "ex-anwendung-rc-glied-aufladung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-rc-glied-aufladung",
  "type": "Example",
  "number": "5.1.27",
  "title": "Application: Charging a capacitor.",
  "body": " Application: Charging a capacitor   A capacitor with capacitance is connected in series with a resistor . At time , the capacitor is uncharged, , and a constant voltage is applied. The capacitor voltage then satisfies the ODE Determine how changes over time.    Here, and , both constant. Hence , and is an antiderivative of : So the general solution is From , we get , so the particular solution is As , : the capacitor charges exponentially up to the applied voltage. The quantity is called the time constant : after the time , , and after , more than of the final voltage has already been reached. With  kΩ and  µF, we get  s — after about five seconds, the capacitor is considered fully charged in practice.   "
},
{
  "id": "sub-anwendungen-variation-der-konstanten-3",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#sub-anwendungen-variation-der-konstanten-3",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "discharging "
},
{
  "id": "ex-anwendung-sparplan-stetig",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-sparplan-stetig",
  "type": "Example",
  "number": "5.1.28",
  "title": "Application: A savings plan with continuous compounding.",
  "body": " Application: A savings plan with continuous compounding   An account with continuous compounding at per year receives continuous deposits, a total of € per year. So in a short time interval , the balance (in euros, in years) grows by the interest and the deposit . Dividing by and letting gives Determine and the balance after years.    In standard form, , so , , . An antiderivative of is . Hence From , we get , so After years, and euros. The deposits total euros; the rest is interest, including interest on interest. (That also appears in the solution is a coincidence: the term of years is exactly .)  The constant is the equilibrium value of the ODE: a negative balance at which the interest on the debt would exactly offset the deposits. Every other solution moves away from this point exponentially — a repelling fixed point, as with the loan from , whose fixed point we examined in .   "
},
{
  "id": "sub-zusammenfassung-5-1-2",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#sub-zusammenfassung-5-1-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "ODE of order : Direction field Euler's method Separation of variables Linear ODE Models: "
},
{
  "id": "exercise-buch-loesung-verifizieren",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#exercise-buch-loesung-verifizieren",
  "type": "Exercise",
  "number": "5.1.7.1",
  "title": "",
  "body": "  Show that is a solution of the ODE . What is the order of this ODE, and is the given solution general or particular?    From , we get — the ODE is satisfied for all . The ODE has order (the highest derivative that occurs is ). Since contains no free parameter, it is a particular solution; the general solution would be , .   "
},
{
  "id": "exercise-buch-trennung-der-variablen-einfach",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#exercise-buch-trennung-der-variablen-einfach",
  "type": "Exercise",
  "number": "5.1.7.2",
  "title": "",
  "body": "  Determine the general solution of the ODE by separation of variables.    For : . Integration gives , so . The equilibrium solution corresponds to , so the general solution is    "
},
{
  "id": "exercise-buch-lineare-dgl-homogen-einfach",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#exercise-buch-lineare-dgl-homogen-einfach",
  "type": "Exercise",
  "number": "5.1.7.3",
  "title": "",
  "body": "  Solve the initial value problem , ( ).    With , we have , so . From , we get the particular solution    "
},
{
  "id": "exercise-buch-variation-der-konstanten-einfach",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#exercise-buch-variation-der-konstanten-einfach",
  "type": "Exercise",
  "number": "5.1.7.4",
  "title": "",
  "body": "  Use variation of parameters to determine the solution of the initial value problem , .    With , we have . For , we integrate : . The general solution is From , we get and the particular solution    "
},
{
  "id": "exercise-buch-euler-verfahren",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#exercise-buch-euler-verfahren",
  "type": "Exercise",
  "number": "5.1.7.5",
  "title": "",
  "body": "  Consider the initial value problem , . Use Euler's method with step size to compute an approximation for . Show by substitution that is the exact solution, and compare the two ( ).    With , , : For , we have and ; moreover, . So the exact value is . The approximation is too low: the solution becomes steeper and steeper, but in each step, the method uses the slope at the beginning of the step.   "
},
{
  "id": "sec-lineare-dgl-hoeherer-ordnung",
  "level": "1",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html",
  "type": "Section",
  "number": "5.2",
  "title": "Higher-order linear differential equations",
  "body": " Higher-order linear differential equations    After this section, you can    recognize higher-order linear differential equations and classify them by homogeneity and by whether their coefficients are constant;  set up the characteristic polynomial and, from its roots — real, complex or multiple — read off the general solution of the homogeneous equation;  solve second-order initial value problems and, conversely, reconstruct the differential equation from a given solution;  find particular solutions of nonhomogeneous equations with the method of undetermined coefficients, including the resonance case;  distinguish the damping cases of the harmonic oscillator and apply them to the mass-spring system, the RLC circuit and the momentum optimizer.     Many oscillation problems — from the mass-spring system to the RLC circuit — lead to differential equations in which derivatives of the unknown function of second or higher order occur. In this section, we develop a systematic method for solving linear differential equations of any order with constant coefficients. First, we solve the homogeneous case via the roots of a characteristic polynomial — this is where the work from pays off, because these roots are often complex. Then we solve the nonhomogeneous case with the method of undetermined coefficients. The harmonic oscillator serves as a running application example. It lets us interpret each case of the solution concretely: Does the system oscillate, does it creep back to its equilibrium position, or do its oscillations build up dangerously when it is driven?  You will see how to design a shock absorber, why soldiers should not march in step across bridges, how to work back from a measured oscillation signal to the spring constant and the damping, and what the momentum optimizer used to train neural networks has in common with a mass-spring system. Almost in passing, the same method also gives a closed formula for the Fibonacci numbers from . This section is also a review: complex numbers, polynomials, derivatives and systems of equations all come together here.    Higher-order linear differential equations  When a car drives over a bump, its body sinks down on the springs — and afterward, it should come to rest again quickly, without bouncing for a long time. Whether this works depends on the interplay of spring and shock absorber. It is described by a differential equation that contains the acceleration , that is, the second derivative of the displacement. Newton's law force equals mass times acceleration makes second-order equations the rule in mechanics.  The first-order differential equations from are therefore sufficient for many applications, but not for all. The harmonic oscillator (an oscillating mass-spring system or an RLC circuit), for example, is described by an equation of the form , in which derivatives of the unknown function up to the second derivative occur. Likewise, the deflection of a loaded beam satisfies a fourth-order equation, . In what follows, we therefore turn to methods for solving higher-order linear differential equations with constant coefficients .   Linear ODE of order   A differential equation of order is called linear if it can be written in the form where the coefficients are functions.    If all are constant , the ODE has constant coefficients .  If , the ODE is called homogeneous ; otherwise, it is called nonhomogeneous .       Computational example: Recognizing linearity, homogeneity and constant coefficients   Which of the following ODEs are linear? Which of these are homogeneous or nonhomogeneous, and which have constant coefficients?             In the term , the unknown function does not occur to the first power — the equation is not linear .  All coefficients ( ) are numbers, hence constant, and the right-hand side is different from — linear , nonhomogeneous , constant coefficients .  The coefficient of is not constant. But the equation is of the first power in each of , and the right-hand side is — linear , homogeneous , but not with constant coefficients.      In the rest of this section, we restrict ourselves to linear ODEs with constant coefficients — exactly the class that occurs for the harmonic oscillator and many other oscillation problems in engineering. As with first-order ODEs, we proceed in two steps: first, we solve the homogeneous case, then the nonhomogeneous one.    Solving homogeneous higher-order linear ODEs  We consider a homogeneous linear ODE of order with constant coefficients The method of solution relies on an auxiliary polynomial that depends only on the coefficients of the ODE.   Characteristic polynomial   The characteristic polynomial of the above ODE is     Where does this polynomial come from? The trial solution has the derivatives . If we substitute it into the ODE and factor out , exactly the condition remains. By the fundamental theorem of algebra ( ), has exactly (possibly complex) roots, counted with multiplicity. Each root gives one or more fundamental solutions of the ODE — depending on whether it is real or complex and whether it is simple or multiple. We distinguish three cases.   Case 1: Simple real root   If is a simple root of , then is a solution of the ODE.     Computational example: Two distinct real roots (Case 1) (optional)   Determine the general solution of and the solution with , .     has the simple roots and . By Case 1, each of them gives a solution, and the general solution is (anticipating ) Check for : ✓. The initial values give the system of equations Adding twice the first equation to the second gives , so , and . Two initial conditions for two constants — as for free fall in .    If a root is complex, , then is a complex-valued function. With Euler's formula ( ), however, it splits at once into real components: So the real part determines growth or decay, and the imaginary part the frequency of the oscillation. Here the complex numbers from pay off directly.   Case 2: Simple pair of complex conjugate roots   If (with ) is a simple root of , then the complex conjugate is also a simple root (since the coefficients of are real). The real and imaginary parts of the complex solution then give two independent real solutions      Case 3: Root of multiplicity    (a) If is a real root of multiplicity of , then form independent solutions of the ODE.   (b) If (with ) is a complex root of multiplicity , then the real and imaginary parts of , , give the independent real solutions      General solution of the homogeneous ODE   If are the fundamental solutions obtained by the above cases from the roots of the characteristic polynomial, then the general solution is The free parameters can be fixed by given initial values; this gives a particular solution.     Computational example: Double real root (Case 3a) (optional)   Determine the general solution of .    The characteristic polynomial can be factored with the formula for the square of a difference: . So there is only one root, the double root . By Case 3a, it gives the fundamental solutions and , and the general solution is The check shows that the strange factor really works: for , we have and , so ✓. With a double root, the trial solution alone would have given only one solution, but a second-order ODE needs two.     Computational example: Simple pair of complex roots (Case 2) (optional)   Determine the general solution of .    For , the quadratic formula gives the roots With , , Case 2 gives the fundamental solutions and , so      Computational example: Combining Case 1 and Case 2   Determine the general solution of . ( Hint : One root is .)    For , substituting confirms . Polynomial division gives (check: ), and has the roots (Case 2 with , ). Together with the simple real root (Case 1), we get the general solution      Computational example: Double pair of complex roots (Case 3b) (optional)   Determine the general solution of .    The formula for the square of a sum (in ) gives , so has the double pair of complex conjugate roots ( , , ). By Case 3b, they give the four fundamental solutions , , , , and the general solution is By the way, we have met the polynomial before: in , we found that it has no root at all in , but two double roots in . It is exactly these multiplicities that now determine the factors in the solution.    The method exponential trial solution, characteristic polynomial, roots is so powerful that it works far beyond differential equations. A short digression at the end of this subsection shows it at work on a sequence that you met in .   Digression: A formula for the Fibonacci numbers   The Fibonacci numbers satisfy the recursion with , . (In , we started with ; the starting value fits this, because then .) Carry the exponential trial solution over to sequences by substituting , and determine an explicit formula for .    Substituting gives , and dividing by gives the characteristic polynomial of the recursion, so (the golden ratio) and . As for an ODE, every combination is a solution of the recursion, and the initial values fix the constants: and , so . This gives Binet's formula  Remarkably, although the formula is full of square roots of , the result is always an integer. Since , the second term quickly becomes tiny; for , for example, , and indeed . So the Fibonacci numbers grow essentially geometrically, with the factor .    The formula is named after Jacques Binet, who published it in 1843. However, Abraham de Moivre and Daniel Bernoulli already knew it about a century earlier — in mathematics, it is not unusual for a formula to bear the name of a later discoverer.    Solving nonhomogeneous higher-order linear ODEs  We now consider a nonhomogeneous linear ODE with constant coefficients The procedure is analogous to that for the first-order linear ODEs in :    Determine the general solution of the associated homogeneous ODE ( ).  Use the method of undetermined coefficients to find a particular solution  of the nonhomogeneous ODE.  The general solution of the nonhomogeneous ODE is then .    Step 3 is no coincidence: if is another solution of the nonhomogeneous ODE, then the difference solves the homogeneous ODE (since the right-hand side cancels in the subtraction), so it can be written as .  Which trial solution to choose for depends on the forcing function — and on whether the exponent belonging to happens to coincide with a root of the characteristic polynomial (the resonance case ). In this case, the standard trial solution is multiplied by the factor , where is the multiplicity of the root.   Trial solutions for the method of undetermined coefficients ( = multiplicity of the root in the resonance case)      Forcing function  Trial solution for    Polynomial of degree  if is not a root of ; otherwise     if is not a root of ; otherwise     if is not a root of ; otherwise     if is not a root of ; otherwise with the factor     The coefficients of the trial solution are found by substituting it into the ODE and comparing the coefficients on both sides — for polynomials, the coefficients of the powers ; for trigonometric terms, those of and . This leads to a small system of linear equations.  The idea behind the table: differentiation turns polynomials, exponential functions and trigonometric functions into functions of the same type. If we substitute a trial solution of this type into the left-hand side, we get a function of this type again, and we only have to choose the coefficients suitably. For exponential and trigonometric forcing functions in the resonance case, the standard trial solution already solves the homogeneous equation and gives on the left (for polynomials, the degree drops on substitution); only the factor helps.   Computational example: The method of undetermined coefficients without resonance   Determine the general solution of .    The characteristic polynomial has the double root , so . Since is not a root of , we use the trial solution . With , , substituting gives so, comparing coefficients, (from ), (from ), and (from ). Hence , and the general solution is      Computational example: Exponential forcing function in the resonance case   Determine the general solution of .    The characteristic polynomial has the double root , so . The forcing function belongs to — resonance with multiplicity . Trial solution: , with the derivatives (product rule) Substituting into the ODE: All terms with cancel — this is typical of the resonance case. From , it follows that . The general solution is      Computational example: Damped trigonometric forcing function (optional)   Determine a particular solution of .    The characteristic polynomial has the roots . The forcing function belongs to ; this is not a root of — not the resonance case. Trial solution: . Differentiating twice (product and chain rules), substituting and sorting by and gives This should equal , so and . The first equation gives ; substituting into the second gives , so , and       Application: The harmonic oscillator  As a running application example, we consider a mass-spring system : a mass that hangs from a spring with spring constant and whose motion is damped by friction with coefficient . For the displacement from the equilibrium position, we have (without an external force) and, under an external force , With the abbreviations (damping grows in proportion to the velocity) and (the restoring force grows in proportion to the displacement), the ODE takes the standard form which also holds for other oscillating systems — for example, for the charge on the capacitor of an RLC circuit (see below). We first solve the homogeneous case ( , free oscillation), then the nonhomogeneous case (forced oscillation).  The characteristic polynomial has the roots . Depending on the sign of , we distinguish four cases.   Case 1a: Free undamped oscillation ( )  Without damping, the ODE becomes , with purely imaginary roots . The general solution is an undamped oscillation with constant amplitude.    Case 1b: Free damped oscillation ( )  For , we distinguish three subcases by the sign of : the underdamped case ( ), the critically damped case ( ) and the overdamped case ( ).    Computational example: Underdamped case   Solve with , .    Here , ; since , the system is underdamped. The roots give By the product rule, From and , it follows that The system oscillates about the equilibrium position, with an amplitude that decays exponentially to .     Computational example: Critically damped case   Solve with , .    Here , : the critically damped case. The characteristic polynomial has the double root , so and (product rule) . From and , it follows that The system returns to the equilibrium position as fast as possible without oscillating — the borderline case between oscillation and pure decay.     Application: Designing a shock absorber (optional)   One wheel of a car carries a mass of  kg, and the spring has the spring constant  N\/m. What damping constant (in Ns\/m) must the shock absorber have so that the car body is critically damped when it comes to rest after a bump?    We have , so per second. Critical damping requires , and with , it follows that A weaker shock absorber lets the car keep bouncing (underdamped case); a stronger one makes the suspension hard and sluggish (overdamped case). In practice, a considerably lower value is chosen, about to of critical damping, because a slight bounce feels more comfortable — but critical damping is the reference point of the design.     Computational example: Overdamped case   Solve with , .    Here , ; since , the system is overdamped. The roots are real and distinct: , , so . From and , it follows (substituting ) that , , so Both parts decay monotonically and without oscillating, and decays much faster than .     The four cases of the free oscillation (so ) with the same initial values , : undamped ( ), underdamped ( ), critically damped ( ) and overdamped ( ). The critically damped case reaches the equilibrium position fastest without overshooting.    Four curves over the time axis; all start at with a horizontal tangent. The undamped curve is a pure cosine oscillation with constant amplitude. The underdamped curve oscillates about zero with exponentially decreasing amplitude. The critically damped curve falls monotonically and quickly toward zero without crossing the axis. The overdamped curve also falls monotonically toward zero, but much more slowly.      In practice, the reverse question often arises: you observe an oscillating system but do not know its parameters. Then you read off the roots of the characteristic polynomial from the measured solution and build the polynomial from them — just as in , only with an ODE at the end.   Application: From the measured signal back to the differential equation   A displacement sensor on a test mass suspended on a spring (  kg) records the displacement after an impact ( in mm, in seconds). Which differential equation describes the system? What are the spring constant (in N\/m) and the damping constant (in Ns\/m)?    The solution consists of and , so by , it belongs to the pair of complex roots . The characteristic polynomial is therefore and the ODE is . Check: by the product rule, so . Hence and , and with , , it follows that The measurement reveals the parameters very directly: the decay rate gives the real part , and the period  s gives the imaginary part . Together, they give . Working backward from the signal to the model in this way is called system identification , and it is everyday practice in the condition monitoring of machines: if the measured natural frequency changes, something has usually changed in the mechanics — for example, a crack or a loose screw.     Case 2: Forced oscillation and resonance  If a sinusoidal external force with driving frequency acts on the system, the method of undetermined coefficients gives a particular solution of the form , as long as is not a root of the characteristic polynomial — the system takes on (after a transient phase) the frequency of the driving force. If, however, the system is undamped and is driven exactly at its natural frequency , then is a root of , and resonance occurs.    Computational example: Resonance catastrophe   Determine the general solution of the undamped, driven system .    The characteristic polynomial has the roots . So the driving frequency exactly matches the natural frequency — the resonance case. Trial solution: . Differentiating twice with the product rule gives and when we substitute into , the part with cancels against : Comparing coefficients gives , , so The term grows without bound: the amplitude of the oscillation increases linearly with time — a resonance catastrophe .    This is an ideal case: in practice (with ), the amplitude of a forced oscillation stays finite, but it can become very large if the damping is small and the driving frequency is close to . This is why soldiers break step on bridges: in 1831, the Broughton Suspension Bridge near Manchester collapsed while a company of soldiers marched across it in step (a faulty bolt probably played a part). When the Millennium Bridge in London opened in 2000, it began to sway sideways, because the pedestrians unconsciously adapted their steps to the swaying and so amplified it more and more; the bridge was closed after two days and reopened only after additional dampers had been installed. (The famous collapse of the Tacoma Narrows Bridge in the wind in 1940, by contrast, is due to a related but different mechanism, self-excited flutter.)  How large the amplitudes of damped systems become can be computed elegantly with a trick from . Instead of the real driving term , we consider the complex driving term ; the real driving term is its real part. Because the ODE has real coefficients, the real part of a complex solution is then a solution of the real equation — and the exponential trial solution spares us all the computation with sine and cosine.   Application: The resonance curve with complex numbers   A damped system has , and . Use the complex trial solution for to determine the amplitude of the forced oscillation as a function of the driving frequency , and evaluate it for , and .    With and , the ODE becomes a single complex equation for , and hence Here the quotient rule for moduli from helped. Why is the amplitude? If we write , then : an oscillation with amplitude and phase shift . With the given values, , so Slow shaking ( ) simply moves the system along; at the natural frequency, the amplitude is four times as large; very fast shaking hardly gets through, because the system is too sluggish. If you have ever watched a washing machine speed up for the spin cycle, you know this resonance curve : as it passes through a certain speed of rotation, it shakes violently; after that, it runs smoothly again. Incidentally, the denominator is exactly the characteristic polynomial , evaluated at . For the low-pass filter in , the denominator is likewise the characteristic polynomial of its first-order ODE at — mathematically, resonant circuits and filters are close relatives.     Application: RLC circuit  The same mathematics describes an electrical series RLC circuit consisting of an inductance , a resistance and a capacitance : for the charge on the capacitor, we have (without an external voltage source) which is exactly the form of the free mass-spring system with and . A large resistance corresponds to strong damping: the charge decreases without changing polarity (overdamped or critically damped case), whereas a small resistance leads to a discharge with damped oscillations (underdamped case) — exactly the same case distinction as for the mechanical mass-spring system. For  H and  µF, we have ; critical damping occurs at . With a smaller resistance, the circuit oscillates.    Application: Momentum in gradient descent  The case distinction of the damped oscillator also reappears in the training of neural networks. Optimizers with momentum (the classical heavy-ball method) update the parameter vector not only on the basis of the current gradient; they also add an inertia term that continues the last direction of motion. In the continuous-time limit, the error (distance from the optimum) of such a trajectory near a minimum can be described approximately by exactly our oscillator ODE , where depends on the curvature of the cost function and on the momentum parameter. Damping that is too weak ( ) makes the optimization overshoot and oscillate around the minimum; damping that is too strong ( ) makes convergence unnecessarily slow. The critically damped case thus marks — just as for the mass-spring system — the fastest possible approach without overshooting, a criterion that plays a role in practice when choosing the learning rate and the momentum parameter.     Summary     Linear ODE with constant coefficients:  ; homogeneous for .   Characteristic polynomial  (from the trial solution ). Each root gives fundamental solutions: real and simple ; simple , ; multiplicity  additional factors .   General solution, homogeneous case:  ; the from initial conditions. Working backward: read off the roots from the fundamental solutions, multiply out as the product of the linear factors, read off the ODE (system identification). The same exponential trial solution gives Binet's formula for the Fibonacci recursion.   Nonhomogeneous:  . Particular solution by the method of undetermined coefficients (polynomial, , , products of these), coefficients by substituting and comparing. Resonance: if the exponent of the forcing function coincides with a root of multiplicity of , multiply the trial solution by .   Harmonic oscillator  , roots : undamped oscillation; decaying oscillation; critically damped case ( ); overdamped case. Driving at without damping: resonance catastrophe (the amplitude grows like ). With damping, the amplitude stays finite, , but becomes very large for small and — the reason why soldiers break step on bridges.   The same equation describes the mass-spring system ( , ), the RLC circuit ( , ) and the error dynamics of an optimizer with momentum.      Exercises    What is the order of the ODE ? Is it linear? Is it homogeneous or nonhomogeneous? Does it have constant coefficients?    The highest derivative that occurs is , so the ODE has order . It is linear, since each occur only to the first power. Because of the right-hand side , it is nonhomogeneous . The coefficient of is not constant, so the ODE does not have constant coefficients.      Determine the general solution of the ODE .    The characteristic polynomial has the roots and . The general solution is       Determine the general solution of the ODE .    The characteristic polynomial has the roots , so . Since is not a root of , we use the trial solution for the constant forcing function. Substituting gives . The general solution is       A damped mass-spring system satisfies the ODE . Which damping case applies, and what is the general solution?    In the standard form , we have , . Since , this is the overdamped case . The roots of the characteristic polynomial are , so , . The general solution is      "
},
{
  "id": "sec-lineare-dgl-hoeherer-ordnung-2",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#sec-lineare-dgl-hoeherer-ordnung-2",
  "type": "Objectives",
  "number": "5.2",
  "title": "",
  "body": "  After this section, you can    recognize higher-order linear differential equations and classify them by homogeneity and by whether their coefficients are constant;  set up the characteristic polynomial and, from its roots — real, complex or multiple — read off the general solution of the homogeneous equation;  solve second-order initial value problems and, conversely, reconstruct the differential equation from a given solution;  find particular solutions of nonhomogeneous equations with the method of undetermined coefficients, including the resonance case;  distinguish the damping cases of the harmonic oscillator and apply them to the mass-spring system, the RLC circuit and the momentum optimizer.   "
},
{
  "id": "sub-lineare-dgl-hoeherer-ordnung-definition-3",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#sub-lineare-dgl-hoeherer-ordnung-definition-3",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "higher-order linear differential equations with constant coefficients "
},
{
  "id": "def-lineare-dgl-hoeherer-ordnung",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#def-lineare-dgl-hoeherer-ordnung",
  "type": "Definition",
  "number": "5.2.1",
  "title": "Linear ODE of order <span class=\"process-math\">\\(n\\)<\/span>.",
  "body": " Linear ODE of order   A differential equation of order is called linear if it can be written in the form where the coefficients are functions.    If all are constant , the ODE has constant coefficients .  If , the ODE is called homogeneous ; otherwise, it is called nonhomogeneous .     "
},
{
  "id": "ex-linearitaet-hoeherer-ordnung-erkennen",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-linearitaet-hoeherer-ordnung-erkennen",
  "type": "Example",
  "number": "5.2.2",
  "title": "Computational example: Recognizing linearity, homogeneity and constant coefficients.",
  "body": " Computational example: Recognizing linearity, homogeneity and constant coefficients   Which of the following ODEs are linear? Which of these are homogeneous or nonhomogeneous, and which have constant coefficients?             In the term , the unknown function does not occur to the first power — the equation is not linear .  All coefficients ( ) are numbers, hence constant, and the right-hand side is different from — linear , nonhomogeneous , constant coefficients .  The coefficient of is not constant. But the equation is of the first power in each of , and the right-hand side is — linear , homogeneous , but not with constant coefficients.     "
},
{
  "id": "def-charakteristisches-polynom",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#def-charakteristisches-polynom",
  "type": "Definition",
  "number": "5.2.3",
  "title": "Characteristic polynomial.",
  "body": " Characteristic polynomial   The characteristic polynomial of the above ODE is    "
},
{
  "id": "thm-nullstelle-einfach-reell",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#thm-nullstelle-einfach-reell",
  "type": "Theorem",
  "number": "5.2.4",
  "title": "Case 1: Simple real root.",
  "body": " Case 1: Simple real root   If is a simple root of , then is a solution of the ODE.   "
},
{
  "id": "ex-charakteristisches-polynom-zwei-reelle-nullstellen",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-charakteristisches-polynom-zwei-reelle-nullstellen",
  "type": "Example",
  "number": "5.2.5",
  "title": "Computational example: Two distinct real roots (Case 1) (optional).",
  "body": " Computational example: Two distinct real roots (Case 1) (optional)   Determine the general solution of and the solution with , .     has the simple roots and . By Case 1, each of them gives a solution, and the general solution is (anticipating ) Check for : ✓. The initial values give the system of equations Adding twice the first equation to the second gives , so , and . Two initial conditions for two constants — as for free fall in .   "
},
{
  "id": "thm-nullstelle-komplex-einfach",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#thm-nullstelle-komplex-einfach",
  "type": "Theorem",
  "number": "5.2.6",
  "title": "Case 2: Simple pair of complex conjugate roots.",
  "body": " Case 2: Simple pair of complex conjugate roots   If (with ) is a simple root of , then the complex conjugate is also a simple root (since the coefficients of are real). The real and imaginary parts of the complex solution then give two independent real solutions    "
},
{
  "id": "thm-nullstelle-mehrfach",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#thm-nullstelle-mehrfach",
  "type": "Theorem",
  "number": "5.2.7",
  "title": "Case 3: Root of multiplicity <span class=\"process-math\">\\(k\\)<\/span>.",
  "body": " Case 3: Root of multiplicity    (a) If is a real root of multiplicity of , then form independent solutions of the ODE.   (b) If (with ) is a complex root of multiplicity , then the real and imaginary parts of , , give the independent real solutions    "
},
{
  "id": "thm-allgemeine-loesung-homogen-hoehere-ordnung",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#thm-allgemeine-loesung-homogen-hoehere-ordnung",
  "type": "Theorem",
  "number": "5.2.8",
  "title": "General solution of the homogeneous ODE.",
  "body": " General solution of the homogeneous ODE   If are the fundamental solutions obtained by the above cases from the roots of the characteristic polynomial, then the general solution is The free parameters can be fixed by given initial values; this gives a particular solution.   "
},
{
  "id": "ex-charakteristisches-polynom-doppelte-nullstelle",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-charakteristisches-polynom-doppelte-nullstelle",
  "type": "Example",
  "number": "5.2.9",
  "title": "Computational example: Double real root (Case 3a) (optional).",
  "body": " Computational example: Double real root (Case 3a) (optional)   Determine the general solution of .    The characteristic polynomial can be factored with the formula for the square of a difference: . So there is only one root, the double root . By Case 3a, it gives the fundamental solutions and , and the general solution is The check shows that the strange factor really works: for , we have and , so ✓. With a double root, the trial solution alone would have given only one solution, but a second-order ODE needs two.   "
},
{
  "id": "ex-charakteristisches-polynom-komplexe-nullstelle",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-charakteristisches-polynom-komplexe-nullstelle",
  "type": "Example",
  "number": "5.2.10",
  "title": "Computational example: Simple pair of complex roots (Case 2) (optional).",
  "body": " Computational example: Simple pair of complex roots (Case 2) (optional)   Determine the general solution of .    For , the quadratic formula gives the roots With , , Case 2 gives the fundamental solutions and , so    "
},
{
  "id": "ex-charakteristisches-polynom-kombiniert",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-charakteristisches-polynom-kombiniert",
  "type": "Example",
  "number": "5.2.11",
  "title": "Computational example: Combining Case 1 and Case 2.",
  "body": " Computational example: Combining Case 1 and Case 2   Determine the general solution of . ( Hint : One root is .)    For , substituting confirms . Polynomial division gives (check: ), and has the roots (Case 2 with , ). Together with the simple real root (Case 1), we get the general solution    "
},
{
  "id": "ex-charakteristisches-polynom-doppelt-komplex",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-charakteristisches-polynom-doppelt-komplex",
  "type": "Example",
  "number": "5.2.12",
  "title": "Computational example: Double pair of complex roots (Case 3b) (optional).",
  "body": " Computational example: Double pair of complex roots (Case 3b) (optional)   Determine the general solution of .    The formula for the square of a sum (in ) gives , so has the double pair of complex conjugate roots ( , , ). By Case 3b, they give the four fundamental solutions , , , , and the general solution is By the way, we have met the polynomial before: in , we found that it has no root at all in , but two double roots in . It is exactly these multiplicities that now determine the factors in the solution.   "
},
{
  "id": "ex-binet-fibonacci",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-binet-fibonacci",
  "type": "Example",
  "number": "5.2.13",
  "title": "Digression: A formula for the Fibonacci numbers.",
  "body": " Digression: A formula for the Fibonacci numbers   The Fibonacci numbers satisfy the recursion with , . (In , we started with ; the starting value fits this, because then .) Carry the exponential trial solution over to sequences by substituting , and determine an explicit formula for .    Substituting gives , and dividing by gives the characteristic polynomial of the recursion, so (the golden ratio) and . As for an ODE, every combination is a solution of the recursion, and the initial values fix the constants: and , so . This gives Binet's formula  Remarkably, although the formula is full of square roots of , the result is always an integer. Since , the second term quickly becomes tiny; for , for example, , and indeed . So the Fibonacci numbers grow essentially geometrically, with the factor .   "
},
{
  "id": "sub-loesung-inhomogene-lineare-dgl-hoeherer-ordnung-3",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#sub-loesung-inhomogene-lineare-dgl-hoeherer-ordnung-3",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "method of undetermined coefficients particular solution "
},
{
  "id": "sub-loesung-inhomogene-lineare-dgl-hoeherer-ordnung-5",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#sub-loesung-inhomogene-lineare-dgl-hoeherer-ordnung-5",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "resonance case "
},
{
  "id": "tab-ansatz-typ-rechte-seite",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#tab-ansatz-typ-rechte-seite",
  "type": "Table",
  "number": "5.2.14",
  "title": "Trial solutions for the method of undetermined coefficients (<span class=\"process-math\">\\(k\\)<\/span> = multiplicity of the root in the resonance case)",
  "body": " Trial solutions for the method of undetermined coefficients ( = multiplicity of the root in the resonance case)      Forcing function  Trial solution for    Polynomial of degree  if is not a root of ; otherwise     if is not a root of ; otherwise     if is not a root of ; otherwise     if is not a root of ; otherwise with the factor    "
},
{
  "id": "ex-ansatz-rechte-seite-polynom",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-ansatz-rechte-seite-polynom",
  "type": "Example",
  "number": "5.2.15",
  "title": "Computational example: The method of undetermined coefficients without resonance.",
  "body": " Computational example: The method of undetermined coefficients without resonance   Determine the general solution of .    The characteristic polynomial has the double root , so . Since is not a root of , we use the trial solution . With , , substituting gives so, comparing coefficients, (from ), (from ), and (from ). Hence , and the general solution is    "
},
{
  "id": "ex-ansatz-rechte-seite-exponentiell-resonanz",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-ansatz-rechte-seite-exponentiell-resonanz",
  "type": "Example",
  "number": "5.2.16",
  "title": "Computational example: Exponential forcing function in the resonance case.",
  "body": " Computational example: Exponential forcing function in the resonance case   Determine the general solution of .    The characteristic polynomial has the double root , so . The forcing function belongs to — resonance with multiplicity . Trial solution: , with the derivatives (product rule) Substituting into the ODE: All terms with cancel — this is typical of the resonance case. From , it follows that . The general solution is    "
},
{
  "id": "ex-ansatz-rechte-seite-gedaempft-trigonometrisch",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-ansatz-rechte-seite-gedaempft-trigonometrisch",
  "type": "Example",
  "number": "5.2.17",
  "title": "Computational example: Damped trigonometric forcing function (optional).",
  "body": " Computational example: Damped trigonometric forcing function (optional)   Determine a particular solution of .    The characteristic polynomial has the roots . The forcing function belongs to ; this is not a root of — not the resonance case. Trial solution: . Differentiating twice (product and chain rules), substituting and sorting by and gives This should equal , so and . The first equation gives ; substituting into the second gives , so , and    "
},
{
  "id": "sub-harmonischer-oszillator-2",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#sub-harmonischer-oszillator-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "mass-spring system "
},
{
  "id": "rem-schwingung-ungedaempft",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#rem-schwingung-ungedaempft",
  "type": "Remark",
  "number": "5.2.18",
  "title": "Case 1a: Free undamped oscillation (<span class=\"process-math\">\\(\\beta=0\\)<\/span>).",
  "body": " Case 1a: Free undamped oscillation ( )  Without damping, the ODE becomes , with purely imaginary roots . The general solution is an undamped oscillation with constant amplitude.  "
},
{
  "id": "rem-schwingung-gedaempft-uebersicht",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#rem-schwingung-gedaempft-uebersicht",
  "type": "Remark",
  "number": "5.2.19",
  "title": "Case 1b: Free damped oscillation (<span class=\"process-math\">\\(\\beta&gt;0\\)<\/span>).",
  "body": " Case 1b: Free damped oscillation ( )  For , we distinguish three subcases by the sign of : the underdamped case ( ), the critically damped case ( ) and the overdamped case ( ).  "
},
{
  "id": "ex-freie-schwingung-schwache-daempfung",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-freie-schwingung-schwache-daempfung",
  "type": "Example",
  "number": "5.2.20",
  "title": "Computational example: Underdamped case.",
  "body": " Computational example: Underdamped case   Solve with , .    Here , ; since , the system is underdamped. The roots give By the product rule, From and , it follows that The system oscillates about the equilibrium position, with an amplitude that decays exponentially to .   "
},
{
  "id": "ex-freie-schwingung-aperiodischer-grenzfall",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-freie-schwingung-aperiodischer-grenzfall",
  "type": "Example",
  "number": "5.2.21",
  "title": "Computational example: Critically damped case.",
  "body": " Computational example: Critically damped case   Solve with , .    Here , : the critically damped case. The characteristic polynomial has the double root , so and (product rule) . From and , it follows that The system returns to the equilibrium position as fast as possible without oscillating — the borderline case between oscillation and pure decay.   "
},
{
  "id": "ex-anwendung-stossdaempfer-auslegen",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-anwendung-stossdaempfer-auslegen",
  "type": "Example",
  "number": "5.2.22",
  "title": "Application: Designing a shock absorber (optional).",
  "body": " Application: Designing a shock absorber (optional)   One wheel of a car carries a mass of  kg, and the spring has the spring constant  N\/m. What damping constant (in Ns\/m) must the shock absorber have so that the car body is critically damped when it comes to rest after a bump?    We have , so per second. Critical damping requires , and with , it follows that A weaker shock absorber lets the car keep bouncing (underdamped case); a stronger one makes the suspension hard and sluggish (overdamped case). In practice, a considerably lower value is chosen, about to of critical damping, because a slight bounce feels more comfortable — but critical damping is the reference point of the design.   "
},
{
  "id": "ex-freie-schwingung-kriechfall",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-freie-schwingung-kriechfall",
  "type": "Example",
  "number": "5.2.23",
  "title": "Computational example: Overdamped case.",
  "body": " Computational example: Overdamped case   Solve with , .    Here , ; since , the system is overdamped. The roots are real and distinct: , , so . From and , it follows (substituting ) that , , so Both parts decay monotonically and without oscillating, and decays much faster than .   "
},
{
  "id": "fig-daempfungsfaelle",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#fig-daempfungsfaelle",
  "type": "Figure",
  "number": "5.2.24",
  "title": "",
  "body": " The four cases of the free oscillation (so ) with the same initial values , : undamped ( ), underdamped ( ), critically damped ( ) and overdamped ( ). The critically damped case reaches the equilibrium position fastest without overshooting.    Four curves over the time axis; all start at with a horizontal tangent. The undamped curve is a pure cosine oscillation with constant amplitude. The underdamped curve oscillates about zero with exponentially decreasing amplitude. The critically damped curve falls monotonically and quickly toward zero without crossing the axis. The overdamped curve also falls monotonically toward zero, but much more slowly.     "
},
{
  "id": "ex-anwendung-systemidentifikation",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-anwendung-systemidentifikation",
  "type": "Example",
  "number": "5.2.25",
  "title": "Application: From the measured signal back to the differential equation.",
  "body": " Application: From the measured signal back to the differential equation   A displacement sensor on a test mass suspended on a spring (  kg) records the displacement after an impact ( in mm, in seconds). Which differential equation describes the system? What are the spring constant (in N\/m) and the damping constant (in Ns\/m)?    The solution consists of and , so by , it belongs to the pair of complex roots . The characteristic polynomial is therefore and the ODE is . Check: by the product rule, so . Hence and , and with , , it follows that The measurement reveals the parameters very directly: the decay rate gives the real part , and the period  s gives the imaginary part . Together, they give . Working backward from the signal to the model in this way is called system identification , and it is everyday practice in the condition monitoring of machines: if the measured natural frequency changes, something has usually changed in the mechanics — for example, a crack or a loose screw.   "
},
{
  "id": "rem-schwingung-erzwungen",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#rem-schwingung-erzwungen",
  "type": "Remark",
  "number": "5.2.26",
  "title": "Case 2: Forced oscillation and resonance.",
  "body": " Case 2: Forced oscillation and resonance  If a sinusoidal external force with driving frequency acts on the system, the method of undetermined coefficients gives a particular solution of the form , as long as is not a root of the characteristic polynomial — the system takes on (after a transient phase) the frequency of the driving force. If, however, the system is undamped and is driven exactly at its natural frequency , then is a root of , and resonance occurs.  "
},
{
  "id": "ex-erzwungene-schwingung-resonanzkatastrophe",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-erzwungene-schwingung-resonanzkatastrophe",
  "type": "Example",
  "number": "5.2.27",
  "title": "Computational example: Resonance catastrophe.",
  "body": " Computational example: Resonance catastrophe   Determine the general solution of the undamped, driven system .    The characteristic polynomial has the roots . So the driving frequency exactly matches the natural frequency — the resonance case. Trial solution: . Differentiating twice with the product rule gives and when we substitute into , the part with cancels against : Comparing coefficients gives , , so The term grows without bound: the amplitude of the oscillation increases linearly with time — a resonance catastrophe .   "
},
{
  "id": "ex-anwendung-resonanzkurve-komplex",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-anwendung-resonanzkurve-komplex",
  "type": "Example",
  "number": "5.2.28",
  "title": "Application: The resonance curve with complex numbers.",
  "body": " Application: The resonance curve with complex numbers   A damped system has , and . Use the complex trial solution for to determine the amplitude of the forced oscillation as a function of the driving frequency , and evaluate it for , and .    With and , the ODE becomes a single complex equation for , and hence Here the quotient rule for moduli from helped. Why is the amplitude? If we write , then : an oscillation with amplitude and phase shift . With the given values, , so Slow shaking ( ) simply moves the system along; at the natural frequency, the amplitude is four times as large; very fast shaking hardly gets through, because the system is too sluggish. If you have ever watched a washing machine speed up for the spin cycle, you know this resonance curve : as it passes through a certain speed of rotation, it shakes violently; after that, it runs smoothly again. Incidentally, the denominator is exactly the characteristic polynomial , evaluated at . For the low-pass filter in , the denominator is likewise the characteristic polynomial of its first-order ODE at — mathematically, resonant circuits and filters are close relatives.   "
},
{
  "id": "rem-rlc-schwingkreis",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#rem-rlc-schwingkreis",
  "type": "Remark",
  "number": "5.2.29",
  "title": "Application: RLC circuit.",
  "body": " Application: RLC circuit  The same mathematics describes an electrical series RLC circuit consisting of an inductance , a resistance and a capacitance : for the charge on the capacitor, we have (without an external voltage source) which is exactly the form of the free mass-spring system with and . A large resistance corresponds to strong damping: the charge decreases without changing polarity (overdamped or critically damped case), whereas a small resistance leads to a discharge with damped oscillations (underdamped case) — exactly the same case distinction as for the mechanical mass-spring system. For  H and  µF, we have ; critical damping occurs at . With a smaller resistance, the circuit oscillates.  "
},
{
  "id": "rem-daempfung-gradientenabstieg",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#rem-daempfung-gradientenabstieg",
  "type": "Remark",
  "number": "5.2.30",
  "title": "Application: Momentum in gradient descent.",
  "body": " Application: Momentum in gradient descent  The case distinction of the damped oscillator also reappears in the training of neural networks. Optimizers with momentum (the classical heavy-ball method) update the parameter vector not only on the basis of the current gradient; they also add an inertia term that continues the last direction of motion. In the continuous-time limit, the error (distance from the optimum) of such a trajectory near a minimum can be described approximately by exactly our oscillator ODE , where depends on the curvature of the cost function and on the momentum parameter. Damping that is too weak ( ) makes the optimization overshoot and oscillate around the minimum; damping that is too strong ( ) makes convergence unnecessarily slow. The critically damped case thus marks — just as for the mass-spring system — the fastest possible approach without overshooting, a criterion that plays a role in practice when choosing the learning rate and the momentum parameter.  "
},
{
  "id": "sub-zusammenfassung-5-2-2",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#sub-zusammenfassung-5-2-2",
  "type": "Paragraph (with a defined term)",
  "number": "",
  "title": "",
  "body": "Linear ODE with constant coefficients: Characteristic polynomial General solution, homogeneous case: Nonhomogeneous: Resonance: Harmonic oscillator The same equation "
},
{
  "id": "exercise-buch-dgl-ordnung-linearitaet-bestimmen",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#exercise-buch-dgl-ordnung-linearitaet-bestimmen",
  "type": "Exercise",
  "number": "5.2.6.1",
  "title": "",
  "body": "  What is the order of the ODE ? Is it linear? Is it homogeneous or nonhomogeneous? Does it have constant coefficients?    The highest derivative that occurs is , so the ODE has order . It is linear, since each occur only to the first power. Because of the right-hand side , it is nonhomogeneous . The coefficient of is not constant, so the ODE does not have constant coefficients.   "
},
{
  "id": "exercise-buch-charakteristisches-polynom-einfach",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#exercise-buch-charakteristisches-polynom-einfach",
  "type": "Exercise",
  "number": "5.2.6.2",
  "title": "",
  "body": "  Determine the general solution of the ODE .    The characteristic polynomial has the roots and . The general solution is    "
},
{
  "id": "exercise-buch-inhomogene-dgl-einfach",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#exercise-buch-inhomogene-dgl-einfach",
  "type": "Exercise",
  "number": "5.2.6.3",
  "title": "",
  "body": "  Determine the general solution of the ODE .    The characteristic polynomial has the roots , so . Since is not a root of , we use the trial solution for the constant forcing function. Substituting gives . The general solution is    "
},
{
  "id": "exercise-buch-schwingfall-klassifizieren",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#exercise-buch-schwingfall-klassifizieren",
  "type": "Exercise",
  "number": "5.2.6.4",
  "title": "",
  "body": "  A damped mass-spring system satisfies the ODE . Which damping case applies, and what is the general solution?    In the standard form , we have , . Since , this is the overdamped case . The roots of the characteristic polynomial are , so , . The general solution is    "
},
{
  "id": "backmatter-2",
  "level": "1",
  "url": "backmatter-2.html",
  "type": "Index",
  "number": "",
  "title": "Index",
  "body": " Index   "
}
]

var ptx_lunr_idx = lunr(function () {
  this.ref('id')
  this.field('title')
  this.field('body')
  this.metadataWhitelist = ['position']

  ptx_lunr_docs.forEach(function (doc) {
    this.add(doc)
  }, this)
})
